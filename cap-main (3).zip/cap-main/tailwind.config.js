import defaultTheme from "tailwindcss/defaultTheme";
const colors = require("tailwindcss/colors");
import forms from "@tailwindcss/forms";

/** @type {import('tailwindcss').Config} */
export default {
    content: [
        "./vendor/laravel/framework/src/Illuminate/Pagination/resources/views/*.blade.php",
        "./storage/framework/views/*.php",
        "./resources/views/**/*.blade.php",
        "./resources/js/**/*.tsx",
    ],

    theme: {
        extend: {
            colors: {
                primary: "#008e9f",
                secondary: "#0e0e23",
                pageColor: "#D9D9D9",
            },
            fontFamily: {
                Montserrat: ["Montserrat", "sans-serif"],
            },
        },
    },

    plugins: [forms],
};
