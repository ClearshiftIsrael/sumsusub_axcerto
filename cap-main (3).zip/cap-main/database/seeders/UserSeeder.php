<?php

namespace Database\Seeders;

use App\Enums\UserRoleEnum;
use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $userRepository = App()->make(UserRepository::class);
        $array = [
            [
                'username' => 'axcertroadmin',
                'email' => 'admin@axcertro.com',
                'first_name' => 'System Admin',
                'role' => UserRoleEnum::Admin->value,
                'password' => Hash::make('Axcertro#Our1st'),
            ],
            [
                'username' => 'capadmin',
                'email' => 'admin@cap.com',
                'first_name' => 'Cap Admin',
                'role' => UserRoleEnum::Admin->value,
                'password' => Hash::make('Cap#Our1st'),
            ],

        ];
        foreach ($array as $key => $item) {
            if (!$userRepository->existsByColumn(['email' => $item['email']])) {
                $userRepository->create($item);
            }
        }
    }
}
