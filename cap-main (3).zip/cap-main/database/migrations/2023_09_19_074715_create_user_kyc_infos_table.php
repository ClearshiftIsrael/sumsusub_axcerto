<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('user_kyc_infos', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->text('applicationId')->nullable();
            $table->text('moderationComment')->nullable();
            $table->text('clientComment')->nullable();
            $table->string('rejectLabels')->nullable();
            $table->string('userKey')->nullable();
            $table->enum('status', ['notStarted', 'notCompleted', 'pending', 'success', 'declined', 'changeRequest'])->nullable();
            $table->string('has_job')->nullable();
            $table->enum('admin_status', ['pending', 'approved', 'rejected']);
            $table->string('doc_number')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_kyc_infos');
    }
};
