<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('accounts', function (Blueprint $table) {
            $table->id();
            $table->string('name')->nullable();
            $table->string('applicant_id')->nullable();
            $table->string('user_key')->nullable();
            $table->string('verification_level')->nullable();
            $table->enum('kyc_status', ['notStarted', 'notCompleted', 'pending', 'success', 'declined', 'changeRequest'])->default('notStarted');
            $table->enum('status', ['draft', 'active', 'inactive'])->default('draft');
            $table->enum('type', ['individual', 'business'])->default('individual');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('accounts');
    }
};
