<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('account_stages', function (Blueprint $table) {
            $table->id();
            $table->foreignId('accounts_id')->nullable()->constrained('accounts')->cascadeOnDelete();
            $table->text('moderationComment')->nullable();
            $table->text('adminComment')->nullable();
            $table->text('rejectLabels')->nullable();
            $table->enum('status',['approved','rejected'])->default('approved');
            $table->enum('is_current',['yes','no'])->default('no');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('account_stages');
    }
};
