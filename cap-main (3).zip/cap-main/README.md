## Usage
  
1/ Setup the spreadsheet
  
This need to be done only once.
  
```bash
php artisan translation_sheet:setup
```  
  
2/ Prepare the sheet

To avoid some conflicts, we will first run this command to rewrite the locale languages files.

```bash
php artisan translation_sheet:prepare
```  
  
3/ Publish translation to sheet

```bash
php artisan translation_sheet:push
```  
  
4/ Share the spreadsheet with clients or project managers for translations.
  
5/ Once done, You can lock the translations on the spreadsheet (to avoid conflicts)  

```bash
php artisan translation_sheet:lock
```  

6/ Pull the translations

This will pull the translations from the spreadsheet, and write it the language files in your applications.
You can use git diff here to make sure eveything is ok (Conflicts, errors etc ...)

```bash
php artisan translation_sheet:pull
```  

6/ Unlock the translations on the spreadsheet

```bash
php artisan translation_sheet:unlock
```  

Open the spreadsheet in the browser

```bash
php artisan translation_sheet:open
```  
