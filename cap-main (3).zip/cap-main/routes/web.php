<?php

use App\Http\Controllers\AdminOnly\Applicant\ApplicantController;
use App\Http\Controllers\AdminOnly\Dashboard\AdminDashboardController;
use App\Http\Controllers\AdminOnly\DownloadController;
use App\Http\Controllers\AdminOnly\Kyc\KycLevelController;
use App\Http\Controllers\AdminOnly\Questionary\QuestionaryController;
use App\Http\Controllers\AdminOnly\User\UserController;
use App\Http\Controllers\LanguageController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\TestController;
use App\Http\Controllers\UserOnly\Accounts\AccountsManagementController;
use App\Http\Controllers\UserOnly\Accounts\AccountsVerificationController;
use App\Http\Controllers\UserOnly\Customer\CustomerDashboardController;
use App\Http\Controllers\UserOnly\Onboarding\OnboardingController;
use App\Http\Controllers\UserOnly\Verification\VerificationController;
use App\Models\User;
use App\Notifications\Account\AccountNewUserNotification;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/notification', function () {
//     $user = User::first();
//     return (new AccountNewUserNotification($user))
//     ->toMail($user);
// });

Route::redirect('/', '/login', 301);
// languages
Route::get('/language/{language}', [LanguageController::class, 'setLanguage'])->name('language');
Route::middleware('auth')->group(
    function () {

        Route::patch('/profile/twofa', [ProfileController::class, 'updateTwoFa'])->name('profile.update.twofa');
        Route::resource('/profile', ProfileController::class);

        // admin routes prefix('admin')->
        Route::prefix('admin')->middleware(['adminVerify'])->group(
            function () {
                Route::get('/dashboard', [AdminDashboardController::class, 'index'])->name('admin.dashboard');
                Route::post('/users/{id}/refetch', [UserController::class, 'reFetch'])->name('users.refetch'); //users refetch
                Route::post('/users/{id}/reset', [UserController::class, 'reset'])->name('users.reset'); //users reset
                Route::post('/users/{id}/status/change', [UserController::class, 'KYCUpdateAdmin'])->name('users.status.change'); //users reset
                Route::get('/download/{id}', [UserController::class, 'downloadSummery'])->name('file.download');
                Route::resource('/users', UserController::class); //users

                Route::get('/users/{id}/restore', [UserController::class, 'restore'])->name('users.restore');
                Route::delete('/users/permanent/{id}/delete', [UserController::class, 'permanentDelete'])
                    ->name('users.permanent.delete');
                Route::resource('/kyc-levels', KycLevelController::class); //KYC

                // Route::post('kyc/refetch/{id}', [VerificationController::class, 'refetchUserData'])
                //     ->name('kyc.refetch');
                Route::get('export/{id}', [DownloadController::class, 'index'])->name('user.export');

                Route::resource('/questionnaire', QuestionaryController::class); //questionnaire
                Route::post('/questionnaire/import', [QuestionaryController::class, 'importQuestionary'])
                    ->name('questionnaire.import');

                Route::get('applicants/{id}/chnage-key', [ApplicantController::class, 'changeKey'])->name('applicants.change-key');
                Route::resource('/applicants', ApplicantController::class); //Applicants
                Route::post('/applicants/add-applicant', [ApplicantController::class, 'addApplicant'])->name('applicants.add-applicant');
            }
        );
        // customer routes
        Route::middleware(['customerVerify'])->group(
            function () {

                Route::get('/dashboard', [CustomerDashboardController::class, 'index'])->name('dashboard');
                Route::resource('/verify', VerificationController::class);

                Route::post('/accounts/add-user', [AccountsManagementController::class, 'addUser'])->name('accounts.add-user');
                Route::post('/accounts/{id}/update-data', [AccountsManagementController::class, 'updateData'])->name('accounts.update-data');
                Route::get('/accounts/{account}/verification', [AccountsVerificationController::class, 'index'])->name('accounts.verification');
                Route::resource('accounts', AccountsManagementController::class);

            }
        );
        Route::post('/profile/delete', [ProfileController::class, 'ProfileDelete'])->name('profile.delete');
    }
);
require __DIR__ . '/auth.php';
