<?php

namespace App\Integrations\Sumsub;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

/**
 * class KycVerification Service
 * php version 8
 *
 * @category class SumSUb
 *
 * @author   Axcertro (Pvt) Ltd <hello@axcertro.com>
 * */
class SumsubIntegration
{
    protected $token;

    protected $secret;

    protected $url;

    protected $ts;

    protected $webhooks_types;

    const PARAMS = [
        'CREATE_APPLICANT' => '/resources/applicants?levelName=',
        'CREATE_ACCESS_TOKEN' => '/resources/accessTokens?userId=',
        'GET_DIGEST_KEY' => '/resources/inspectionCallbacks/testDigest?secretKey=',
        'RESET_APPLICANT' => '/resources/applicants/',
        'GET_APPLICANT_IMAGES' => '/resources/inspections/',
        'GET_APPLICANT' => '/resources/applicants/',
        'GET_APPLICANT_STATUS' => '/resources/applicants/',
        'PATCH_TOPLEVEL' => '/resources/applicants/',
    ];

    const CONTENT_TYPES = [
        'JSON' => 'application/json',
        'PLAIN' => 'text/plain',
        'IMAGE' => 'application/octet-stream',
        'PDF' => 'application/pdf',
    ];

    const METHODS = [
        'POST' => 'post',
        'PATCH' => 'patch',
        'GET' => 'get',
    ];

    /**
     * __construct
     */
    public function __construct()
    {
        $this->ts = round(strtotime('now'));
        $this->token = config('services.sumsub.token');
        $this->secret = config('services.sumsub.secret');
        $this->url = config('services.sumsub.url');
        $this->webhooks_types = config('services.sumsub.webhooks');
    }

    /**
     * Create Applicant
     *
     * @param  string  $externalUserId Random String which is related to customer
     * @return array $response
     */
    public function createApplicant($externalUserId, $level): array
    {
        $url_param2 = self::PARAMS['CREATE_APPLICANT'].urlencode($level);
        //Request Body
        $body = ['externalUserId' => $externalUserId];
        // Request
        $response = Http::withHeaders(
            $this->getHeaders($this->ts, self::METHODS['POST'], $url_param2, $body, self::CONTENT_TYPES['JSON'])
        )->post($this->url.$url_param2, $body);

        return $response->successful() ? $response->json() : [];
    }

    /**
     * Method createAccessToken
     *
     * @param  string  $externalUserId [explicite description]
     * @param  string  $level [explicite description]
     */
    public function createAccessToken(string $externalUserId, string $level): string
    {
        $url_param2 = self::PARAMS['CREATE_ACCESS_TOKEN'].$externalUserId.'&levelName='. urlencode($level).'&ttlInSecs='.$this->ts;
        // call the url
        $response = Http::withHeaders(
            $this->getHeaders(
                $this->ts,
                self::METHODS['POST'],
                $url_param2,
                [],
                self::CONTENT_TYPES['JSON']
            )
        )->post($this->url.$url_param2, []);

        return $response->successful() ? $response->json()['token'] : '';
    }

    /**
     * Get Headers for Request
     *
     * @param  string  $ts          current Time in UTC time format
     * @param  string  $httpMethod  Request method
     * @param  string  $url         Base Url
     * @param  array  $httpBody    Request Body
     * @param  string  $contentType Request Type
     */
    public function getHeaders($ts, $httpMethod, $url, $httpBody, $contentType): array
    {
        return [
            'Content-Type' => $contentType,
            'X-App-Token' => $this->token,
            'X-App-Access-Sig' => $this->_createSignature(
                $ts,
                $httpMethod,
                $url,
                json_encode($httpBody)
            ),
            'X-App-Access-Ts' => $ts,
        ];
    }

    /**
     * Method getHeadersGet
     *
     * @param  string  $ts          current Time in UTC time format
     * @param  string  $httpMethod  Request method
     * @param  string  $url         Base Url
     * @param  string  $contentType Request Type
     */
    public function getHeadersGet($ts, $httpMethod, $url, $contentType): array
    {
        return [
            'Content-Type' => $contentType,
            'X-App-Token' => $this->token,
            'X-App-Access-Sig' => $this->_createSignatureGet(
                $ts,
                $httpMethod,
                $url
            ),
            'X-App-Access-Ts' => $ts,
        ];
    }

    /**
     * Get Headers for Request
     *
     * @param  string  $ts         current Time in UTC time format
     * @param  string  $httpMethod Request method
     * @param  string  $url        Base Url
     * @param  array  $httpBody   Request Body
     */
    private function _createSignature($ts, $httpMethod, $url, $httpBody): string
    {
        return hash_hmac('sha256', $ts.strtoupper($httpMethod).$url.$httpBody, $this->secret);
    }

    /**
     * Method _createSignatureGet
     *
     * @param  string  $ts         current Time in UTC time format
     * @param  string  $httpMethod Request method
     * @param  string  $url        Base Url
     */
    private function _createSignatureGet($ts, $httpMethod, $url): string
    {
        return hash_hmac('sha256', $ts.strtoupper($httpMethod).$url, $this->secret);
    }

    /**
     * Get Digest Key By Request
     *
     * @param  string  $secret_key Digest Secret Key
     * @param  array  $body       Request Body
     */
    public function getDigest(string $secret_key, array $body): array
    {
        $url_param2 = self::PARAMS['GET_DIGEST_KEY'].$secret_key;
        $response = Http::withHeaders(
            $this->getHeaders($this->ts, self::METHODS['POST'], $url_param2, $body, self::CONTENT_TYPES['PLAIN'])
        )->post($this->url.$url_param2, $body);

        return $response->successful() ? $response->json() : [];
    }

    /**
     * Validate Digest
     *
     * @param  Request  $request Http Request
     * @param  string  $secret  Webhook secret
     */
    public function validateDigest(Request $request, string $secret): bool
    {
        return true;
        // return $this->getDigest($secret, $request->all()) == $request->header('x-payload-digest') ? true : false;
    }

    /**
     * Reset Applicant
     *
     * @param  string  $applicantId
     */
    public function resetApplicant($applicantId): bool
    {
        $url_param2 = self::PARAMS['RESET_APPLICANT'].$applicantId.'/reset';
        // Request
        $response = Http::withHeaders(
            $this->getHeaders($this->ts, self::METHODS['POST'], $url_param2, [], self::CONTENT_TYPES['JSON'])
        )->post($this->url.$url_param2, []);

        return $response->successful() ? true : false;
    }


    public function changeTopLevel($data): bool
    {
        $url_param2 = self::PARAMS['PATCH_TOPLEVEL'];
        // Request
        $response = Http::withHeaders(
            $this->getHeaders($this->ts, self::METHODS['PATCH'], $url_param2, $data, self::CONTENT_TYPES['JSON'])
        )->patch($this->url . $url_param2, $data);
        Log::debug("before", [$response]);
        return $response->successful() ? true : false;
    }

    /**
     * Method getApplicant
     *
     * @param  string  $applicationId [explicite description]
     * @return mixed
     */
    public function getApplicant(string $applicationId)
    {
        $url_param2 = self::PARAMS['GET_APPLICANT'].$applicationId.'/one';
        // call the url
        $response = Http::withHeaders(
            $this->getHeadersGet($this->ts, self::METHODS['GET'], $url_param2, self::CONTENT_TYPES['JSON'])
        )->get($this->url.$url_param2);

        return $response->successful() ? $response->json() : '';
    }

    /**
     * Method resetStep
     *
     * @param  string  $applicationId [explicite description]
     * @param $step $step [explicite description]
     * @return void
     */
    public function resetStep(string $applicationId, $step)
    {
        $url_param2 = self::PARAMS['GET_APPLICANT']."$applicationId/resetStep/$step";
        // call the url
        $response = Http::withHeaders(
            $this->getHeaders($this->ts, self::METHODS['POST'], $url_param2, [], self::CONTENT_TYPES['JSON'])
        )->post($this->url.$url_param2);

        return $response->successful() ? $response->json() : '';
    }

    /**
     * Method getApplicantPdf
     *
     * @param  string  $applicantId [explicite description]
     * @param  string  $reportType [explicite description]
     * @return void
     */
    public function getApplicantPdf(string $applicantId, string $name, string $reportType = 'applicantReport')
    {
        $url_param2 = self::PARAMS['GET_APPLICANT'].$applicantId.'/summary/report?report='.$reportType.'&lang=en';
        // dd($url_param2);
        // call the url
        $response = Http::withHeaders(
            $this->getHeadersGet($this->ts, self::METHODS['GET'], $url_param2, self::CONTENT_TYPES['PDF'])
        )->accept(self::CONTENT_TYPES['PDF'])->get($this->url.$url_param2);
        $path = '';
        if ($binary = $response->body()) {
            $path = 'downloads/'.$applicantId.'/'.$name.str()->random(50).'.pdf';
            Storage::put($path, $binary);
        }

        return $path;
    }

    /**
     * Method getApplicantStatus
     *
     * @param  string  $applicationId [explicite description]
     * @return mixed
     */
    public function getApplicantStatus(string $applicationId)
    {
        $url_param2 = self::PARAMS['GET_APPLICANT_STATUS'].$applicationId.'/requiredIdDocsStatus';
        // call the url
        $response = Http::withHeaders(
            $this->getHeadersGet($this->ts, self::METHODS['GET'], $url_param2, self::CONTENT_TYPES['JSON'])
        )->get($this->url.$url_param2);

        return $response->successful() ? $response->json() : '';
    }

    /**
     * Method getApplicantImages
     *
     * @param  string  $applicationId [explicite description]
     * @return void
     */
    public function getApplicantImages(string $inspectionId, $imageId, $applicantId)
    {
        $url_param2 = self::PARAMS['GET_APPLICANT_IMAGES'].$inspectionId.'/resources'.'/'.$imageId;
        // call the url
        $response = Http::withHeaders(
            $this->getHeadersGet($this->ts, self::METHODS['GET'], $url_param2, self::CONTENT_TYPES['IMAGE'])
        )->accept('application/json')->get($this->url.$url_param2);
        $binary = $response->body();
        $path = '/'.'downloads/'.$applicantId.'/'.str()->random(50);
        $resp = Storage::put($path, $binary);
        $mime = Storage::mimeType($path);

        $type = '.jpg';
        switch ($mime) {
            case 'image/jpeg':
                $type = '.jpg';
                break;
            case 'image/png':
                $type = '.png';
                break;
            case 'application/pdf':
                $type = '.pdf';
                break;
        }
        $newPath = $path.$type;
        Storage::move($path, $newPath);

        return ($response->successful() && $resp) ? $newPath : '';
    }

    /**
     * Method getApplicantByExternalId
     *
     * @param  string  $userKey [explicite description]
     * @return void
     */
    public function getApplicantByExternalId(string $userKey)
    {
        $url_param2 = self::PARAMS['GET_APPLICANT'].'-;externalUserId='.$userKey.'/one';
        // call the url
        $response = Http::withHeaders(
            $this->getHeadersGet($this->ts, self::METHODS['GET'], $url_param2, self::CONTENT_TYPES['JSON'])
        )->get($this->url.$url_param2);

        return $response->successful() ? $response->json() : '';
    }
}
