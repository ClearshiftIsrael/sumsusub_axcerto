<?php

namespace App\Enums;

enum TeamInvitationStatusEnum: string
{
    case Sent = 'sent';
    case Clicked = 'clicked';
    case Expired = 'expired';
}
