<?php

namespace App\Enums;

enum UserIDTypeEnum: string
{
    case PASSPORT = 'PASSPORT';
    case ID_CARD = 'ID_CARD';
    case DRIVERS = 'DRIVERS';
}
