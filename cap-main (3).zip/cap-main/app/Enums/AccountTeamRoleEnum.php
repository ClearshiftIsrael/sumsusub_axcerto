<?php

namespace App\Enums;

enum AccountTeamRoleEnum: string
{
    case Owner = 'owner';
    case Member = 'member';
    // case TransferOwner = 'transfer_owner';
}
