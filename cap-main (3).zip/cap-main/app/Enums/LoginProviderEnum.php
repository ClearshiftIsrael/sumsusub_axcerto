<?php

namespace App\Enums;

enum LoginProviderEnum: string
{
    case BASIC = 'basic';
    case GOOGLE = 'google';
    case FACEBOOK = 'facebook';
    case LINKEDIN = 'linkedin';

}
