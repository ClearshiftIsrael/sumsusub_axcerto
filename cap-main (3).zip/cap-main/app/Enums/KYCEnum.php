<?php

namespace App\Enums;

enum KYCEnum: string
{
    case Individual = 'basic-kyc-level';
    case Business = 'business-kyc-level';
}
