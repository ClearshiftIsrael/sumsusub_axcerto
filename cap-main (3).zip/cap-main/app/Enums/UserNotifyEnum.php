<?php

namespace App\Enums;

enum UserNotifyEnum: string
{
    case Send = 'send';
    case NotSend = 'not_send';
}
