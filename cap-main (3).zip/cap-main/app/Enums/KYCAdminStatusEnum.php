<?php

namespace App\Enums;

enum KYCAdminStatusEnum: string
{
    case Pending = 'pending';
    case Approved = 'approved';
    case Rejected = 'rejected';
    case Inprogress = 'inprogress';
}
