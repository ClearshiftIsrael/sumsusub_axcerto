<?php

namespace App\Enums;

enum IsKYCDefaultEnum: string
{
    case Default = 'yes';
    case NotDefault = 'no';
}
