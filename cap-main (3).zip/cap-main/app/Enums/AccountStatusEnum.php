<?php

namespace App\Enums;

enum AccountStatusEnum: string
{
    case Draft = 'draft';
    case Active = 'active';
    case InActive = 'inactive';
}
