<?php

namespace App\Enums;

enum KYCLevelStatusEnum: string
{
    case Active = 'active';
    case Inactive = 'inactive';
}
