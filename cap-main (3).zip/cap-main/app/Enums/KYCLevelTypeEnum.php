<?php

namespace App\Enums;

enum KYCLevelTypeEnum: string
{
    case KYC = 'kyc';
    case KYB = 'kyb';
}
