<?php

namespace App\Enums;

enum IsLoggedInEnum: string
{
    case LoggedIn = 'true';
    case NotLogIn = 'false';
}
