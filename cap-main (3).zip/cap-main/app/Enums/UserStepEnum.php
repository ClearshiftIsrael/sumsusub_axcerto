<?php

namespace App\Enums;

enum UserStepEnum: string
{
    case Started = 'started';
    case One = 'one';

    case Two = 'two';
}
