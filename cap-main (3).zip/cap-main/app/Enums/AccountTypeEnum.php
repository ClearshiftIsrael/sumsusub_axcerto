<?php

namespace App\Enums;

enum AccountTypeEnum: string
{
    case Individual = 'individual';
    case Business = 'business';
}
