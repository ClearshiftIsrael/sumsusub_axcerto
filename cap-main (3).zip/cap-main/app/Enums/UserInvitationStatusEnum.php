<?php

namespace App\Enums;

enum UserInvitationStatusEnum: string
{
    case Yes = 'yes';
    case No = 'no';
}
