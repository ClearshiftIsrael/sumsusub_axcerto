<?php

namespace App\Enums;

enum DownloadStatusEnum: string
{
    case No = 'no';
    case Preparing = 'preparing';
    case Yes = 'yes';
}
