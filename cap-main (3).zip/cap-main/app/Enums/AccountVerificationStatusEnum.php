<?php

namespace App\Enums;

enum AccountVerificationStatusEnum: string
{
    case NotStarted = 'notStarted';
    case NotCompleted = 'notCompleted';
    case Pending = 'pending';
    case Success = 'success';
    case Declined = 'declined';
    case ChangeRequest = 'changeRequest';
}
