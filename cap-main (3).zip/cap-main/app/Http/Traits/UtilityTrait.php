<?php

namespace App\Http\Traits;

use Illuminate\Support\Arr;

trait UtilityTrait
{
    /**
     * Method enumToArray
     *
     * @param  mixed  $enum [explicite description]
     */
    public function enumToArray($enum): array
    {

        return Arr::map($enum, fn ($enum) => $enum->value);
    }

    /**
     * Method enumToSelect
     *
     * @param  mixed  $enum [explicite description]
     */
    public function enumToSelect($enum): array
    {
        $arr = [];
        foreach ($this->enumToArray($enum) as $key => $value) {
            if ($value != 'draft') {
                $arr[] = ['value' => $value, 'label' => strtoupper($value)];
            }
        }

        return $arr;
    }
}
