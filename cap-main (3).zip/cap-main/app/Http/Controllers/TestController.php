<?php

namespace App\Http\Controllers;

use App\Notifications\User\ApproveNotification;
use App\Notifications\User\DeclinedNotification;
use App\Notifications\User\WelcomeNotification;
use App\Repositories\Eloquent\Users\KycInfoRepository;
use App\Repositories\Eloquent\Users\UserRepository;

class TestController extends Controller
{
    /**
     * @return [type]
     */
    public function test()
    {
        // $kycInfo = app()->make(KycInfoRepository::class)->all();
        // foreach ($kycInfo as $value) {
        //     if ($value->applicationId) {
        //         $user = app()->make(UserRepository::class)->findById($value->user_id);
        //         $user->update(['applicant_id' => $value->applicationId]);
        //     }
        // }

        app()->make(UserRepository::class)->findById(43)->notify(new WelcomeNotification());
        // $user->notify(new ApproveNotification());
        // $user->notify(new DeclinedNotification());

        return 'success';
    }
}
