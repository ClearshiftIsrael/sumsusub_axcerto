<?php

namespace App\Http\Controllers\Webhooks;

use App\Http\Controllers\Controller;
use App\Services\Accounts\AccountsService;
use App\Services\User\KycService;
use Illuminate\Http\Request;

class WebHooksController extends Controller
{
    protected $accountsService;
    public function __construct(AccountsService $accountsService){
        $this->accountsService=$accountsService;
    }
      
    /**
     * verification
     *
     * @param  mixed $request
     * @param  mixed $type
     * @return void
     */
    public function verification(Request $request, $type)
    {
        return $this->accountsService->verify($request, $type);
    }
}
