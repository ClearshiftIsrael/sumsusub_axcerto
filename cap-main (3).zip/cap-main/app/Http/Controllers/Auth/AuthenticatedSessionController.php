<?php

namespace App\Http\Controllers\Auth;

use App\Enums\IsLoggedInEnum;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\CodeRequest;
use App\Http\Requests\Auth\LoginRequest;
use App\Notifications\User\TwoFaNotification;
use App\Providers\RouteServiceProvider;
use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

class AuthenticatedSessionController extends Controller
{
    /**
     * Display the login view.
     */
    public function create(): Response
    {
        return Inertia::render('Auth/Login', [
            'canResetPassword' => Route::has('password.request'),
            'status' => session('status'),
        ]);
    }

    /**
     * @param  mixed  $cred
     * @return [type]
     */
    public function auto(Request $request)
    {
        $user = app()->make(UserRepository::class)->getUserByMd5Id($request->cred);
        if ($user && $user->is_logged_in->value == IsLoggedInEnum::NotLogIn->value) {
            return Inertia::render('Auth/SetPassword', [
                'id' => $request->cred,
            ]);
        } elseif ($user && $user->is_logged_in->value == IsLoggedInEnum::LoggedIn->value) {
            // if($user->email){
            return Inertia::render('Auth/Login', [
                'canResetPassword' => Route::has('password.request'),
                'status' => session('status'),
            ]);
            // }
        }

        return Inertia::render('Error/Index', [
            'status' => 401,
            'statusText' => 'Unauthorized',
            'message' => 'You are not authorized to access this page.',

        ]);
        // return redirect()->intended(RouteServiceProvider::HOME);
    }
    public function store(LoginRequest $request)
    {
        $userRepository = app()->make(UserRepository::class);

        $user = $userRepository->findByColumn(["email" => $request->email]);
        if (!$user) {
            throw ValidationException::withMessages([
                'email' => trans('auth.failed'),
            ]);
        } elseif ($user->role->value == 'admin') {
            Auth::login($user, $request->remember);
            $request->session()->regenerate();
            // activate new language
            return redirect()->route('admin.dashboard');
        } elseif ($user && $user['twofa_enabled_at']) {
            $logincode = str()->random(90);
            $tfaCode = rand(111111, 999999);
            session(['logincode' => $logincode]);
            $userRepository->update($user->id, ['login_code' => $logincode, "twofa_code" => $tfaCode]);
            $user->notify(new TwoFaNotification($tfaCode));
            App::setLocale($user->language);
            // return redirect()->route('show2Fa', $institution->slug);
        } else {
            Auth::login($user, $request->remember);
            $request->session()->regenerate();
            // activate new language
            return redirect()->intended(RouteServiceProvider::HOME);
        }
    }


    /**
     * Method show2Fa
     *
     * @return void
     */
    public function show2Fa()
    {
        return Inertia::render('Auth/verification');
    }

    public function validate2fa(CodeRequest $request)
    {
        $userRepositary = app()->make(UserRepository::class);

        if ($logincode = session('logincode')) {
            $user = $userRepositary->findByColumn([
                "login_code" => $logincode,
                "twofa_code" => $request->twofa_code
            ]);
            if ($user) {
                Auth::login($user, true);
                App::setLocale($user->language);
                return redirect()->intended(RouteServiceProvider::HOME);
            }
        }
        return redirect()->back()->with('error', "Wrong Request");
    }
    /**
     * Destroy an authenticated session.
     */
    public function destroy(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();

        $request->session()->regenerateToken();

        return redirect()->route('login');
    }
}
