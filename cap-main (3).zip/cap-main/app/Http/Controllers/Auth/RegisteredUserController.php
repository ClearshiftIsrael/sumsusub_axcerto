<?php

namespace App\Http\Controllers\Auth;

use App\Enums\IsLoggedInEnum;
use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\SignUpRequest;
use App\Notifications\User\WelcomeNotification;
use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Auth\Events\Registered;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Inertia\Inertia;
use Inertia\Response;

class RegisteredUserController extends Controller
{
    protected $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository=$userRepository;
    }

    /**
     * Display the registration view.
     */
    public function create(): Response
    {
        return Inertia::render('Auth/Register');
    }

    /**
     * Handle an incoming registration request.
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    public function store(SignUpRequest $request): RedirectResponse
    {
        $data=$request->all();
        $data['password']=Hash::make($request->password);
        $data['is_logged_in']=IsLoggedInEnum::LoggedIn->value;
        $user=$this->userRepository->create($data);
        // Notify User with welcome
        $user->notify(new WelcomeNotification());
        event(new Registered($user));
        // Login
        Auth::login($user);
        // Redirect
        return redirect()->route('dashboard');
    }
}
