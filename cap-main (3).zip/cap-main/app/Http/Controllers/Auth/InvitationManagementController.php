<?php

namespace App\Http\Controllers\Auth;

use App\Enums\TeamInvitationStatusEnum;
use App\Enums\UserInvitationStatusEnum;
use App\Http\Controllers\Controller;
use App\Http\Requests\InvitationUserSubmitRequest;
use App\Repositories\Eloquent\Accounts\AccountsTeamRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Inertia\Inertia;

class InvitationManagementController extends Controller
{
    protected $accountsTeamRepository;
    protected $userRepository;
    public function __construct(
        AccountsTeamRepository $accountsTeamRepository,
        UserRepository $userRepository
    ) {
        $this->accountsTeamRepository = $accountsTeamRepository;
        $this->userRepository = $userRepository;
    }

    public function validateAccess(Request $request, String $code)
    {
        // Get Account
        $accountTeam = $this->accountsTeamRepository->findByColumn(['code' => $code]);
        // dd($accountTeam);
        //  get the user
        $user = $accountTeam->user;
        $account = $accountTeam->account;
        // Update the link
        $this->accountsTeamRepository->update(
            $accountTeam->id,
            [
                'invitation_status' => TeamInvitationStatusEnum::Clicked->value,
            ]
        );

        if (($user?->is_invited == UserInvitationStatusEnum::Yes->value)&&(!Auth::check())) {
            return Inertia::render('Auth/Invitation/Index', [
                'user' => $user,
                'code' => $code
            ]);
        }else{
            return redirect()->route('accounts.verification', $account->id);
        }
    }

    public function validateAccessUpdate(InvitationUserSubmitRequest $request, String $code)
    {
        // Get Account
        $accountTeam = $this->accountsTeamRepository->findByColumn(['code' => $code]);
        // user update
        $this->userRepository->updateWithMeta(
            $accountTeam->user->id,
            [
                'first_name' => $request->first_name,
                'last_name' => $request->last_name,
                'password' => Hash::make($request->password),
            ]
        );
        $user = $this->userRepository->findById($accountTeam->user->id);
        // Update the link
        $this->accountsTeamRepository->update(
            $accountTeam->id,
            [
                'invitation_status' => TeamInvitationStatusEnum::Expired->value
            ]
        );
        // login
        Auth::login($user);
        //
        return redirect()->route('accounts.verification', $accountTeam->account_id);
    }
}
