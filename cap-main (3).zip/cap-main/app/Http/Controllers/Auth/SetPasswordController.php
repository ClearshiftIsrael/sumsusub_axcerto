<?php

namespace App\Http\Controllers\Auth;

use App\Enums\IsLoggedInEnum;
use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\Rules;

class SetPasswordController extends Controller
{
    /**
     * @return [type]
     */
    public function store(Request $request)
    {
        $request->validate([
            'password' => ['required', 'confirmed', Rules\Password::defaults()],
        ]);
        $user = app()->make(UserRepository::class)->getUserByMd5Id($request->id);
        // $userId = Crypt::decryptString($request->id);
        // $user = app()->make(UserRepository::class)->findById($userId);
        $password = Hash::make($request->password);
        $user->update(['password' => $password, 'is_logged_in' => IsLoggedInEnum::LoggedIn->value]);
        // $user->sendEmailVerificationNotification();
        Auth::loginUsingId($user->id);
        Log::debug('CAP - user log in');

        return redirect()->intended(RouteServiceProvider::HOME);
    }
}
