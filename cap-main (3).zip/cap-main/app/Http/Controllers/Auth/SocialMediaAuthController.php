<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Laravel\Socialite\Facades\Socialite;

class SocialMediaAuthController extends Controller
{

    /**
     * openAuth
     *
     * @param  mixed $provider
     * @return mixed
     */
    public function openAuth($provider){
        return Socialite::driver($provider)->redirect();
    }

    /**
     * authenticate
     *
     * @param  mixed $provider
     * @return void
     */
    public function authenticate($provider){
        $googleUser = Socialite::driver($provider)->user();

        // seperate the name
        $nameArray = explode(" ",$googleUser->name);

        $user = User::updateOrCreate([
            'email' => $googleUser->email,
        ], [
            'provider_id' => $googleUser->id,
            'provider' => $provider,
            'first_name' => $nameArray[0],
            'last_name' => count($nameArray)>1?$nameArray[1]:"",
            'provider_token' => $googleUser->token,
            'provider_refresh_token' => $googleUser->refreshToken,
        ]);

        Auth::login($user);


        return redirect()->route('dashboard');

    }
}
