<?php

namespace App\Http\Controllers\AdminOnly\Applicant;

use App\Enums\AccountStatusEnum;
use App\Enums\UserNotifyEnum;
use App\Http\Controllers\Controller;
use App\Http\Requests\Applicant\AddApplicantRequest;
use App\Http\Requests\User\UserCreateRequest;
use App\Http\Requests\User\UserUpdateRequest;
use App\Http\Resources\Account\AccountResource;
use App\Http\Resources\Users\UserResource;
use App\Models\KycLevel;
use App\Notifications\User\WelcomeNotification;
use App\Repositories\Eloquent\Accounts\AccountsRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use App\Services\Accounts\AccountsService;
use App\Services\Accounts\NewApplicantService;
use Google\Service\Localservices\Resource\AccountReports;
use Illuminate\Http\Request;
use Inertia\Inertia;

class ApplicantController extends Controller
{
    protected $accountService;

    /**
     * @param AccountsRepository $accountRepository
     */
    public function __construct(
        protected AccountsRepository $accountRepository,
        protected AccountsService $AccountsService,
        protected NewApplicantService $newApplicantService
    ) {
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {

        $filters = $request->all('searchParam', 'sortBy', 'sortDirection', 'rowPerPage', 'page');
        $filters['sortBy'] = $filters['sortBy'] ?? 'id';
        $filters['sortDirection'] = $filters['sortDirection'] ?? 'desc';
        $filters['rowPerPage'] = $filters['rowPerPage'] ?? 10;
        $filters['site'] = 'admin';

        return Inertia::render('Applicants/All/ApplicantIndex', [
            'filters' => $filters,
            'accounts' => AccountResource::collection($this->accountRepository->filter($filters)),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return Inertia::render('Applicants/Create/ApplicantCreateIndex', [
            'levels' => KycLevel::selectRaw('id as value, CONCAT(name, " ", "(", UPPER(level_type), ")") as label, level_type')->get(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(UserCreateRequest $request)
    {
        $data = $request->all();
        $data['notify_status'] = UserNotifyEnum::Send->value;
        $user = $this->accountRepository->create($data);
        $user->refresh();
        $user->notify(new WelcomeNotification());

        return redirect()->route('applicants.index')->with('success', __('users.alerts.create.success'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        return Inertia::render('Applicants/Edit/ApplicantEditIndex', [
            'account' => new AccountResource($this->accountRepository->findById($id, ['*'], ['users'])),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $this->accountRepository->update($id, $request->all());
        // if (($request->status == 'active') && ($request->delete == 'inactive')) {
        //     $this->accountRepository->restoreById($id);
        // } elseif (($request->status == 'inactive') && ($request->delete == 'active')) {
        //     $this->accountRepository->deleteById($id);
        // }

        return redirect()->route('applicants.index')->with('success', __('users.alerts.edit.success'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $this->accountRepository->deleteById($id);

        return redirect()->route('applicants.index')->with('success', __('users.alerts.delete.success'));
    }

    /**
     * @param AddApplicantRequest $request
     *
     * @return [type]
     */
    public function addApplicant(AddApplicantRequest $request)
    {
        if ($this->accountService->addAccountUser($request->all())) {
            return redirect()->route('applicants.index')->with('success', __('users.alerts.add.success'));
        }
        return redirect()->route('applicants.index')->with('error', __('users.alerts.add.error'));
    }
    /**
     * changeKey
     *
     * @param  mixed $request
     * @param  mixed $id
     * @return void
     */
    public function changeKey(Request $request, int $id)
    {
        $account = $this->accountRepository->findById($id);
        $this->newApplicantService->chnageTheExternalId($account);
    }
    /**
     * @return [type]
     */
    public function permanentDelete(string $id)
    {
        $this->accountRepository->DeleteById($id);

        return redirect()->route('applicants.index')->with('success', __('users.alerts.delete.success'));
    }

    /**
     * @return [type]
     */
    public function restore(string $id)
    {
        $this->accountRepository->restoreById($id);

        return redirect()->route('applicants.index')->with('success', 'User restored successful');
    }
}
