<?php

namespace App\Http\Controllers\AdminOnly\User;

use App\Enums\IsKYCDefaultEnum;
use App\Enums\IsLoggedInEnum;
use App\Enums\KYCAdminStatusEnum;
use App\Enums\KYCLevelTypeEnum;
use App\Enums\UserNotifyEnum;
use App\Enums\UserTypeEnum;
use App\Http\Controllers\Controller;
use App\Http\Requests\User\UserCreateRequest;
use App\Http\Requests\User\UserUpdateRequest;
use App\Http\Resources\Users\UserResource;
use App\Models\KycLevel;
use App\Notifications\User\WelcomeNotification;
use App\Repositories\Eloquent\Business\BusinessRepository;
use App\Repositories\Eloquent\KycLevel\KycLevelRepository;
use App\Repositories\Eloquent\Users\KycInfoRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use App\Services\User\KycService;
use App\Services\User\UserService;
use Illuminate\Http\Request;
use Inertia\Inertia;

class UserController extends Controller
{
    protected $userRepository;

    public function __construct(UserRepository $userRepository)
    {
        $this->userRepository = $userRepository;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {

        $filters = $request->all('searchParam', 'sortBy', 'sortDirection', 'rowPerPage', 'page');
        $filters['sortBy'] = $filters['sortBy'] ?? 'id';
        $filters['sortDirection'] = $filters['sortDirection'] ?? 'desc';
        $filters['rowPerPage'] = $filters['rowPerPage'] ?? 10;
        $filters['role'] = $filters['role'] ?? ['customer'];
        $filters['type'] = $request->type ?? 'all';

        return Inertia::render('User/All/UserIndex', [
            'filters' => $filters,
            'users' => UserResource::collection($this->userRepository->filter($filters,['accounts'])),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return Inertia::render('User/Create/UserCreateIndex', [
            'levels' => KycLevel::selectRaw('id as value, CONCAT(name, " ", "(", UPPER(level_type), ")") as label, level_type')->get(),
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(UserCreateRequest $request)
    {
        $data = $request->all();        
        $data['notify_status'] = UserNotifyEnum::Send->value;
        $user = $this->userRepository->create($data);
        $user->refresh();
        $user->notify(new WelcomeNotification());

        return redirect()->route('users.index')->with('success', __('users.alerts.create.success'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        return Inertia::render('User/Edit/UserEditIndex', [
            'user' => new UserResource($this->userRepository->findTrashedById($id, ['*'], ['accounts'])),
        ]);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UserUpdateRequest $request, string $id)
    {
        $this->userRepository->updateWithTrashed($id, $request->all());
        if (($request->status == 'active') && ($request->delete == 'inactive')) {
            $this->userRepository->restoreById($id);
        } elseif (($request->status == 'inactive') && ($request->delete == 'active')) {
            $this->userRepository->deleteById($id);
        }

        return redirect()->route('users.index')->with('success', __('users.alerts.edit.success'));
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $this->userRepository->deleteById($id);

        return redirect()->route('users.index')->with('success', __('users.alerts.delete.success'));
    }

    /**
     * @return [type]
     */
    public function permanentDelete(string $id)
    {
        $this->userRepository->permanentlyDeleteById($id);

        return redirect()->route('users.index')->with('success', __('users.alerts.delete.success'));
    }

    /**
     * @return [type]
     */
    public function restore(string $id)
    {
        $this->userRepository->restoreById($id);

        return redirect()->route('users.index')->with('success', 'User restored successful');
    }
}
