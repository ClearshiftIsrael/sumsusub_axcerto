<?php

namespace App\Http\Controllers\AdminOnly\Kyc;

use App\Enums\KYCLevelTypeEnum;
use App\Http\Controllers\Controller;
use App\Http\Traits\UtilityTrait;
use App\Repositories\Eloquent\KycLevel\KycLevelRepository;
use App\Services\KycLevel\KycLevelService;
use Illuminate\Http\Request;
use Inertia\Inertia;

class KycLevelController extends Controller
{
    use UtilityTrait;

    protected $kycLevelRepository;

    public function __construct()
    {
        $this->kycLevelRepository = app()->make(KycLevelRepository::class);
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $filters = $request->all('searchParam', 'sortBy', 'sortDirection', 'rowPerPage', 'page');
        $filters['sortBy'] = $filters['sortBy'] ?? 'id';
        $filters['sortDirection'] = $filters['sortDirection'] ?? 'desc';
        $filters['rowPerPage'] = $filters['rowPerPage'] ?? 10;

        return Inertia::render('KycLevel/All/KycLevelAllIndex', [
            'filters' => $filters,
            'levels' => $this->kycLevelRepository->filter($filters),
            'types' => $this->enumToSelect(KYCLevelTypeEnum::cases()),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $this->kycLevelRepository->create($request->all());

        return redirect()->route('kyc-levels.index')->with('success', 'KYC Level create successful');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        if (empty($request->all())) {
            app()->make(KycLevelService::class)->statusUpdate($id);
        } else {
            $this->kycLevelRepository->update($id, $request->all());
        }

        return redirect()->route('kyc-levels.index')->with('success', 'KYC Level update successful');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $this->kycLevelRepository->deleteById($id);

        return redirect()->route('kyc-levels.index')->with('success', 'KYC Level create successful');
    }
}
