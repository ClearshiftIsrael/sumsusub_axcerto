<?php

namespace App\Http\Controllers\AdminOnly\Dashboard;

use App\Enums\KYCStatusEnum;
use App\Http\Controllers\Controller;
use App\Repositories\Eloquent\Users\KycInfoRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use Inertia\Inertia;

class AdminDashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $userRepo = app()->make(UserRepository::class);
        $userKycRepo = app()->make(KycInfoRepository::class);
        $users = [
            'totalUsers' => $userRepo->getCount(),
            'pending' => $userKycRepo->getCount(['status' => KYCStatusEnum::Pending->value]),
            'declined' => $userKycRepo->getCount(['status' => KYCStatusEnum::Declined->value]),
        ];

        return Inertia::render('Dashboard', [
            'users' => $users,
        ]);
    }
}
