<?php

namespace App\Http\Controllers\AdminOnly\Questionary;

use App\Http\Controllers\Controller;
use App\Http\Resources\Questionary\QuestionaryResource;
use App\Http\Traits\UtilityTrait;
use App\Repositories\Eloquent\Questionary\QuestionaryRepository;
use App\Services\Questionary\QuestionaryService;
use Illuminate\Http\Request;
use Inertia\Inertia;

class QuestionaryController extends Controller
{
    use UtilityTrait;

    protected $questionaryRepository;

    public function __construct()
    {
        $this->questionaryRepository = app()->make(QuestionaryRepository::class);
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $filters = $request->all('searchParam', 'sortBy', 'sortDirection', 'rowPerPage', 'page');
        $filters['sortBy'] = $filters['sortBy'] ?? 'id';
        $filters['sortDirection'] = $filters['sortDirection'] ?? 'desc';
        $filters['rowPerPage'] = $filters['rowPerPage'] ?? 10;

        return Inertia::render('Questionnaire/All/QuestionnaireAllIndex', [
            'filters' => $filters,
            'questionary' => QuestionaryResource::collection($this->questionaryRepository->filter($filters)),
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $this->questionaryRepository->create($request->all());

        return redirect()->route('questionnaire.index')->with('success', 'Questionary Create Successful.');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $this->questionaryRepository->update($id, $request->all());

        return redirect()->back()->with('success', 'Questionary Update Successful.');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $this->questionaryRepository->deleteById($id);

        return redirect()->back()->with('success', 'Questionary Delete Successful.');

    }

    /**
     * @return [type]
     */
    public function importQuestionary(Request $request)
    {
        $questionService = app()->make(QuestionaryService::class);
        $questionService->store($request->all()['array']);

        return redirect()->back()->with('success', 'Questionary Added Successful.');
    }
}
