<?php

namespace App\Http\Controllers\AdminOnly;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Artisan;

class DownloadController extends Controller
{
    /**
     * @return [type]
     */
    public function index(int $userId)
    {
        // $user =  app()->make(UserRepository::class)->findById($userId);
        // app()->make(UserExportService::class)->downloadUserData($user);

        try {
            // Run the DownloadsPrepareCommand using Artisan::call
            Artisan::call('prepare:downloads');

            // Get the output of the command (optional)
            $output = Artisan::output();

            // You can do something with the output, such as logging it or returning it as needed
            return $output;
        } catch (\Exception $e) {
            // Handle any exceptions that may occur during command execution
            // Log or report the exception as needed
            return $e->getMessage(); // Return an error message or handle the error appropriately
        }
    }
}
