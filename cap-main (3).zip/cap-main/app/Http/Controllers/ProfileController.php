<?php

namespace App\Http\Controllers;

use App\Repositories\Eloquent\Users\UserRepository;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules;
use Inertia\Inertia;
use Inertia\Response;

class ProfileController extends Controller
{
    /**
     * Display the user's profile form.
     */
    public function index(): Response
    {
        return Inertia::render('Profile/ProfileIndex');
    }

    /**
     * Update the user's profile information.
     */
    public function update(Request $request): RedirectResponse
    {
        if ($request->privacy == 'true') {
            $request->validate([
                'password' => ['required', 'confirmed', Rules\Password::defaults()],
            ]);
        } else {
            $request->validate([
                'first_name' => ['required', 'string', 'max:200'],
                'last_name' => ['required', 'string', 'max:200'],
                'email' => ['email', 'required', 'string', 'max:200', Rule::unique('users')->ignore(Auth::id())],
            ]);
        }
        app()->make(UserRepository::class)->update(auth()->id(), $request->all());

        return redirect()->back()->with('success', 'Profile Update successful.');
    }
    /**
     * Method updateTwoFa
     *
     * @param ProfileUpdateRequest $request [explicite description]
     * @param $institution $institution [explicite description]
     *
     * @return RedirectResponse
     */
    public function updateTwoFa(Request $request): RedirectResponse
    {
        $repository = app()->make(UserRepository::class);
        $repository->update($request->user()->id, [
            'twofa_enabled_at' => $request->twofa_enabled_at == "true" ? Carbon::now() : null
        ]);
        return redirect()->back()->with('success', 'Profile Update successful.');
    }

    /**
     * Delete the user's account.
     */
    public function profileDelete(Request $request): RedirectResponse
    {
        $request->validate([
            'password' => ['required', 'current_password'],
        ]);

        $user = $request->user();
        Auth::logout();

        $user->delete();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return Redirect::to('/');
    }
}
