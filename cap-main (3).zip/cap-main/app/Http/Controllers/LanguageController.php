<?php

namespace App\Http\Controllers;

use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LanguageController extends Controller
{
    /**
     * @param  mixed  $language
     * @return [type]
     */
    public function setLanguage(Request $request, $language)
    {
        Session()->put('locale', $language);
        if (Auth::check()) {
            $userRepository = app()->make(UserRepository::class);
            $userRepository->update(Auth::user()->id, [
                'language' => $language,
            ]);

            setcookie('locale', $language, time() + (86400 * 180), '/');
        }

        return redirect()->back();
    }
}
