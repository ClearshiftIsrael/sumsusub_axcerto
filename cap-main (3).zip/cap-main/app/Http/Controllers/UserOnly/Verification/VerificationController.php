<?php

namespace App\Http\Controllers\UserOnly\Verification;

use App\Http\Controllers\Controller;
use App\Repositories\Eloquent\Users\KycInfoRepository;
use App\Services\User\KycService;
use Inertia\Inertia;

class VerificationController extends Controller
{
    /**
     * Method index ------> web
     *
     * @return 
     */
    public function index()
    {
        $kycInfoRepo = app()->make(KycInfoRepository::class);
        $status = $kycInfoRepo->findByColumn(['user_id' => auth()->id()])?->admin_status->value;
        $kycService = app()->make(KycService::class);

        return Inertia::render(
            'Customer/KYCIndex',
            [
                'kycData' => $kycService->getSdkRelatedData(),
                'adminStatus' => $status,
            ]
        );
    }

    /**
     * @param  mixed  $id
     * @return [type]
     */
    public function refetchUserData($id)
    {
        $kycService = app()->make(KycService::class);
        $kycService->updateUserDataFromKyc($id);

        return redirect()->back()->with('success', 'User refetch successful.');
    }

    /**
     * Method getNewToken ---> API
     *
     * @return void
     */
    public function getNewToken()
    {
        if (auth()->user()) {
            $kycService = app()->make(KycService::class);

            return response()->json($kycService->getNewToken(), 200);
        }
    }
}
