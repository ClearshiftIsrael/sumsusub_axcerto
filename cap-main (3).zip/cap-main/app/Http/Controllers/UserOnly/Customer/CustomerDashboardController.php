<?php

namespace App\Http\Controllers\UserOnly\Customer;

use App\Http\Controllers\Controller;
use App\Repositories\Eloquent\Accounts\AccountsTeamRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class CustomerDashboardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        return Inertia::render('Customer/Dashboard/Index',[
            'dashboardData' => $this->dashboardData()
        ]);
    }
    /**
     * @return [type]
     */
    public function dashboardData()
    {
        $auth_user = app()->make(UserRepository::class)->findById(Auth::user()->id,['*'],['individualAccounts']);
        // dd($auth_user);
        app()->make(AccountsTeamRepository::class)->getByColumn(['user_id' => $auth_user->id]);
        $total_accounts = $auth_user?->active_accounts_count;
        $individual_accounts = $auth_user?->individualAccounts->count();
        return [
            'total_accounts' => $total_accounts,
            'individual_accounts' =>  $individual_accounts,
            'business_accounts' => $total_accounts - $individual_accounts,
        ];
    }
}
