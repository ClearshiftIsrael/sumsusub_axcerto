<?php

namespace App\Http\Controllers\UserOnly\Accounts;

use App\Http\Controllers\Controller;
use App\Repositories\Eloquent\Accounts\AccountsRepository;
use App\Repositories\Eloquent\Accounts\AccountsTeamRepository;
use App\Services\Accounts\AccountsService;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class AccountsVerificationController extends Controller
{
    protected $accountsRepository;
    protected $accountsTeamRepository;
    protected $accountsService;

    public function __construct(
        AccountsRepository $accountsRepository,
        AccountsTeamRepository $accountsTeamRepository,
        AccountsService $accountsService
        )
    {
        $this->accountsRepository = $accountsRepository;
        $this->accountsTeamRepository=$accountsTeamRepository;
        $this->accountsService=$accountsService;
    }
    /**
     * Display a listing of the resource.
     */
    public function index(int $id)
    {
        $account = $this->accountsRepository->findById($id,['*'],['users']);
        if($account){
            if($account = $this->accountsRepository->getAccount($id, Auth::id(), ['users'])){
                return Inertia::render('Customer/Accounts/KYC/Index',[
                    'account' => $account,
                    "verificationData"=>$this->accountsService->getSdkRelatedData($account),
                    'adminStatus'=>""
                ]);
            }else{
                return redirect(route('dashboard'))->with('error', 'You are currently logged in to a different account. Please log out first and then try again.');
            }
        }else{
            return abort(404);
        }
    }
    /**
     * getNewToken
     *
     * @param  mixed $id
     * @return void
     */
    public function getNewToken($id){
        $account = $this->accountsRepository->getAccount($id, Auth::id(),['users']);
        return response()->json($this->accountsService->getAccessToken($account), 200);
    }
}
