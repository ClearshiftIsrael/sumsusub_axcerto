<?php

namespace App\Http\Controllers\UserOnly\Accounts;

use App\Enums\AccountStatusEnum;
use App\Enums\AccountTeamRoleEnum;
use App\Enums\AccountTypeEnum;
use App\Enums\KYCLevelStatusEnum;
use App\Enums\KYCLevelTypeEnum;
use App\Http\Controllers\Controller;
use App\Http\Requests\Account\NewuserAssignRequest;
use App\Http\Resources\Accounts\AccountsResource;
use App\Http\Traits\UtilityTrait;
use App\Models\Account;
use App\Repositories\Eloquent\Accounts\AccountsRepository;
use App\Repositories\Eloquent\Accounts\AccountsTeamRepository;
use App\Repositories\Eloquent\KycLevel\KycLevelRepository;
use App\Services\Accounts\AccountInvitationService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Inertia\Inertia;
use Illuminate\Support\Str;

class AccountsManagementController extends Controller
{
    use UtilityTrait;

    protected $accountsRepository;
    protected $accountsTeamRepository;
    protected $kycLevelRepository;
    protected $accountInvitationService;

    public function __construct(
        AccountsRepository $accountsRepository,
        AccountsTeamRepository $accountsTeamRepository,
        KycLevelRepository $kycLevelRepository,
        AccountInvitationService $accountInvitationService
    ) {
        $this->accountsRepository = $accountsRepository;
        $this->accountsTeamRepository = $accountsTeamRepository;
        $this->kycLevelRepository = $kycLevelRepository;
        $this->accountInvitationService = $accountInvitationService;
    }
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $filters = $request->all('searchParam', 'sortBy', 'sortDirection', 'rowPerPage', 'page');
        $filters['sortBy'] = $filters['sortBy'] ?? 'id';
        $filters['sortDirection'] = $filters['sortDirection'] ?? 'desc';
        $filters['rowPerPage'] = $filters['rowPerPage'] ?? 10;
        $filters['role'] = $filters['role'] ?? ['customer'];
        $filters['type'] = $request->type ?? 'all';

        return Inertia::render('Customer/Accounts/All/Index', [
            'filters' => $filters,
            'accounts' => AccountsResource::collection($this->accountsRepository->filter($filters))
        ]);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $account = $this->accountsRepository->findByColumn(['status' => AccountStatusEnum::Draft->value]);
        if (!$account) {
            $account = $this->accountsRepository->create([
                'name' => "",
                'status' => AccountStatusEnum::Draft->value
            ]);
            // create the manager
            $this->accountsTeamRepository->create([
                'user_id' => Auth::id(),
                'account_id' => $account->id,
                'role' => AccountTeamRoleEnum::Owner->value,
                'code' =>  Str::random(100)
            ]);
        }
        // $account->fresh()->with('users');
        $account = $this->accountsRepository->findByColumn(['id' => $account->id], ['*'], ['users']);
        return Inertia::render('Customer/Accounts/Edit/Index', $this->formData($account, "create"));
    }

    /**
     * Store a newly created resource in storage.
     */
    protected function formData(Account $account = null, $type)
    {
        return [
            'account' => $account,
            'type' => $type,
            'accountStatus' => $this->enumToSelect(AccountStatusEnum::cases()),
            'roles' => $this->enumToSelect(AccountTeamRoleEnum::cases()),
            'accTypes' => [
                ['value' => AccountTypeEnum::Individual->value, 'label' => AccountTypeEnum::Individual->name],
                // ['value' => AccountTypeEnum::Business->value, 'label' => AccountTypeEnum::Business->description]
            ],
            // 'accTypes' => $this->enumToSelect(AccountTypeEnum::cases()),
            // 'verificationLevels' => $this->kycLevelRepository->getByColumn(['status' => KYCLevelStatusEnum::Active->value], ['key as value', 'name as label'])
        ];
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(int $id)
    {
        $account = $this->accountsRepository->getAccount($id, Auth::id(), ['users']);

        return Inertia::render('Customer/Accounts/Edit/Index', $this->formData($account, "edit"));
    }

    /**
     * Update the specified resource in storage.
     */
    public function updateData(Request $request, string $id)
    {
        $data = $request->all();
        try {
            $data['verification_level']  = $this->kycLevelRepository->findByColumn(['status' => KYCLevelStatusEnum::Active->value, 'level_type' => KYCLevelTypeEnum::KYC->value, 'default' => 'yes'])->key;
            if ($data['type'] == AccountTypeEnum::Business->value) {
                $data['verification_level'] = $this->kycLevelRepository->findByColumn(['status' => KYCLevelStatusEnum::Active->value, 'level_type' => KYCLevelTypeEnum::KYB->value, 'default' => 'yes'])->key;
            }
            $account= $this->accountsRepository->findById($id);

            if($account->status->value== AccountStatusEnum::Draft->value){
                $data['status'] = AccountStatusEnum::Active->value;
            }
            $this->accountsRepository->updateWithMeta($id, $data);

            if ($data['ui']=="edit") {
                return redirect(route('accounts.index'))->with('success', "Account Updated successfully");
            }else{
                return redirect(route('accounts.verification', $id))->with('success', "Account Created successfully");
            }
        } catch (\Throwable $th) {
           return redirect()->back()->with('error', 'Something went wrong, contact system admin');
           Log::error("please add default level for KYC & KYB level");
        }
    }


    /**
     * @param NewuserAssignRequest $request
     *
     * @return [type]
     */
    public function addUser(NewuserAssignRequest $request)
    {
        $this->accountInvitationService->invite($request->all(), $request->accountId);
        return redirect(route('accounts.edit', $request->accountId))->with('success', 'User invitation sent successfully');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
