<?php

namespace App\Http\Requests\User;

use App\Rules\User\BusinessCheckRule;
use Illuminate\Foundation\Http\FormRequest;

class UserUpdateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        $userId = $this->route('user');

        return [
            'first_name' => ['required', 'max:150', 'min:2'],
            'last_name' => ['required', 'max:150', 'min:2'],
            'email' => ['required', 'max:150', 'min:2', 'email', 'unique:users,email,'.$userId],
        ];
    }
}
