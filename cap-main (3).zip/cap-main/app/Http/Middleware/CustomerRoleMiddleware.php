<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Inertia\Inertia;

class CustomerRoleMiddleware
{
    /**
     * Method handle
     *
     * @param  Request  $request [explicite description]
     * @param  Closure  $next [explicite description]
     * @return void
     */
    public function handle(Request $request, Closure $next)
    {
        $user = Auth::user();
        if ($user && $user->role->value == 'customer') {
            return $next($request);
        }

        return Inertia::render('Error/Index', [
            'status' => 401,
            'statusText' => 'Unauthorized',
            'message' => 'You are not authorized to access this page.',

        ]);
    }
}
