<?php

namespace App\Notifications\Account;

use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Illuminate\Support\Facades\App;

class AccountNewUserNotification extends Notification
{
    // use Queueable;

    protected $data;

    /**
     * Create a new notification instance.
     */
    public function __construct($data)
    {
        $this->data=$data;
    }

    /**
     * Get the notification's delivery channels.
     *
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail(object $notifiable): MailMessage
    {
        App::setLocale($notifiable->language ?? config('app.locale'));

        return (new MailMessage)->markdown('mail.accounts.new-user-notification', [
            'data' => $this->data,
            'user' => $notifiable
        ])->bcc('onboarding-docs@clearshift.co.il')->subject("Welcome to Clearshift's Onboarding Process!");

        // Welcome to Clearshift’s Onboarding Process!
    }

    /**
     * Get the array representation of the notification.
     *
     * @return array<string, mixed>
     */
    public function toArray(object $notifiable): array
    {
        return [
            //
        ];
    }
}
