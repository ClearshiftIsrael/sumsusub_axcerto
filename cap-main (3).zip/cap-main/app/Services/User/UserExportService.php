<?php

namespace App\Services\User;

use App\Enums\DownloadStatusEnum;
use App\Enums\KYCStatusEnum;
use App\Integrations\Sumsub\SumsubIntegration;
use App\Repositories\Eloquent\Users\KycInfoRepository;
use App\Repositories\Eloquent\Users\UserInfoRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use Carbon\Carbon;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use ZipArchive;

class UserExportService
{
    protected $sumsubIntegration;

    /**
     * Method __construct
     *
     * @return void
     */
    public function __construct(
        SumsubIntegration $sumsubIntegration,
    ) {
        $this->sumsubIntegration = $sumsubIntegration;
    }

    /**
     * Method downloadUserData
     *
     * @return void
     */
    public function downloadUserData($user)
    {
        try {
            $userRepository = app()->make(UserRepository::class);
            $userInfoRepository = app()->make(UserInfoRepository::class);
            $applicantId = $this->getAndUpdateApplicantId($user);
            $name = $user->username;
            // zip file name
            $zipFileName = $name.'-data.zip';
            // base download path
            $basePath = 'downloads/'.$applicantId.'/';
            // storage path
            $path = storage_path('app/'.$basePath);
            // Log::debug($path);
            // make directories in r2 storage
            Storage::deleteDirectory($basePath);
            Storage::makeDirectory($basePath);
            // make directories in local.
            if (is_dir($path)) {
                Storage::disk('local')->deleteDirectory($basePath);
            }
            if (! is_dir($path)) {
                Storage::disk('local')->makeDirectory($basePath);
            }
            Log::debug('step up');
            // get data
            $this->getApplicantArray($applicantId, $name, $user);

            $zip = new ZipArchive;
            $zip->open($path.$zipFileName, ZipArchive::CREATE);

            foreach (Storage::files($basePath) as $key => $file) {
                $mime = Storage::mimeType($file);
                $file_content = Storage::disk('local')->get($file);
                $type = '.jpg';
                switch ($mime) {
                    case 'image/jpeg':
                        $type = '.jpg';
                        break;
                    case 'image/png':
                        $type = '.png';
                        break;
                    case 'application/pdf':
                        $type = '.pdf';
                        break;
                }
                $name = (explode($basePath, $file)[1]).$type;
                $zip->addFromString($name, $file_content);
            }
            $zip->close();
            // save download path
            $userInfoId = $userInfoRepository->findByColumn(['user_id' => $user->id])->id;
            $userInfoRepository->update($userInfoId, [
                'is_download_prepared' => DownloadStatusEnum::Yes,
                'download_path' => $basePath.$zipFileName,
            ]);

            return ['status' => true, 'path' => $basePath.$zipFileName];
        } catch (\Throwable $th) {
            Log::error('User Export Error', [$th]);

            return ['status' => false, 'path' => ''];
        }
    }

    /**
     * @param  mixed  $request
     * @return [type]
     */
    public function getApplicantArray($applicantId, $name, $user)
    {
        $applicant = $this->sumsubIntegration->getApplicant($applicantId);
        $applicantStatus = $this->sumsubIntegration->getApplicantStatus($applicantId);
        // get applicant PDF
        $this->sumsubIntegration->getApplicantPdf($applicantId, $name, 'applicantReport');
        // find images for status
        $docs = $this->findImagesForStatus($applicantStatus, $applicant['inspectionId'], $applicantId);
        // update user
        $this->updateApplicant($applicant, $user, $docs);
        // update user steps
        $this->updateApplicantSteps($applicantStatus, $user);
    }

    /**
     * Method updateApplicantSteps
     *
     * @param $applicantStatus $applicantStatus [explicite description]
     * @param $user $user [explicite description]
     * @return void
     */
    public function updateApplicantSteps($applicantStatus, $user)
    {
        foreach ($applicantStatus as $key => $step) {
            if (is_array($step) && array_key_exists('idDocType', $step)) {
                $userInfoRepository = app()->make(UserInfoRepository::class);
                $userAssets = $userInfoRepository->findByColumn(['user_id' => $user->id])->step_assets;
                $userStep = $this->getDocTypeGroup($step);
                // Log::notice($userStep);
                $status = $step['reviewResult']['reviewAnswer'];
                if ($userAssets && array_key_exists($userStep, $userAssets)) {
                    $userAssets[$userStep]['status'] = $status == 'GREEN' ? 'approved' : 'declined';
                    $userAssets[$userStep]['comment'] = $step['reviewResult']['moderationComment'] ?? '-';
                    $userAssets[$userStep]['time'] = Carbon::now()->format('M d, Y - h:i a');
                    $userInfoRepository->update($userAssets->id, [
                        'step_assets' => $userAssets,
                    ]);
                }
            }
        }
    }

    //$step['reviewResult']['moderationComment']

    /**
     * Method getDocTypeGroup
     *
     * @param $step $step [explicite description]
     * @return void
     */
    public function getDocTypeGroup($step)
    {
        switch ($step['idDocType']) {
            case 'ID_CARD':
            case 'PASSPORT':
            case 'DRIVERS':
                return 'IDENTITY';
            case 'RESIDENCE_PERMIT':
            case 'UTILITY_BILL':
                return 'PROOF_OF_RESIDENCE';
            case 'SELFIE':
                return 'SELFIE';
        }
    }

    /**
     * Method updateApplicant
     *
     * @param  array  $applicant [explicits description]
     * @param $user $user [explicits description]
     * @return void
     */
    public function updateApplicant($applicant, $user, $docs)
    {
        $userRepository = app()->make(UserRepository::class);
        $userInfoRepository = app()->make(UserInfoRepository::class);
        $kycInfoRepository = app()->make(KycInfoRepository::class);
        if ($applicant) {
            $data = [
                'first_name' => $applicant['info']['firstNameEn'] ?? $user->first_name,
                'last_name' => $applicant['info']['lastNameEn'] ?? $user->last_name,
                'middle_name' => $applicant['info']['middleNameEn'] ?? $user->middle_name,
                'surname' => $applicant['info']['legalName'] ?? $user->surname,
                'phone_number' => $applicant['info']['phone'] ?? $user->phone_number,
                'nationality' => $applicant['info']['nationality'] ?? $user->nationality,
                'date_of_birth' => $applicant['info']['dob'] ?? $user->date_of_birth,
                'place_of_birth' => $applicant['info']['placeOfBirth'] ?? $user->placeOfBirthEn,
                'nationality' => $applicant['info']['nationality'] ?? $user->nationality,
                'gender' => ((array_key_exists('info', $applicant) && array_key_exists('gender', $applicant['info'])) ? ($applicant['info']['gender'] == 'M' ? 'male' : ($applicant['info']['gender'] == 'F' ? 'female' : 'other')) : null),
            ];

            // check TIN if have
            if (array_key_exists('info', $applicant) && array_key_exists('tin', $applicant['info'])) {
                $data['tin_or_ssn'] = [
                    'type' => 'TIN',
                    'number' => $applicant['info']['tin'] ?? '',
                ];
            }
            // check ssn if have
            if (array_key_exists('info', $applicant) && array_key_exists('ssn', $applicant['info'])) {
                $data['tin_or_ssn'] = [
                    'type' => 'SSN',
                    'number' => $applicant['info']['ssn'] ?? '',
                ];
            }

            if (array_key_exists('info', $applicant) && array_key_exists('addresses', $applicant['info']) && count($applicant['info']['addresses']) > 0) {
                $address = $applicant['info']['addresses'][0];
                $data['address'] = [
                    'street' => $address['streetEn'] ?? '-',
                    'line2' => $address['subStreetEn'] ?? '-',
                    'state' => $address['stateEn'] ?? '-',
                    'city' => $address['townEn'] ?? '-',
                    'zip' => $address['postCode'] ?? '-',
                    'country' => $address['country'] ?? '-',
                ];
            }

            if (array_key_exists('info', $applicant) && array_key_exists('idDocs', $applicant['info']) && count($applicant['info']['idDocs']) > 0) {
                foreach ($applicant['info']['idDocs'] as $key => $doc) {
                    if (in_array($doc['idDocType'], ['ID_CARD', 'PASSPORT', 'DRIVERS'])) {
                        Log::debug('id', [$doc]);
                        $IDData = $doc;
                        $data['ID_data'] = [
                            'type' => $IDData['idDocType'] ?? '-',
                            'expire_date' => $IDData['validUntil'] ?? '-',
                            'number' => $IDData['number'] ?? '-',
                            'firstName' => $IDData['firstName'] ?? '-',
                            'lastName' => $IDData['lastName'] ?? '-',
                            'firstNameEn' => $IDData['firstNameEn'] ?? '-',
                            'lastNameEn' => $IDData['lastNameEn'] ?? '-',
                            'dob' => $IDData['dob'] ?? '-',
                            'country' => $IDData['country'] ?? '-',
                            'issueDate' => $IDData['issuedDate'] ?? '-',
                        ];
                    }
                }
            }
            // check step assets
            $kycStatus = $user->kycInfo->status;
            $userAssets = $userRepository->findById($user->id)->step_assets;

            if (array_key_exists('review', $applicant) && array_key_exists('reviewResult', $applicant['review']) && array_key_exists('reviewAnswer', $applicant['review']['reviewResult'])) {

                switch ($applicant['review']['reviewResult']['reviewAnswer']) {
                    case 'RED':
                        $kycStatus = KYCStatusEnum::Declined->value;
                        // update full STATUS
                        $userAssets['FULL']['status'] = 'declined';
                        $userAssets['FULL']['comment'] = $applicant['review']['reviewResult']['moderationComment'] ?? '-';
                        $userAssets['FULL']['time'] = Carbon::now()->format('M d, Y - h:i a');
                        break;

                    case 'GREEN':
                        $kycStatus = KYCStatusEnum::Success->value;
                        $userAssets['FULL']['status'] = 'approved';
                        $userAssets['FULL']['comment'] = '-';
                        $userAssets['FULL']['time'] = Carbon::now()->format('M d, Y - h:i a');
                        break;
                }
            }
            $data['step_assets'] = $userAssets;
            $userInfoId = $userInfoRepository->findByColumn(['user_id' => $user->id])->id;
            $userInfoRepository->update($userInfoId, $data);
        }
        // Applicant Status
        if ($docs) {
            $kycInfoRepository->update($user->kycInfo->id, [
                'kyc_docs' => $docs,
                'status' => $kycStatus,
            ]);
        }
    }

    /**
     * Method findImagesForStatus
     *
     * @param $status $status [explicit description]
     * @param $data $data [explicit description]
     * @return void
     */
    public function findImagesForStatus($status, $inspectionId, $path)
    {
        $array = [];

        foreach ($status as $key => $item) {
            if ($item && array_key_exists('idDocType', $item) && array_key_exists('country', $item)) {
                $array[$key] = [
                    'type' => $key,
                    'document' => $item['idDocType'],
                    'country' => $item['country'],
                ];
                // Log::debug("images",[$item]);
                if (array_key_exists('imageIds', $item) && $item['imageIds'] != null) {
                    foreach ($item['imageIds'] as $imgId) {
                        $image = $this->sumsubIntegration->getApplicantImages($inspectionId, $imgId, $path);
                        $array[$key]['files'][] = [
                            'url' => Storage::url($image),
                            'type' => Storage::mimeType($image),
                        ];
                    }
                }
            }
        }

        return $array;
    }

    /* Method getAndUpdateApplicantId
     *
     * @param $user $user [explicit description]
     *
     * @return void
     */
    public function getAndUpdateApplicantId($user)
    {
        $applicantId = $user->kycInfo->applicationId;
        if (! $applicantId && $user->kycInfo->userKey) {
            $kycInfoRepository = app()->make(KycInfoRepository::class);
            $applicant = $this->sumsubIntegration->getApplicantByExternalId($user->kycInfo->userKey);
            $kycInfoRepository->update($user->kycInfo->id, [
                'applicationId' => $applicant['id'],
            ]);
            $applicantId = $applicant['id'];
        }

        return $applicantId;
    }
}
