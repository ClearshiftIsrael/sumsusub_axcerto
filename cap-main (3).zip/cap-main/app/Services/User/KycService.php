<?php

namespace App\Services\User;

use App\Enums\IsKYCDefaultEnum;
use App\Enums\KYCAdminStatusEnum;
use App\Enums\KYCLevelTypeEnum;
use App\Enums\KYCStatusEnum;
use App\Enums\UserNotifyEnum;
use App\Enums\UserTypeEnum;
use App\Integrations\Sumsub\SumsubIntegration;
use App\Jobs\UserUpdateJob;
use App\Models\User;
use App\Models\UserKycInfo;
use App\Models\Webhook;
use App\Notifications\User\ApproveNotification;
use App\Notifications\User\DeclinedNotification;
use App\Notifications\User\WelcomeNotification;
use App\Repositories\Eloquent\Business\BusinessRepository;
use App\Repositories\Eloquent\KycLevel\KycLevelRepository;
use App\Repositories\Eloquent\Users\KycInfoRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Contracts\Container\BindingResolutionException;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;

/**
 * KycService
 */
class KycService
{
    protected $userRepository;

    protected $sumsubIntegration;

    protected $userKycInfoRepository;

    /**
     * Method __construct
     *
     * @return void
     */
    public function __construct(
        UserRepository $userRepository,
        KycInfoRepository $userKycInfoRepository,
        SumsubIntegration $sumsubIntegration,
    ) {
        $this->userRepository = $userRepository;
        $this->sumsubIntegration = $sumsubIntegration;
        $this->userKycInfoRepository = $userKycInfoRepository;
    }

    /**
     * Method Get Sdk Related Data
     */
    public function getSdkRelatedData(): array
    {
        try {
            $user = Auth::user();
            $type = $this->getKycLevel($user)->key;
            return [
                'token' => $this->getAccessToken($user, $type),
                'url' => config('services.sumsub.url'),
                'type' => $type,
            ];
        } catch (\Exception $e) {
            Log::error(
                [
                    'Error - function getSdkRelatedData', $e,
                ]
            );
        }
    }

    public function getKycLevel(User $user)
    {
        $kycLevelRepo = app()->make(KycLevelRepository::class);
        if ($user && $user?->kyc_level_id) {
            return $kycLevelRepo->findById($user->kyc_level_id);
        }

        return $kycLevelRepo->findByColumn(
            [
                "default" => IsKYCDefaultEnum::Default->value,
                "level_type" => ($user->type == UserTypeEnum::Business ? KYCLevelTypeEnum::KYB->value : KYCLevelTypeEnum::KYC->value),

            ]
        );
    }
    /**
     * Method getAccessToken
     *
     * @param  User  $user [explicite description]
     */
    public function getAccessToken(User $user, string $type): string
    {

        try {
            return $this->sumsubIntegration->createAccessToken($this->getOrCreateKycAccount($user)->userKey, $type);
        } catch (\Exception $e) {
            Log::error(['Error - function getAccessToken', $e]);
        }
    }

    /**
     * Method getOrCreateKycAccount
     *
     * @param  User  $user [explicite description]
     */
    public function getOrCreateKycAccount(User $user): UserKycInfo
    {
        try {
            $kycInfo = $user->kycInfo;
            if (!$kycInfo) {
                $kycInfo = $this->userKycInfoRepository->create(
                    [
                        'user_id' => $user->id,
                        'userKey' => $this->customerKey(),
                        'status' => KYCStatusEnum::NotStarted->value,
                    ]
                );
            }
            Log::debug(['CAP - getOrCreateKycAccount', $user]);

            return $kycInfo;
        } catch (\Exception $e) {
            Log::error(['Error - function getOrCreateKycAccount', $e]);
        }
    }

    /**
     * Method customerKey
     */
    public function customerKey(): string
    {
        try {
            $randomKey = str()->random(50);
            $isUnique = false;
            while (!$isUnique) {
                !$this->userKycInfoRepository->findByColumn(
                    [
                        'userKey' => $randomKey,
                    ]
                ) ?
                    $isUnique = true :
                    $randomKey = str()->random(50);
            }

            return $randomKey;
        } catch (\Exception $e) {
            Log::error(['Error - function getNewToken', $e]);
        }
    }

    /**
     * Method getNewToken
     *
     * @return void
     */
    public function getNewToken()
    {
        try {
            $user = Auth::user();
            $type = $this->getKycLevel($user)->key;

            return $this->getAccessToken($user, $type);
        } catch (\Exception $e) {
            Log::error(['Error - function getNewToken', $e]);
        }
    }

    /**
     * Verify Webhooks
     *
     * @param  Request  $request Https Request
     * @param  string  $type    Webhooks Type
     * @return array
     */
    public function verify(Request $request, string $type)
    {
        Log::debug([$type => $request->all()]);
        $this->storeWebhooks($type, $request->all()); //store webhooks for project development
        try {
            $webhooksTypes = config('services.sumsub.webhooks');
            switch ($type) {
                case $webhooksTypes['APPLICANT_CREATE']['VALUE']: //strtolower removed
                    return $this->validateDigest($request, $webhooksTypes['APPLICANT_CREATE']['SECRET']) ? $this->applicantCreated($request->all()) : [];
                    break;
                case $webhooksTypes['APPLICANT_PENDING']['VALUE']:
                    return $this->validateDigest($request, $webhooksTypes['APPLICANT_PENDING']['SECRET']) ? $this->applicantPending($request->all()) : [];
                    break;
                case $webhooksTypes['APPLICANT_REVIVED']['VALUE']:
                    return $this->validateDigest($request, $webhooksTypes['APPLICANT_REVIVED']['SECRET']) ? $this->approveCustomerKyc($request->all()) : [];
                    break;
                case $webhooksTypes['APPLICANT_RESET']['VALUE']:
                    return $this->validateDigest($request, $webhooksTypes['APPLICANT_RESET']['SECRET']) ? $this->applicantDeleted($request->all()) : [];
                    break;
                case $webhooksTypes['APPLICANT_DELETE']['VALUE']:
                    return $this->validateDigest($request, $webhooksTypes['APPLICANT_DELETE']['SECRET']) ? $this->applicantDeleted($request->all()) : [];
                    break;
                case $webhooksTypes['APPLICANT_WORKFLOW_COMPLETED']['VALUE']:
                    return $this->validateDigest($request, $webhooksTypes['APPLICANT_WORKFLOW_COMPLETED']['SECRET']) ? $this->applicantWorkflowCompleted($request->all()) : [];
                    break;
            }
        } catch (\Exception $e) {
            Log::error(['Error - function verify', $e]);
        }
    }

    /**
     * @param  mixed  $name
     * @param  mixed  $data
     * * for project use
     * @return [type]
     */
    public function storeWebhooks($name, $data)
    {
        try {
            Webhook::create(['name' => $name, 'value' => $data]);
        } catch (\Exception $e) {
            Log::error(['storeWebhooks', $e]);
        }
    }

    /**
     * Validate Digest
     *
     * @param  Request  $request Http Request
     * @param  string  $secret  Webhook secret
     */
    public function validateDigest(Request $request, string $secret): bool
    {
        return true;
        // return $this->getDigest($secret, $request->all()) == $request->header('x-payload-digest') ? true : false;
    }

    public function applicantCreated(array $data): array
    {
        try {
            $kycRepository = app()->make(KycInfoRepository::class);
            if (array_key_exists('applicantId', $data) && array_key_exists('externalUserId', $data) && $data['externalUserId'] != null) {
                // $kycAccount = $kycRepository->findByColumn(['userKey' => $data['externalUserId']]);
                // if (array_key_exists('memberOf', $data)) {
                $this->userAccountCreateForBeneficiary(null, $data['applicantId']);

                return ['status' => true, 'data' => $data];
                // }
            }

            return ['status' => false, 'data' => $data];
        } catch (\Exception $e) {
            Log::error(['Error - function applicantCreated', $e]);
        }
    }

    public function applicantWorkflowCompleted(array $data): array
    {
        try {
            $kycRepository = app()->make(KycInfoRepository::class);
            if (array_key_exists('applicantId', $data) && array_key_exists('externalUserId', $data) && $data['externalUserId'] != null) {
                $kycAccount = $kycRepository->findByColumn(['userKey' => $data['externalUserId']]);
                if ($kycAccount) {
                    $kycRepository->update(
                        $kycAccount->id,
                        [
                            'admin_status' => KYCAdminStatusEnum::Inprogress->value,
                            'applicationId' => $data['applicantId'],
                        ]
                    );

                    return ['status' => true, 'data' => $data];
                }
            }

            return ['status' => false, 'data' => $data];
        } catch (\Exception $e) {
            Log::error(['Error - function applicantWorkflowCompleted', $e]);
        }
    }

    public function applicantPending(array $data): array
    {
        Log::debug(['applicantPending => ', $data]);
        try {
            $kycRepository = app()->make(KycInfoRepository::class);
            if (array_key_exists('applicantId', $data) && array_key_exists('externalUserId', $data) && $data['externalUserId'] != null) {
                $kycAccount = $kycRepository->findByColumn(['userKey' => $data['externalUserId']]);
                $userId = $kycAccount?->user_id;
                if ($kycAccount) {
                    $kycRepository->update(
                        $kycAccount->id,
                        [
                            'status' => KYCStatusEnum::Pending,
                            'applicationId' => $data['applicantId'],
                        ]
                    );
                    UserUpdateJob::dispatch($userId);
                } else {
                    if (array_key_exists('applicantMemberOf', $data)) {
                        $BusinessUserKycAccount = $kycRepository->findByColumn(['applicationId' => $data['applicantMemberOf'][0]['applicantId']]);
                        if ($BusinessUserKycAccount && $this->userRepository->existsById($BusinessUserKycAccount->user_id)) {
                            $user = $this->userRepository->findById($BusinessUserKycAccount->user_id);
                            $this->userAccountCreateForBeneficiary($user->business_id, $data['applicantId']);
                        } else {
                            $this->userAccountCreateForBeneficiary(null, $data['applicantId']);
                        }
                    }
                }

                return ['status' => true, 'data' => $data];
            }

            return ['status' => false, 'data' => $data];
        } catch (\Exception $e) {
            Log::error(['Error - function applicantPending', $e]);
        }
    }

    /**
     * Applicant Deleted
     */
    public function applicantDeleted(array $data): array
    {
        try {
            $kycRepository = app()->make(KycInfoRepository::class);
            if (array_key_exists('applicantId', $data) && array_key_exists('externalUserId', $data) && $data['externalUserId'] != null) {
                $kycAccount = $kycRepository->findByColumn(['userKey' => $data['externalUserId']]);
                if ($kycAccount) {
                    $kycRepository->update(
                        $kycAccount->id,
                        [
                            'status' => KYCStatusEnum::NotStarted,
                        ]
                    );

                    return ['status' => true, 'data' => $data];
                }
            }

            return ['status' => false, 'data' => $data];
        } catch (\Exception $e) {
            Log::error(['Error - function applicantDeleted', $e]);
        }
    }

    /**
     * Applicant Resets
     */
    public function applicantResets(array $data): array
    {
        try {
            $kycRepository = app()->make(KycInfoRepository::class);
            if (array_key_exists('applicantId', $data) && array_key_exists('externalUserId', $data) && $data['externalUserId'] != null) {
                $kycAccount = $kycRepository->findByColumn(['userKey' => $data['externalUserId']]);
                if ($kycAccount) {
                    $kycRepository->update(
                        $kycAccount->id,
                        [
                            'status' => KYCStatusEnum::NotStarted,
                        ]
                    );

                    return ['status' => true, 'data' => $data];
                }
            }

            return ['status' => false, 'data' => $data];
        } catch (\Exception $e) {
            Log::error(['Error - function applicantResets', $e]);
        }
    }

    /**
     * Approve Customer Kyc
     *
     * @return void
     */
    public function approveCustomerKyc($data)
    {
        try {
            $kycRepository = app()->make(KycInfoRepository::class);
            $userRepository = app()->make(UserRepository::class);
            if (array_key_exists('applicantId', $data) && array_key_exists('reviewResult', $data) && array_key_exists('externalUserId', $data) && $data['externalUserId'] != null) {
                $kycAccount = $kycRepository->findByColumn(['userKey' => $data['externalUserId']]);
                if ($kycAccount) {
                    $user = $kycAccount->user;
                    switch ($data['reviewResult']['reviewAnswer']) {
                        case 'RED':
                            $status = KYCStatusEnum::Declined;
                            $moderation_comment = array_key_exists('moderationComment', $data['reviewResult']) ? $data['reviewResult']['moderationComment'] : '-';
                            $client_comment = array_key_exists('clientComment', $data['reviewResult']) ? $data['reviewResult']['clientComment'] : '-';
                            $reject_labels = array_key_exists('rejectLabels', $data['reviewResult']) ? implode(',', $data['reviewResult']['rejectLabels']) : '-';
                            $user->notify(new ApproveNotification()); // send approve notification
                            break;
                        case 'GREEN':
                            $status = KYCStatusEnum::Success;
                            $moderation_comment = '';
                            $client_comment = '';
                            $reject_labels = '';
                            UserUpdateJob::dispatch($user->id);
                            // reset step mesages
                            $userRepository->update($user->id, ['step_assets' => null]);
                            $user->notify(new DeclinedNotification()); // send declined notification
                            break;
                    }
                    $kycRepository->update($kycAccount->id, [
                        'moderationComment' => $moderation_comment,
                        'clientComment' => $client_comment,
                        'rejectLabels' => $reject_labels,
                        'status' => $status,
                        // 'status' => $status,
                    ]);

                    return ['status' => true, 'data' => $data];
                }
            }

            return ['status' => false, 'data' => $data];
        } catch (\Exception $e) {
            Log::error(['Error - function approveCustomerKyc', $e]);
        }
    }

    /**
     * @param  mixed  $applicantId
     * @return [type]
     */
    public function getUser($applicantId)
    {
        try {
            return $this->sumsubIntegration->getApplicant($applicantId);
        } catch (\Exception $e) {
            Log::error(['Error - function getUser', $e]);
        }
    }

    /**
     * @param  mixed  $userId
     * @return [type]
     */
    public function updateUserDataFromKyc($userId)
    {
        try {
            $user = $this->userRepository->findById($userId);
            if ($applicantId = $user?->kycInfo?->applicationId) {
                // get sumsub data
                $sumsubData = $this->getUser($applicantId);
                if ($sumsubData && $user?->kycInfo?->applicationId) {
                    Log::debug($sumsubData);
                    // save basic information
                    $info = array_merge(
                        $sumsubData['info'] ?? [],
                        $sumsubData['fixedInfo'] ?? []
                    );

                    if (array_key_exists('companyInfo', $info)) {
                        $companyInfo = $info['companyInfo'];
                        $data = [
                            'company_name' => $companyInfo['companyName'],
                            'registration_number' => $companyInfo['registrationNumber'],
                            'country' => $companyInfo['country'],
                            'beneficiaries' => $companyInfo['beneficiaries'],
                            'type' => UserTypeEnum::Business->value, // update customer as company

                        ];
                        if (array_key_exists('beneficiaries', $companyInfo)) {
                            $this->createBeneficiaryForBusiness($companyInfo['beneficiaries'], $user);
                        }
                    } else {
                        if (array_key_exists('memberOf', $sumsubData)) {
                            $businessId = $this->userKycInfoRepository->findByColumn(['applicationId' => $sumsubData['memberOf'][0]['applicantId']])?->user_id;
                            $business_id = $this->userRepository->findById($businessId)->business_id;
                            $data['business_id'] = $business_id;
                            $this->createUserData($sumsubData, $business_id);
                            Log::debug(['user updateUserDataFromKyc, memberOf, => ' . $business_id]);
                        }
                        // else {
                        $data = [
                            // "user_id" => $userId,
                            'first_name' => $info['firstName'] ?? $user->first_name,
                            'last_name' => $info['lastName'] ?? $user->last_name,
                            'middle_name' => $info['middleNameEn'] ?? $user->middle_name,
                            'surname' => $info['legalName'] ?? $user->surname,
                            'phone_number' => $info['phone'] ?? $user->phone_number,
                            'nationality' => $info['nationality'] ?? $user->nationality,
                            'date_of_birth' => $info['dob'] ?? $user->date_of_birth,
                            'place_of_birth' => $info['placeOfBirth'] ?? $user->placeOfBirthEn,
                            'gender' => $info['gender'] ?? $user->gender,
                            'nationality' => $info['nationality'] ?? $user->nationality,
                            'country' => $info['country'] ?? $user->country,
                            'country_of_birth' => $info['countryOfBirth'] ?? $user->country_of_birth,
                            'state_of_birth' => $info['stateOfBirth'] ?? $user->state_of_birth,
                            'tin' => $info['tin'] ?? $user->tin,
                            'taxResidenceCountry' => $info['taxResidenceCountry'] ?? $user->taxResidenceCountry,
                            'ssn' => $info['ssn'] ?? $user->ssn,
                            'addresses' => $info['addresses'] ?? $user->addresses,
                        ];
                        // }
                    }
                    // save id docs
                    $docs = [];
                    if (isset($info['idDocs'])) {
                        foreach ($info['idDocs'] as $key => $doc) {
                            // TODO: for future usage
                            $docs[] = $doc;
                        }
                    }
                    $data['idDocs'] = $docs;
                    if (isset($sumsubData['questionnaires'])) {
                        //save  questionnaires
                        $questionnaires = [];
                        foreach ($sumsubData['questionnaires'] as $key => $questionary) {
                            // TODO: for future usage
                            // add document to the database
                            $questionnaires[] = $questionary;
                        }
                        $data['questionnaires'] = $questionnaires;
                    }

                    //  download images
                    $data['images'] = $this->downloadImages($sumsubData);
                    $data['summary'] = $this->sumsubIntegration->getApplicantPdf($applicantId, $info['firstName'] ?? $user->first_name, 'applicantReport');
                    $this->userRepository->updateWithMeta($user->id, $data);
                }
            }
        } catch (\Exception $e) {
            Log::error(['Error - function updateUserDataFromKyc', $e]);
        }
    }

    /**
     * @param  array  $data
     * @return [type]
     */
    public function createBeneficiaryForBusiness(array $beneficiaries, $businessUser)
    {
        $BusinessId = $businessUser->business_id;
        Log::debug(['createBeneficiaryForBusiness beneficiaries array', $beneficiaries]);
        foreach ($beneficiaries as $shareholder) {
            $this->userAccountCreateForBeneficiary($BusinessId, $shareholder['applicantId'], $shareholder);
        }
    }

    /**
     * @param  mixed  $businessId
     * @param  mixed  $applicantId
     * @return [type]
     */
    public function userAccountCreateForBeneficiary($businessId, $applicantId, $shareholderData = null)
    {
        $sumsubData = $this->getUser($applicantId);
        $this->createUserData($sumsubData, $businessId, $shareholderData);
    }

    /**
     * @param  array  $sumsubData
     * @return [type]
     */
    public function createUserData($sumsubData, $businessId = null, $shareholderData = null)
    {
        Log::debug($businessId);
        if ($sumsubData) {
            Log::debug(['create applicant' => $sumsubData]);
            // $info = $sumsubData['info'];
            // if (array_key_exists('email', $sumsubData) && array_key_exists('fixedInfo', $sumsubData)) {
            if (array_key_exists('fixedInfo', $sumsubData) || array_key_exists('info', $sumsubData)) {
                $kycLevel = app()->make(KycLevelRepository::class)->findByColumn(['key' => $sumsubData['review']['levelName']])?->id;
                $fixedInfo = array_merge(
                    $sumsubData['info'] ?? [],
                    $sumsubData['fixedInfo'] ?? []
                );
                $data = [
                    'email' => $sumsubData['email'] ?? null,
                    'business_id' => $businessId,
                    'first_name' => $fixedInfo['firstName'] ?? null,
                    'last_name' => $fixedInfo['lastName'] ?? null,
                    'kyc_level_id' => $kycLevel,
                    'type' => UserTypeEnum::Customer->value,
                ];
                if ($sumsubData['type'] == 'company') {
                    $business = $this->createBusiness($sumsubData['info']['companyInfo']);
                    $data['business_id'] = $business->id;
                    $names = explode(' ', $business->name);
                    $data['first_name'] = $names[0] ?? null;
                    $data['last_name'] = $names[1] ?? null;
                    $data['type'] = UserTypeEnum::Business->value;
                }
                $user = $this->userRepository->createOrUpdateWithTrashed([
                    'applicant_id' => $sumsubData['id'],
                ], $data);
                $this->userKycInfoRepository->createOrUpdate([
                    'applicationId' => $sumsubData['id'],
                ], [
                    'userKey' => $sumsubData['externalUserId'],
                    'user_id' => $user->id,
                    // 'status' => KYCStatusEnum::NotStarted->value,
                    // 'admin_status' => KYCAdminStatusEnum::Pending->value
                ]);
                if ($sumsubData['type'] == 'individual') {
                    $user->setMeta([
                        'position' => $shareholderData['positions'][0] ?? '-',
                        'type' => $shareholderData['type'] ?? '-',
                        'first_name' => $fixedInfo['firstName'] ?? '-',
                        'middle_name' => $fixedInfo['middleName'] ?? '-',
                        'last_name' => $fixedInfo['lastName'] ?? '-',
                        'date_of_birth' => $fixedInfo['dob'] ?? '-',
                        'phone_number' => $fixedInfo['phone'] ?? '-',
                    ]);

                    $user->save();
                }
                if ($user->notify_status == UserNotifyEnum::NotSend && array_key_exists('email', $sumsubData)) {
                    $user->notify(new WelcomeNotification());
                    $user->update(['notify_status' => UserNotifyEnum::Send->value]);
                }
            }
        }
    }

    /**
     * @param  mixed  $companyData
     * @return [type]
     */
    public function createBusiness($companyData)
    {
        return app()->make(BusinessRepository::class)->create([
            'name' => $companyData['companyName'],
        ]);
    }

    /**
     * Method downloadImages
     *
     * @param  mixed  $applicantId [explicite description]
     * @return void
     */
    public function downloadImages($sumsubData)
    {
        try {
            $applicantStatus = $this->sumsubIntegration->getApplicantStatus($sumsubData['id']);
            // loom the status
            Log::debug($applicantStatus);
            foreach ($applicantStatus as $key => $item) {
                $array[$key] = [
                    'type' => $key,
                    'document' => $item['idDocType'],
                    'country' => $item['country'],
                    'status' => $item['reviewResult']['reviewAnswer'] ?? '',
                    'moderationComment' => $item['reviewResult']['moderationComment'] ?? '',
                ];

                if (array_key_exists('imageIds', $item) && $item['imageIds'] != null) {
                    foreach ($item['imageIds'] as $imgId) {
                        $image = $this->sumsubIntegration->getApplicantImages($sumsubData['inspectionId'], $imgId, $sumsubData['id']);
                        Log::debug(['sources', $image]);
                        $array[$key]['files'][] = [
                            'url' => $image,
                            'type' => Storage::mimeType($image),
                        ];
                    }
                }
            }

            return $array;
        } catch (\Exception $e) {
            Log::error(['', $e->getMessage()]);
        }
    }

    /**
     * Method resetUserKyc
     *
     * @param  array  $data [explicite description]
     * @param  int  $id   [explicite description]
     * @return void
     */
    public function resetUserKycStep($data, $id)
    {
        // dd($data, $id);
        try {
            $user = $this->userRepository->findById($id);
            $images = $user->images;
            switch ($data['status']) {
                case 'approve':
                    $images[$data['step']]['admin_status'] = 'GREEN';
                    break;
                case 'reject':
                    // reset status in sumsub
                    // dd($user->kycInfo->applicationId, $data['step']);
                    $resp = $this->sumsubIntegration->resetStep(
                        $user->kycInfo->applicationId,
                        $data['step']
                    );
                    // set status
                    $images[$data['step']]['status'] = 'RED';
                    $images[$data['step']]['admin_status'] = 'RED';
                    break;
            }
            $images[$data['step']]['admin_comment'] = $data['comment'];
            // update user images
            $this->userRepository->updateWithMeta(
                $user->id,
                [
                    'images' => $images,
                ]
            );
        } catch (\Exception $e) {
            Log::error(['Error - Step Reset Issue', $e]);
        }
    }

    /**
     * Method resetKYCStep
     *
     * @param  int  $userId [explicite description]
     * @param  string  $step   [explicite description]
     *
     * @throws BindingResolutionException
     */
    public function resetKYCStep(int $userId, string $step): void
    {
        $userRepository = app()->make(UserRepository::class);
        $kycInfoRepository = app()->make(KycInfoRepository::class);
        $sumsubIntegration = app()->make(SumsubIntegration::class);
        $user = $userRepository->findById($userId);
        $sumsubIntegration->resetStep($user->kycInfo->applicationId, $step);
        // reset liveness
        $sumsubIntegration->resetStep($user->kycInfo->applicationId, 'SELFIE');
        // update kyc as declined
        $kycInfoRepository->update(
            $user->kycInfo->id,
            [
                'status' => KYCStatusEnum::NotCompleted,
                'admin_status' => KYCAdminStatusEnum::Rejected,
            ]
        );
        // mail for notify
        // $user->notify(new KYCResubmitNotification($step));
    }

    //////////////////////////////

    /**
     * Method resetStep
     *
     * @param $user $user [explicite description]
     * @param $data $data [explicite description]
     * @return void
     */
    public function resetStep($user, $data)
    {
        $kycRepository = app()->make(KycInfoRepository::class);
        // Reset step
        if ($data['step'] != 'SELFIE') {
            $this->sumsubIntegration->resetStep($user->kycInfo->applicationId, $data['step']);
        }
        //  reset face match
        $this->sumsubIntegration->resetStep($user->kycInfo->applicationId, 'SELFIE');
        $userData['step_assets'] = $user->step_assets;
        $userData['step_assets'][$data['step']]['admin_status'] = 'reset';
        $userData['step_assets'][$data['step']]['admin_comment'] = $data['comment'];
        $userData['step_assets'][$data['step']]['admin_time'] = Carbon::now()->format('M d, H:i a');
        $this->userRepository->update($user->id, ['step_assets' => $userData['step_assets']]);
        // update KYC
        $kycRepository->update($user->kycInfo->id, [
            'admin_status' => 'pending',
            'status' => KYCStatusEnum::NotCompleted,
        ]);
        // Notify user
        $customJobRepository = app()->make(CustomJobRepository::class);
        $customJobRepository->create([
            'user_id' => $user->id,
            'step' => $data['step'],
            'reason' => $data['comment'],
            'type' => 'KYCResubmitNotification',
        ]);

        // new activity
        // $this->userActivityService->saveActivity($user->id, "KYC_STEP_RESET", $data['step'] . " manually rejected and asked to resubmit");
    }

    /**
     * Method manualApprove
     *
     * @param  User  $user [explicite description]
     * @param  array  $data [explicite description]
     * @return void
     */
    public function manualApprove($user, $data)
    {

        // $userData["step_assets"] = $user->step_assets;
        // $userData["step_assets"][$data['step']]["admin_status"] = "approved";
        // $userData["step_assets"][$data['step']]["admin_comment"] = $data['comment'];
        // $userData["step_assets"][$data['step']]["admin_time"] = Carbon::now()->format('M d, H:i a');
        // $this->userRepository->update($user->id, ["step_assets" => $userData["step_assets"]]);

        // new activity
        // $this->userActivityService->saveActivity($user->id, "KYC_STEP_APPROVED", $data['step'] . " manually approved");
    }

    /**
     * Method modify
     *
     * @param  User  $user [explicite description]
     * @param  array  $data [explicite description]
     * @return void
     */
    public function modify($user, $data)
    {
        if ($user->kycInfo) {
            switch ($data['modifyType']) {
                case 'approve':
                    $this->manualApprove($user, $data);
                    break;
                case 'decline':
                    $this->resetStep($user, $data);
                    break;
            }
        }
    }

    /**
     * Method modifyFUlly
     *
     * @param $user $user [explicite description]
     * @param $data $data [explicite description]
     * @return void
     */
    public function modifyFully($user, $data)
    {
        switch ($data['modifyType']) {
            case 'approve':
                $this->manualApproveFully($user, $data);
                break;
            case 'decline':
                $this->fullReset($user, $data);
                break;
        }
    }

    /**
     * Method manualApproveFully
     *
     * @param  User  $user [explicite description]
     * @param  array  $data [explicite description]
     * @return void
     */
    public function manualApproveFully($user, $data)
    {
        $kycRepository = app()->make(KycInfoRepository::class);

        $assets = $user->step_assets;
        // foreach ($user->step_assets as $key => $asset) {
        //     $assets[$key]['admin_status'] = 'approved';
        //     $assets[$key]['admin_comment'] = $data['comment'];
        //     $assets[$key]['admin_time'] = Carbon::now()->format('M d, H:i a');
        // }
        // full
        $assets['FULL']['admin_status'] = 'approved';
        $assets['FULL']['admin_comment'] = $data['comment'];
        $assets['FULL']['admin_time'] = Carbon::now()->format('M d, H:i a');
        // Update
        $this->userRepository->update($user->id, ['admin_status' => 'approved', 'step_assets' => $assets]);
        // kyc status
        $kycRepository->update($user->kycInfo->id, [
            'admin_status' => 'approved',
        ]);
        // New activity
        // $this->userActivityService->saveActivity($user->id, "KYC_STEP_APPROVED", "User KYC manually approved");
    }

    /**
     * Method fullReset
     *
     * @param $user $user [explicite description]
     * @return void
     */
    public function fullReset($user, $data)
    {
        $kycRepository = app()->make(KycInfoRepository::class);
        $this->sumsubIntegration->resetApplicant($user->kycInfo->applicationId);
        $this->userRepository->update($user->id, [
            'is_download_prepared' => 'no',
            'step_assets' => [
                'FULL' => [
                    'status' => 'reset',
                ],
            ],
        ]);
        // update admin status
        $kycRepository->update($user->kycInfo->id, [
            'admin_status' => 'pending',
            'admin_comments' => [
                'reason' => $data['comment'],
                'time' => Carbon::now(),
            ],
            'status' => KYCStatusEnum::NotCompleted,
        ]);
        // Notify user
        $customJobRepository = app()->make(CustomJobRepository::class);
        $customJobRepository->create([
            'user_id' => $user->id,
            'step' => 'FULL',
            'reason' => 'Full KYC reset',
            'type' => 'KYCResubmitNotification',
        ]);
    }
}
