<?php

namespace App\Services\User;

use App\Enums\UserTypeEnum;
use App\Repositories\Eloquent\Questionary\QuestionaryRepository;
use App\Repositories\Eloquent\Users\KycInfoRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Log;

class UserService
{
    /**
     * @return [type]
     */
    public function getUserLoginUrl(int $userId)
    {
        return config('app.url').'/login/auto?cred='.Crypt::encryptString($userId);
    }

    /**
     * @return [type]
     */
    public function getUserData(int $id)
    {
        $kycInfoRepo = app()->make(KycInfoRepository::class);
        $kycService = app()->make(KycService::class);
        $applicationId = $kycInfoRepo->findByColumn(['user_id' => $id])->applicationId;

        return $kycService->getUser($applicationId);
    }

    /**
     * @return [type]
     */
    public function getQuestionary(int $userId)
    {
        try {
            $userRepo = app()->make(UserRepository::class);
            $questionaryRepo = app()->make(QuestionaryRepository::class);
            $questionary = $userRepo->findTrashedById($userId)->questionnaires;
            $tagTable = $questionaryRepo->all();
            $tagArray = [];

            foreach ($tagTable as $tag) {
                $tagArray[$tag->tag] = ['key' => $tag->key, 'options' => $tag->options];
            }
            // dd($tagArray);
            function recursiveReplaceKeysAndValues(&$data, $tagArray, $tagTable)
            {
                if ($data) {
                    foreach ($data as $key => &$value) {
                        if (is_array($value)) {
                            recursiveReplaceKeysAndValues($value, $tagArray, $tagTable);
                        } else {
                        }
                        if (isset($tagArray[$key])) {
                            $setValue = $value;
                            if (isset($tagArray[$key]['options']) && is_array($tagArray[$key]['options'] && array_key_exists('value', $value))) {
                                if (isset($tagArray[$key]['options'][$value['value']])) {
                                    // dd($tagArray[$key]['options'][$value['value']]);
                                    $setValue = ['value' => $tagArray[$key]['options'][$value['value']]];
                                }
                            }
                            // dd($setValue);
                            $data[$tagArray[$key]['key']] = $setValue;
                            // $data[$tagArray[$key]] = $value;
                            unset($data[$key]);
                        }
                    }
                }
            }
            recursiveReplaceKeysAndValues($questionary, $tagArray, $tagTable);

            // dd($questionary);
            return $questionary;
        } catch (\Exception $e) {
            Log::debug($e);
        }
    }

    /**
     * @param  mixed  $shareholder
     * @return [type]
     */
    public function getBusinessAccount($shareholder)
    {
        $userRepo = app()->make(UserRepository::class);
        if ($shareholder->business_id) {
            $businessAccount = $userRepo->findByColumnWithTrashed(['business_id' => $shareholder->business_id, 'type' => UserTypeEnum::Business->value]);

            return $businessAccount;
        }
    }

    // public function replaceKeysAndValues($userId)
    // {
    //     $userRepo = app()->make(UserRepository::class);
    //     $questionaryRepo = app()->make(QuestionaryRepository::class);
    //     $questionary = $userRepo->findById($userId)->questionnaires;
    //     $tagTable = $questionaryRepo->all();
    //     $tagArray = [];

    //     foreach ($tagTable as $tag) {
    //         $tagArray[$tag->tag] = $tag->key;
    //     }

    //     function recursiveReplaceKeysAndValues(&$data, $tagArray)
    //     {
    //         foreach ($data as $key => &$value) {
    //             if (is_array($value)) {
    //                 recursiveReplaceKeysAndValues($value, $tagArray);
    //             } else {
    //             }
    //             if (isset($tagArray[$key])) {
    //                 $data[$tagArray[$key]] = $value;
    //                 unset($data[$key]);
    //             }
    //         }
    //     }
    //     recursiveReplaceKeysAndValues($questionary, $tagArray);
    //     return $questionary;
    // }
}
