<?php

namespace App\Services\Questionary;

use App\Repositories\Eloquent\Questionary\QuestionaryRepository;
use Illuminate\Support\Facades\Log;

class QuestionaryService
{
    protected $questionaryRepo;

    /**
     * @param  mixed  $data
     * @return [type]
     */
    public function store($jsonData)
    {
        try {
            $questionaryRepo = app()->make(QuestionaryRepository::class);
            $data = json_decode($jsonData, true);

            // Initialize an empty array to store the results
            $resultArray = [];
            $options = [];

            // Function to recursively extract id and title
            function extractIdsAndTitles($data, &$resultArray, &$options)
            {
                if (is_array($data) || is_object($data)) {
                    foreach ($data as $key => $value) {
                        if (is_array($value)) {
                            // Recursively call the function for nested arrays
                            extractIdsAndTitles($value, $resultArray, $options);
                        } elseif (is_array($data) && isset($data['id']) && isset($data['title'])) {
                            if (! empty($data['title'])) {
                                $resultArray[$data['id']] = $data['title'];
                                if (isset($data['options'])) {
                                    $values = [];
                                    foreach ($data['options'] as $value) {
                                        $values[$value['value']] = $value['title'];
                                    }
                                    $options[$data['id']] = $values;
                                }
                            }
                            // If both id and title are present, add them to the result array
                        }
                    }
                }
            }
            // Call the function to extract data
            extractIdsAndTitles($data, $resultArray, $options);
            // dd($options);
            foreach ($resultArray as $key => $value) {
                $opValue = null;
                if (isset($options[$key])) {
                    $opValue = $options[$key];
                } else {
                    $opValue = null;
                }
                // dd(['tag' => $key], ['key' => $value, 'options' => $opValue]);
                $q = $questionaryRepo->createOrUpdate(['tag' => $key], ['key' => $value, 'options' => $opValue]);
                // dd($q);
            }
        } catch (\Exception $e) {
            Log::error($e->getMessage());
        }
    }
}
