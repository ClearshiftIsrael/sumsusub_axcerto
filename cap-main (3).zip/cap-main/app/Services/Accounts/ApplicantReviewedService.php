<?php

namespace App\Services\Accounts;

use App\Enums\AccountVerificationStatusEnum;
use App\Integrations\Sumsub\SumsubIntegration;
use App\Repositories\Eloquent\Accounts\AccountsRepository;
use Illuminate\Support\Facades\Log;

class ApplicantReviewedService
{

    public function __construct(
        protected   AccountsRepository $accountsRepository,
        protected   SumsubIntegration $sumsubIntegration
    ) {
    }

    /**
     * applicantReviewed
     *
     * @param  mixed $data
     * @return array
     */
    public function applicantReviewed(array $data): ?array
    {

        try {

            if (array_key_exists('applicantId', $data) && array_key_exists('reviewResult', $data) && array_key_exists('externalUserId', $data) && $data['externalUserId'] != null) {

                $applicant = $this->sumsubIntegration->getApplicant($data['applicantId']);
                //array merge
                $info = array_merge(
                    $applicant['info'] ?? [],
                    $applicant['fixedInfo'] ?? []
                );
                $svData = [];
                // get account and update data
                if ($account = $this->accountsRepository->findByColumn(['user_key' => $data['externalUserId']])) {
                    $status = $account->kyc_status;
                    switch ($data['reviewResult']['reviewAnswer']) {
                        case 'RED':
                            $status = AccountVerificationStatusEnum::Declined;
                            $svData['moderation_comment'] = array_key_exists('moderationComment', $data['reviewResult']) ? $data['reviewResult']['moderationComment'] : '-';
                            $svData['client_comment'] = array_key_exists('clientComment', $data['reviewResult']) ? $data['reviewResult']['clientComment'] : '-';
                            $svData['reject_labels'] = array_key_exists('rejectLabels', $data['reviewResult']) ? implode(',', $data['reviewResult']['rejectLabels']) : '-';

                        case 'GREEN':
                            $status = AccountVerificationStatusEnum::Success;
                            $svData['moderation_comment'] = '';
                            $svData['client_comment'] = '';
                            $svData['reject_labels'] = '';
                    }
                    $this->saveInfo($info, $account, $status, $svData);
                } else {
                    //TODO
                }

                return ['status' => true, 'data' => $data];
            }

            return ['status' => false, 'data' => $data];
        } catch (\Exception $e) {
            Log::error('Error - function applicantCreated', ["error" => $e]);
        }
    }

    /**
     * saveInfo
     *
     * @param  mixed $info
     * @param  mixed $account
     * @param  mixed $status
     * @return void
     */
    public function saveInfo($info, $account, $status, $data)
    {
        // add company data if have
        if (array_key_exists('companyInfo', $info)) {
            $data['business_name'] =  $info['companyInfo']['companyName'];
            $data['country'] =  $info['companyInfo']['country'];
        }
        // Add Personal data
        $data['first_name'] = $info['firstName'] ?? $account?->mata_data?->first_name;
        $data['last_name'] = $info['lastName'] ?? $account?->mata_data?->last_name;
        $data['middle_name'] = $info['middleNameEn'] ?? $account?->mata_data?->last_name;
        $data['surname'] = $info['legalName'] ?? $account?->mata_data?->last_name;

        // status
        $data['kyc_status'] = $status;
        unset($data['type']);
        // sace account data
        $this->accountsRepository->updateWithMeta($account->id, $data);
    }
}
