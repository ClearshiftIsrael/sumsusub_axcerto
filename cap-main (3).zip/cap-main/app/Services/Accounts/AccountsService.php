<?php

namespace App\Services\Accounts;

use App\Enums\AccountStatusEnum;
use App\Enums\AccountTeamRoleEnum;
use App\Enums\AccountVerificationStatusEnum;
use App\Enums\TeamInvitationStatusEnum;
use App\Integrations\Sumsub\SumsubIntegration;
use App\Models\Account;
use App\Notifications\Account\AccountNewUserNotification;
use App\Repositories\Eloquent\Accounts\AccountsRepository;
use App\Repositories\Eloquent\Accounts\AccountsTeamRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use App\Repositories\Eloquent\WebHooks\WebHooksRepository;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class AccountsService
{

    public function __construct(
        protected AccountsRepository $accountsRepository,
        protected SumsubIntegration $sumsubIntegration,
        protected WebHooksRepository $webHooksRepository,
        protected UserRepository $userRepository,
        protected NewApplicantService $newApplicantService,
        protected ApplicantPendingService $applicantPendingService,
        protected ApplicantReviewedService $applicantReviewedService,
        protected ApplicantResetService $applicantResetService,
        protected ApplicantDeleteService $applicantDeleteService
    ) {
    }
    public function getSdkRelatedData($account): array
    {
        try {
            return [
                'token' => $this->getAccessToken($account),
                'url' => config('services.sumsub.url'),
            ];
        } catch (\Exception $e) {
            Log::error(
                'Error - function getSdkRelatedData',
                [
                    "error" => $e,
                ]
            );
            return null;
        }
    }
    /**
     * Method getAccessToken
     *
     * @param  Account  $account [explicite description]
     */
    public function getAccessToken(Account $account): string
    {

        try {
            $accountKey = $account->user_key;
            if (!$accountKey) {
                $accountKey = str()->random(60);
                $this->accountsRepository->update($account->id, ["user_key" => $accountKey]);
            }
            return $this->sumsubIntegration->createAccessToken($accountKey, $account->verification_level);
        } catch (\Exception $e) {

            Log::error(
                'Error - function getAccessToken',
                [
                    "error" => $e,
                ]
            );
            return null;
        }
    }
    /**
     * @param  mixed  $applicantId
     * @return [type]
     */
    public function getUser($applicantId)
    {
        try {
            return $this->sumsubIntegration->getApplicant($applicantId);
        } catch (\Exception $e) {
            Log::error('Error - function getUser', ["error" => $e]);
            return [];
        }
    }

    /**
     * Verify Webhooks
     *
     * @param  mixed  $request Https Request
     * @param  string  $type    Webhooks Type
     * @return mixed
     */
    public function verify($request, string $type)
    {
        $this->storeWebhooks($type, $request->all()); //store webhooks for project development
        try {
            $webhooksTypes = config('services.sumsub.webhooks');
            switch ($type) {
                case $webhooksTypes['APPLICANT_CREATE']['VALUE']: //strtolower removed
                    return $this->validateDigest($request, $webhooksTypes['APPLICANT_CREATE']['SECRET']) ? $this->newApplicantService->create($request->all()) : [];
                case $webhooksTypes['APPLICANT_PENDING']['VALUE']:
                    return $this->validateDigest($request, $webhooksTypes['APPLICANT_PENDING']['SECRET']) ? $this->applicantPendingService->applicantPending($request->all()) : [];
                case $webhooksTypes['APPLICANT_REVIVED']['VALUE']:
                    return $this->validateDigest($request, $webhooksTypes['APPLICANT_REVIVED']['SECRET']) ? $this->applicantReviewedService->applicantReviewed($request->all()) : [];
                case $webhooksTypes['APPLICANT_RESET']['VALUE']:
                    return $this->validateDigest($request, $webhooksTypes['APPLICANT_RESET']['SECRET']) ? $this->applicantResetService->applicantResets($request->all()) : [];
                case $webhooksTypes['APPLICANT_DELETE']['VALUE']:
                    return $this->validateDigest($request, $webhooksTypes['APPLICANT_DELETE']['SECRET']) ? $this->applicantDeleteService->applicantDeleted($request->all()) : [];
            }
        } catch (\Exception $e) {
            Log::error('Error - function verify',[$e]);
            return [];
        }
    }


    /**
     * @param  mixed  $name
     * @param  mixed  $data
     * * for project use
     * @return [type]
     */
    public function storeWebhooks($name, $data)
    {
        try {
            $this->webHooksRepository->create(['name' => $name, 'value' => $data]);
        } catch (\Exception $e) {
            Log::error('storeWebhooks', ["error" => $e]);
        }
    }
    /**
     * Validate Digest
     *
     * @param  Request  $request Http Request
     * @param  string  $secret  Webhook secret
     */
    public function validateDigest($request, string $secret): bool
    {
        return true;
        // return $this->getDigest($secret, $request->all()) == $request->header('x-payload-digest') ? true : false;
    }

    /**
     * @param array $data
     *
     * @return [type]
     */
    public function addAccountUser(array $data)
    {
        $userRepository = app()->make(UserRepository::class);
        $accountTeamRepo = app()->make(AccountsTeamRepository::class);
        $sumSubUser = $this->getUser($data['applicant_id']);
        
        if ($sumSubUser) {
            $account = $this->accountsRepository->create([
                "name" => '',
                "applicant_id" => $data['applicant_id'],
                'user_key' => $sumSubUser['externalUserId'],
                "verification_level" => $sumSubUser['review']['levelName'],
                "status" => AccountStatusEnum::Active->value,
                "type" => $sumSubUser['type']
            ]);
            $user = $userRepository->findByColumn(['email' => $data['email']]);
            $code = Str::random(100);
            if (!$user) {
                $user = $userRepository->create([
                    'username' => Str::random('12'),
                    'email' => $data['email'],

                ]);
            }
            $user->notify(new AccountNewUserNotification(['name' => $account->name, 'type' => $account->type, 'link' => route('invitation', $code)]));
            $accountTeamRepo->create([
                'user_id' => $user->id,
                'account_id' => $account->id,
                'role' => AccountTeamRoleEnum::Owner->value,
                'invitation_status' => TeamInvitationStatusEnum::Sent->value,
                'code' => $code,
            ]);
            return true;
        }
        return false;
    }
}
