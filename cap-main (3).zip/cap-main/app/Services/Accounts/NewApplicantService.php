<?php

namespace App\Services\Accounts;

use App\Enums\AccountTeamRoleEnum;
use App\Enums\AccountVerificationStatusEnum;
use App\Enums\KYCLevelStatusEnum;
use App\Enums\KYCStatusEnum;
use App\Integrations\Sumsub\SumsubIntegration;
use App\Notifications\Account\AccountNewUserNotification;
use App\Repositories\Eloquent\Accounts\AccountsRepository;
use App\Repositories\Eloquent\Accounts\AccountsTeamRepository;
use App\Repositories\Eloquent\KycLevel\KycLevelRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;

class NewApplicantService
{

    public function __construct(
        protected   AccountsRepository $accountsRepository,
        protected   SumsubIntegration $sumsubIntegration,
        protected   UserRepository $userRepository,
        protected KycLevelRepository $kycLevelRepository,
        protected AccountsTeamRepository $accountsTeamRepository
    ) {
    }


    public function create(array $data)
    {
        try {
            // Get Applicant from SumSub
            $applicant = $this->sumsubIntegration->getApplicant($data['applicantId']);
            // applicant
            $info = array_merge(
                $applicant['info'] ?? [],
                $applicant['fixedInfo'] ?? []
            );
            // find the accout ofm the applicant
            $account = $this->accountsRepository->findByColumn(['applicant_id' => $data['applicantId']]);
            if (!$account) {
                // If not found need to create the user and applicant both
                $user =   $this->userRepository->findOrCreate(
                    [
                        'email' => $data['externalUserId']
                    ],
                    [
                        'first_name' => $applicant['info']['firstName'] ?? "-",
                        'last_name' => $applicant['info']['lastName'] ?? "-",
                        'username' => Str::random(15),
                        'is_invited' => 'yes'
                    ]
                );
                // Get the level
                $level = $this->kycLevelRepository->findOrCreate(['key' => $applicant['review']['levelName']], ['name' => Str::headline($applicant['review']['levelName'])]);
                // Create the account
                $account = $this->accountsRepository->create(
                    [
                        'name' => (($applicant['info']['firstName']??"") . " " . ($applicant['info']['lastName']??"")),
                        'applicant_id' => $data['applicantId'],
                        'user_key' => $data['externalUserId'],
                        'verification_level' => $level->key,
                        'kyc_status' => KYCStatusEnum::NotStarted->value,
                        'status' => KYCLevelStatusEnum::Active->value,
                    ]
                );
                // Add the account to the team
                $team =  $this->accountsTeamRepository->create(
                    [
                        'user_id' => $user->id,
                        'account_id' => $account->id,
                        'invitation_status' => 'sent',
                        'role' => AccountTeamRoleEnum::Owner->value,
                        'code' =>  Str::random(100)
                    ]
                );
                // Notify the user 
                $user->notify(new AccountNewUserNotification(
                    [
                        'link' => route('invitation', $team->code),
                        'name' => $account->name,
                        'type' => $account->type,
                    ]
                ));
                // Change the ExternalId
                $this->chnageTheExternalId($account, $user);
            }
            // Save Applicant Info
            $this->saveInfo($info, $account, AccountVerificationStatusEnum::NotCompleted, $data);
            return ['status' => false, 'data' => $data];
        } catch (\Exception $e) {
            Log::error('Error - function applicant Created', ["error" => $e]);
        }
    }


    public function chnageTheExternalId($account, $user)
    {
        $code = str()->random(50);
        // 
        $resp = $this->sumsubIntegration->changeTopLevel(
            [
                'id' => $account->applicant_id,
                'externalUserId' => $code,
                'email' => $user->email
            ]
        );
        if ($resp) {
            $this->accountsRepository->update($account->id, ['user_key' => $code]);
        }
    }


    /**
     * saveInfo
     *
     * @param  mixed $info
     * @param  mixed $account
     * @param  mixed $status
     * @return void
     */
    public function saveInfo($info, $account, $status, $data)
    {
        // add company data if have
        if (array_key_exists('companyInfo', $info)) {
            $data['business_name'] =  $info['companyInfo']['companyName'];
            $data['country'] =  $info['companyInfo']['country'];
        }
        // Add Personal data
        $data['first_name'] = $info['firstName'] ?? $account?->mata_data?->first_name;
        $data['last_name'] = $info['lastName'] ?? $account?->mata_data?->last_name;
        $data['middle_name'] = $info['middleNameEn'] ?? $account?->mata_data?->last_name;
        $data['surname'] = $info['legalName'] ?? $account?->mata_data?->last_name;

        // status
        $data['kyc_status'] = $status;
        unset($data['type']);
        // sace account data
        $this->accountsRepository->updateWithMeta($account->id, $data);
    }
}
