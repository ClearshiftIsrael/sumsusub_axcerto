<?php

namespace App\Services\Accounts;

use App\Enums\TeamInvitationStatusEnum;
use App\Enums\UserInvitationStatusEnum;
use App\Notifications\Account\AccountNewUserNotification;
use App\Repositories\Eloquent\Accounts\AccountsRepository;
use App\Repositories\Eloquent\Accounts\AccountsTeamRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Support\Str;

class AccountInvitationService
{
    protected $accountsRepository;
    protected $userRepository;
    protected $accountTeamRepository;

    public function __construct(
        AccountsRepository $accountsRepository,
        AccountsTeamRepository $accountTeamRepository,
        UserRepository $userRepository
    ) {
        $this->accountsRepository = $accountsRepository;
        $this->userRepository = $userRepository;
        $this->accountTeamRepository = $accountTeamRepository;
    }

    public function invite($data, $id)
    {
        // Get The account
        $account = $this->accountsRepository->findById($id);

        $user = $this->userRepository->findByColumn(['email' => $data['email']]);
        //Get the user by email
        if (!$user) {
            $user = $this->userRepository->create(['email' => $data['email'], 'username' => Str::random('12'), 'is_invited' => UserInvitationStatusEnum::Yes]);
        }
        // Account Team
       $team= $this->accountTeamRepository->create(
            [
                'account_id' => $account->id,
                'user_id' => $user->id,
                'role' => $data['role'],
                'code' => Str::random(100),
                'invitation_status' => TeamInvitationStatusEnum::Sent->value
            ]
        );

        $user->notify(new AccountNewUserNotification(
            [
                'link' => route('invitation', $team->code),
                'name' => $account->name,
                'type' => $account->type,
            ]
        ));
    }
}
