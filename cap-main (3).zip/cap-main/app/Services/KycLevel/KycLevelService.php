<?php

namespace App\Services\KycLevel;

use App\Enums\IsKYCDefaultEnum;
use App\Repositories\Eloquent\KycLevel\KycLevelRepository;

class KycLevelService
{
    /**
     * @return [type]
     */
    public function statusUpdate(int $id)
    {
        $kycLevelRepo = app()->make(KycLevelRepository::class);
        $nowDefault = $kycLevelRepo->findById($id);
        $prevDefault = $kycLevelRepo->findByColumn(['default' => IsKYCDefaultEnum::Default->value, 'level_type' => $nowDefault->level_type->value]);
        if ($prevDefault) {
            $prevDefault?->update(['default' => IsKYCDefaultEnum::NotDefault->value]);
        }
        $kycLevelRepo->findById($id)?->update(['default' => IsKYCDefaultEnum::Default->value]);

    }
}
