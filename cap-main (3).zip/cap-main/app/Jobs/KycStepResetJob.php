<?php

namespace App\Jobs;

use App\Services\User\KycService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class KycStepResetJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $userId;

    protected $step;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($userId, $step)
    {
        $this->userId = $userId;
        $this->step = $step;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        Log::debug('resetKYCStep');
        $kycService = app()->make(KycService::class);
        $kycService->resetKYCStep($this->userId, $this->step);
    }
}
