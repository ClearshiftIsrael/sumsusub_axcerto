<?php

namespace App\Console\Commands;

use App\Notifications\User\KYCAdminResubmitNotification;
use App\Notifications\UserKycApproved;
use App\Repositories\Eloquent\CustomJob\CustomJobRepository;
use App\Repositories\Eloquent\User\UserRepository;
use Illuminate\Console\Command;

class StepRestMailSender extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'app:custom-jobs-mail-sender';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $customJobRepository = app()->make(CustomJobRepository::class);
        $jobs = $customJobRepository->getByColumn(['status' => 'pending']);

        foreach ($jobs as $job) {

            switch ($job->type) {
                case 'KYCResubmitNotification':
                    $this->resetMailSender($job);
                    break;
                case 'KYCApprovedNotification':
                    $this->kycApprovedMailSender($job);
                    break;
            }

        }
    }

    public function kycApprovedMailSender($job)
    {
        $user = app()->make(UserRepository::class)->findById($job->user_id);
        $user->notify(new UserKycApproved());
        $job->status = 'done';
        $job->save();
    }

    /**
     * Method resetMailSender
     *
     * @param $job $job [explicite description]
     * @return void
     */
    public function resetMailSender($job)
    {

        $user = app()->make(UserRepository::class)->findById($job->user_id);
        $user->notify(new KYCAdminResubmitNotification($job->step, $job->reason));
        $job->status = 'done';
        $job->save();
    }
}
