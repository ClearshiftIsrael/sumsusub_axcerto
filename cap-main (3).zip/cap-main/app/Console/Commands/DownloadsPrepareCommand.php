<?php

namespace App\Console\Commands;

use App\Enums\DownloadStatusEnum;
use App\Jobs\DownloadPrepareJob;
use App\Repositories\Eloquent\Users\UserInfoRepository;
use App\Repositories\Eloquent\Users\UserRepository;
use Illuminate\Console\Command;

class DownloadsPrepareCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'prepare:downloads';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Prepare Downloads';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        $userRepository = app()->make(UserRepository::class);
        $userInfoRepo = app()->make(UserInfoRepository::class);
        // user repository

        $notPreparedButSuccess = $userRepository->getKycSuccessAndDownloadableUsers();
        foreach ($notPreparedButSuccess as $key => $user) {
            DownloadPrepareJob::dispatch($user);
            $userInfoId = $userInfoRepo->findByColumn(['user_id' => $user])->id;
            $userInfoRepo->update($userInfoId, ['is_download_prepared' => DownloadStatusEnum::Preparing]);
        }

        return Command::SUCCESS;
    }
}
