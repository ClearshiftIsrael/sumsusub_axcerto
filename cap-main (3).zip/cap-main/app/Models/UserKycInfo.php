<?php

namespace App\Models;

use App\Enums\KYCAdminStatusEnum;
use App\Enums\KYCStatusEnum;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserKycInfo extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'applicationId',
        'moderationComment',
        'adminComment',
        'rejectLabels',
        'userKey',
        'status',
        'has_job',
        'admin_status',
        'doc_number',
        'kyc_docs',
    ];

    protected $appends = [
        'created_at_human',
        'updated_at_human',
        'selfie_url',
        'id_urls',
    ];

    protected $casts = [
        'status' => KYCStatusEnum::class,
        'admin_status' => KYCAdminStatusEnum::class,
        'kyc_docs' => 'array',
    ];

    /**
     * @return [type]
     */
    public function getSelfieUrlAttribute()
    {
        if ($docs = $this->kyc_docs) {
            if (isset($docs['SELFIE']) && is_array($docs['SELFIE']['files']) && count($docs['SELFIE']['files']) > 0) {
                // The 'SELFIE' key exists, 'files' is an array, and it contains at least one item.
                // dd($docs['SELFIE']['files'][0]['url']);
                return config('app.url').$docs['SELFIE']['files'][0]['url'];
            }
        }

        return '';
    }

    /**
     * @return [type]
     */
    public function getIdUrlsAttribute()
    {
        $pathArray = [];
        if ($docs = $this->kyc_docs) {
            if (isset($docs['IDENTITY']) && is_array($docs['IDENTITY']['files']) && count($docs['IDENTITY']['files']) > 0) {
                foreach ($docs['IDENTITY']['files'] as $path) {
                    array_push($pathArray, config('app.url').$path['url']);
                }
            }
        }

        return $pathArray;
    }

    /**
     * Method getCreatedAtHumanAttribute
     *
     * @return void
     */
    public function getCreatedAtHumanAttribute()
    {
        return $this->created_at->format('M d ,Y h:i:a');
    }

    /**
     * Method getUpdatedAtHumanAttribute
     *
     * @return void
     */
    public function getUpdatedAtHumanAttribute()
    {
        return $this->updated_at->format('M d ,Y h:i:a');
    }

    /**
     * Method user
     *
     * @return void
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
