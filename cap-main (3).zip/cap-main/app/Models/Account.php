<?php

namespace App\Models;

use App\Enums\AccountStatusEnum;
use App\Enums\AccountTeamRoleEnum;
use App\Enums\AccountTypeEnum;
use App\Enums\AccountVerificationStatusEnum;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Kodeine\Metable\Metable;
use Illuminate\Support\Str;

class Account extends Model
{
    use HasFactory, Metable;

    protected $fillable = [
        'name',
        'applicant_id',
        'user_key',
        'verification_level',
        'kyc_status',
        'status',
        'type',
    ];


    protected $appends = [
        'account_name', 'created_at_human', 'role_of_me'
    ];

    protected $casts = [
        'type' => AccountTypeEnum::class,
        'status' => AccountStatusEnum::class,
        'kyc_status' => AccountVerificationStatusEnum::class
    ];

    /**
     * @param  mixed  $query
     * @return [type]
     */
    public function scopeFilter($query, array $filters, $for = "public")
    {
        $query->when($filters['searchParam'] ?? null, function ($query, $search) {
            $query->where(function ($query) use ($search) {
                $query->where('name', 'like', '%' . $search . '%');
            });
        })
            ->where('status', AccountStatusEnum::Active->value);
        if(!array_key_exists('site', $filters)){
            $query->whereHas('teams', function ($query) {
                    $query->where('user_id', Auth::user()->id)
                        ->where('role', AccountTeamRoleEnum::Owner->value);
                });// change for load only owner accounts
        }
    }
    /**
     * @param  mixed  $query
     * @param  mixed  $column
     * @param  string  $direction
     * @return [type]
     */
    public function scopeOrderByColumn($query, $column, $direction = 'asc')
    {
        $query->orderBy($column, $direction);
    }
    /**
     * Method getNameAttribute
     *
     * @return void
     */
    public function getAccountNameAttribute()
    {
        if ($this->type == AccountTypeEnum::Individual) {
            return "$this->first_name $this->last_name";
        } else {
            return "$this->business_name";
        }
    }
    /**
     * @return [type]
     */
    public function getCreatedAtHumanAttribute()
    {
        return Carbon::parse($this->created_at)->format('M d, Y');
    }


    // public function getVericationStatusTitleAttribute(){
    //     return Str::title($this->kyc_status);
    // }

    public function getRoleOfMeAttribute()
    {
        if (Auth::user()) {
            return AccountTeam::where('account_id', $this->id)->where('user_id', Auth::id())->first()?->role?->name;
        }
    }

    /**
     * users
     *
     * @return void
     */
    public function users()
    {
        return $this->belongsToMany(User::class, 'account_teams', 'account_id', 'user_id')->withPivot(['role']);
    }

    /**
     * @return [type]
     */
    public function teams()
    {
        return $this->hasMany(AccountTeam::class, 'account_id', 'id');
    }
}
