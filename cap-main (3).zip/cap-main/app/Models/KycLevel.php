<?php

namespace App\Models;

use App\Enums\IsKYCDefaultEnum;
use App\Enums\KYCLevelStatusEnum;
use App\Enums\KYCLevelTypeEnum;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

class KycLevel extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'key',
        'description',
        'default',
        'level_type',
        'status',
    ];

    protected $appends = [
        'created_at_human',
    ];

    protected $casts = [
        'default' => IsKYCDefaultEnum::class,
        'level_type' => KYCLevelTypeEnum::class,
        'status' => KYCLevelStatusEnum::class
    ];

    /**
     * @return [type]
     */
    public function getCreatedAtHumanAttribute()
    {
        return Carbon::parse($this->created_at)->format('M d, Y');
    }

    /**
     * @param  mixed  $query
     * @param  mixed  $column
     * @param  string  $direction
     * @return [type]
     */
    public function scopeOrderByColumn($query, $column, $direction = 'asc')
    {
        $query->orderBy($column, $direction);
    }

    /**
     * @param  mixed  $query
     * @return [type]
     */
    public function scopeFilter($query, array $filters)
    {
        $query->when($filters['searchParam'] ?? null, function ($query, $search) {
            $query->where(function ($query) use ($search) {
                $query->where('name', 'like', '%'.$search.'%')
                    ->orWhere('key', 'like', '%'.$search.'%');
            });
        });
    }
}
