<?php

namespace App\Models;

use App\Enums\KYCStatusEnum;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AccountStage extends Model
{
    use HasFactory;

    protected $fillable=[
        'accounts_id',
        'moderationComment',
        'adminComment',
        'rejectLabels',
        'status',
        'is_current',
    ];

    protected $casts=[
        'status' => KYCStatusEnum::class,
    ];
}
