<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;

use App\Enums\AccountStatusEnum;
use App\Enums\AccountTypeEnum;
use App\Enums\IsLoggedInEnum;
use App\Enums\KYCStatusEnum;
use App\Enums\LoginProviderEnum;
use App\Enums\UserNotifyEnum;
use App\Enums\UserRoleEnum;
use App\Enums\UserStepEnum;
use App\Enums\UserTypeEnum;
use App\Notifications\User\Password\PasswordResetNotification;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;
use Kodeine\Metable\Metable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Metable, Notifiable, SoftDeletes;

    protected $metaKeyName = 'user_id';

    protected $metaTable = 'users_meta';

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'username',
        'first_name',
        'last_name',
        'email',
        'password',
        'role',
        'kyc_level_id',
        'language',
        'is_logged_in',
        'business_id',
        'type',
        'step',
        'notify_status',
        'applicant_id',
        'twofa_enabled_at',
        'twofa_code',
        'login_code',
        'provider',
        'provider_id',
        'provider_token',
        'provider_refresh_token',
        'is_invited'
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'role' => UserRoleEnum::class,
        'is_logged_in' => IsLoggedInEnum::class,
        'type' => UserTypeEnum::class,
        'notify_status' => UserNotifyEnum::class,
        'provider' => LoginProviderEnum::class,
        'step' => UserStepEnum::class,
    ];

    protected $appends = [
        'created_at_human', 'deleted_at_human', 'name', 'login_url', 'image_url', 'summary_url','accounts_count', 'active_accounts_count'
    ];

    /**
     * @return [type]
     */
    public function getDeletedAtHumanAttribute()
    {
        if ($this->deleted_at) {
            return Carbon::parse($this->deleted_at)->format('M d, Y');
        }

        return null;
    }

    /**
     * sendPasswordResetNotification
     *
     * @param  mixed  $token
     * @return void
     */
    public function sendPasswordResetNotification($token)
    {
        $user = $this->full_name;
        $email = $this->email;
        $this->notify(new PasswordResetNotification($token, $user, $email));
    }

    /**
     * @return [type]
     */
    public function getSummaryUrlAttribute()
    {
        if ($summary = $this->getMeta('summary')) {
            return config('app.url') . Storage::url($summary);
        }

        return '';
    }

    /**
     * @return [type]
     */
    public function getImageUrlAttribute()
    {
        if ($this->kycInfo) {
            return $this->kycInfo->selfie_url ?? '';
        }

        return '';
    }

    /**
     * @return [type]
     */
    public function getCreatedAtHumanAttribute()
    {
        return Carbon::parse($this->created_at)->format('M d, Y');
    }

    /**
     * @return [type]
     */
    public function getLoginUrlAttribute()
    {
        // $id  = md5($this->id);
        return config('app.url') . '/login/auto?cred=' . md5($this->id);
    }

    /**
     * @return [type]
     */
    protected static function boot()
    {
        parent::boot();

        static::creating(function ($user) {
            // Concatenate the first and last names to create the 'name'
            if (!$user->username) {
                $user->username = Str::slug($user->first_name . '-' . $user->last_name);
            }
        });
    }

    /**
     * @param  mixed  $query
     * @param  mixed  $column
     * @param  string  $direction
     * @return [type]
     */
    public function scopeOrderByColumn($query, $column, $direction = 'asc')
    {
        $query->orderBy($column, $direction);
    }

    /**
     * @param  mixed  $query
     * @return [type]
     */
    public function scopeFilter($query, array $filters)
    {
        $query->where('role', UserRoleEnum::Customer->value)->withTrashed();
        switch ($filters['type']) {
            case 'kyc':
                $query->where('type', UserTypeEnum::Customer->value);
                break;
            case 'kyb':
                $query->where('type', UserTypeEnum::Business->value);
                break;
        }

        $query->when($filters['searchParam'] ?? null, function ($query, $search) {
            $query->where(function ($query) use ($search) {
                $query->where('username', 'like', '%' . $search . '%')
                    ->orWhere('email', 'like', '%' . $search . '%');
            });
        });
    }

    /**
     * @param  mixed  $roles
     * @return [type]
     */
    public function hasAnyRole($roles)
    {
        if (is_array($roles)) {
            foreach ($roles as $role) {
                if ($this->role->value === $role) {
                    return true;
                }
            }
        } else {
            if ($this->role === $roles) {
                return true;
            }
        }

        return false;
    }

    /**
     * Method getNameAttribute
     *
     * @return string
     */
    public function getNameAttribute()
    {
        return "$this->first_name $this->last_name";
    }

     /**
     * users
     *
     * @return mixed
     */
    public function accounts(){
        return $this->belongsToMany(Account::class,'account_teams','user_id','account_id')->where('status', AccountStatusEnum::Active->value)->withPivot(['role']);
    }

    /**
     * @return [type]
     */
    public function individualAccounts(){
        return $this->belongsToMany(Account::class, 'account_teams', 'user_id', 'account_id')->where('type', AccountTypeEnum::Individual->value)->where('status', AccountStatusEnum::Active->value)->withPivot(['role']);
    }

    /**
     * @return [type]
     */
    public function getAccountsCountAttribute(){
        return $this->belongsToMany(Account::class,'account_teams','user_id','account_id')->count();
    }
    /**
     * @return [type]
     */
    public function getActiveAccountsCountAttribute()
    {
        return $this->belongsToMany(Account::class, 'account_teams', 'user_id', 'account_id')->where('status', AccountStatusEnum::Active->value)->count();
    }
}
