<?php

namespace App\Models;

use App\Enums\AccountTeamRoleEnum;
use App\Enums\TeamInvitationStatusEnum;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AccountTeam extends Model
{
    use HasFactory;

    protected $fillable=[
        'account_id',
        'user_id',
        'role',
        'code',
        'invitation_status'
    ];

    protected $casts = [
        'role' => AccountTeamRoleEnum::class,
        'invitation_status' => TeamInvitationStatusEnum::class
    ];
    
    /**
     * account
     *
     * @return void
     */
    public function account() {
        return $this->belongsTo(Account::class);
    }
    
    /**
     * user
     *
     * @return void
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
