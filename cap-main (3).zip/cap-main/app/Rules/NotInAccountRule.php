<?php

namespace App\Rules;

use App\Repositories\Eloquent\Accounts\AccountsRepository;
use Closure;
use Illuminate\Contracts\Validation\ValidationRule;

class NotInAccountRule implements ValidationRule
{
    protected $accountId;
    public function __construct($accountId) {
        $this->accountId= $accountId;
    }
    /**
     * Run the validation rule.
     *
     * @param  \Closure(string): \Illuminate\Translation\PotentiallyTranslatedString  $fail
     */
    public function validate(string $attribute, mixed $value, Closure $fail): void
    {
        $accountRepository = app()->make(AccountsRepository::class);
        $resp = $accountRepository->validateAccountWithEmail($value,$this->accountId);
        if($resp){
            $fail('This user has access to the account already.');
        }
    }
}
