<?php

namespace App\Rules\User;

use App\Enums\KYCLevelTypeEnum;
use App\Repositories\Eloquent\KycLevel\KycLevelRepository;
use Illuminate\Contracts\Validation\Rule;

class BusinessCheckRule implements Rule
{
    protected $business;

    public function __construct($business)
    {
        $this->business = $business;
    }

    /**
     * @param  mixed  $attribute
     * @param  mixed  $value
     * @return [type]
     */
    public function passes($attribute, $value)
    {
        if (is_string($value) && $value == KYCLevelTypeEnum::KYB->value) {
            return ! empty($this->business);
        } else {
            if (! is_string($value)) {
                $type = app()->make(KycLevelRepository::class)->findById($value)->level_type;
                if ($type === KYCLevelTypeEnum::KYB) {
                    return ! empty($this->business);
                }
            }
        }

        return true;
    }

    public function message()
    {
        return 'The business name is required for KYB level.';
    }
}
