<?php

namespace App\Repositories\Interfaces\Questionary;

use App\Repositories\Base\EloquentRepositoryInterface;

interface QuestionaryRepositoryInterface extends EloquentRepositoryInterface
{
}
