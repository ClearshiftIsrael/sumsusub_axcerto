<?php

namespace App\Repositories\Interfaces\WebHooks;

use App\Repositories\Base\EloquentRepositoryInterface;

interface WebHooksRepositoryInterface extends EloquentRepositoryInterface
{
}
