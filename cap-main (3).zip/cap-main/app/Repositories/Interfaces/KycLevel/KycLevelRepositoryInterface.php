<?php

namespace App\Repositories\Interfaces\KycLevel;

use App\Repositories\Base\EloquentRepositoryInterface;

interface KycLevelRepositoryInterface extends EloquentRepositoryInterface
{
}
