<?php

namespace App\Repositories\Interfaces\Business;

use App\Repositories\Base\EloquentRepositoryInterface;

interface BusinessRepositoryInterface extends EloquentRepositoryInterface
{
}
