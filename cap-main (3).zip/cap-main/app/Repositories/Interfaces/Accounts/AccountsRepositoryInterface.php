<?php

namespace App\Repositories\Interfaces\Accounts;

use App\Repositories\Base\EloquentRepositoryInterface;

interface AccountsRepositoryInterface extends EloquentRepositoryInterface
{
}
