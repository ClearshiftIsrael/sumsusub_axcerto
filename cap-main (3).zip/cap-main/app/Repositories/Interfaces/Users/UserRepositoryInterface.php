<?php

namespace App\Repositories\Interfaces\Users;

use App\Repositories\Base\EloquentRepositoryInterface;

interface UserRepositoryInterface extends EloquentRepositoryInterface
{
}
