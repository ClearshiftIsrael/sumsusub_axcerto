<?php

namespace App\Repositories\Interfaces\Users;

use App\Repositories\Base\EloquentRepositoryInterface;

interface UserInfoRepositoryInterface extends EloquentRepositoryInterface
{
}
