<?php

namespace App\Repositories\Eloquent\Questionary;

use App\Models\questionnaire;
use App\Repositories\Base\BaseRepository;
use App\Repositories\Interfaces\Questionary\QuestionaryRepositoryInterface;

class QuestionaryRepository extends BaseRepository implements QuestionaryRepositoryInterface
{
    /**
     * @var Model
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @param  Model  $model
     */
    public function __construct(questionnaire $model)
    {
        $this->model = $model;
    }
}
