<?php

namespace App\Repositories\Eloquent\KycLevel;

use App\Models\KycLevel;
use App\Repositories\Base\BaseRepository;
use App\Repositories\Interfaces\KycLevel\KycLevelRepositoryInterface;

class KycLevelRepository extends BaseRepository implements KycLevelRepositoryInterface
{
    /**
     * @var Model
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @param  Model  $model
     */
    public function __construct(KycLevel $model)
    {
        $this->model = $model;
    }
}
