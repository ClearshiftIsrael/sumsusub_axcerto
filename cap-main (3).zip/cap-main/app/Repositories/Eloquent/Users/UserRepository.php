<?php

namespace App\Repositories\Eloquent\Users;

use App\Enums\DownloadStatusEnum;
use App\Enums\KYCStatusEnum;
use App\Models\User;
use App\Repositories\Base\BaseRepository;
use App\Repositories\Interfaces\Users\UserRepositoryInterface;
use Illuminate\Database\Eloquent\Collection;

class UserRepository extends BaseRepository implements UserRepositoryInterface
{
    /**
     * @var Model
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @param  Model  $model
     */
    public function __construct(User $model)
    {
        $this->model = $model;
    }

    /**
     * @param  mixed  $filters
     * @param  array  $with
     * @return [type]
     */
    public function filterCustomer($filters, $with = [])
    {
        $query = $this->model->filter($filters)->orderByColumn($filters['sortBy'], $filters['sortDirection']);
        if (count($with) > 0) {
            $query = $query->with($with);
        }
        $query = $query->where('role', 'customer');

        return $query->paginate($filters['rowPerPage'])->appends($filters);
    }

    /**
     * Method getByRoles
     *
     * @param  array  $roles [explicite description]
     */
    public function getByRoles(array $roles): ?Collection
    {
        return $this->model->whereIn('role', $roles)->get();
    }

    /**
     * @param  mixed  $filters
     * @param  array  $with
     * @return [type]
     */
    public function searchCustomer($filters, $with = [])
    {
        return $this->model->searchCustomer($filters, $with);
    }

    /**
     * Method getKycSuccessAndDownloadableUsers
     *
     * @return void
     */
    public function getKycSuccessAndDownloadableUsers()
    {
        return $this->model->whereHas('kycInfo', function ($query) {
            $query->where('status', KYCStatusEnum::Success->value)->whereNotNull('applicationId');
        })->whereHas('userInfo', function ($query) {
            $query->where('is_download_prepared', DownloadStatusEnum::No->value);
        })->get();
    }

    /**
     * @param  mixed  $md5Id
     * @return [type]
     */
    public function getUserByMd5Id($md5Id)
    {
        return $this->model->whereRaw('md5(id) = "'.$md5Id.'"')->first();
    }

    /**
     * @param  mixed  $user
     * @return [type]
     */
    public function getShareholders($user)
    {
        return $this->model->withTrashed()->where('business_id', $user->business_id)->whereNot('id', $user->id)->whereNotNull('business_id')->get();
    }
}
