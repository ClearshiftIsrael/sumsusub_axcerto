<?php

namespace App\Repositories\Eloquent\Users;

use App\Models\UserInfo;
use App\Repositories\Base\BaseRepository;
use App\Repositories\Interfaces\Users\UserInfoRepositoryInterface;
use Illuminate\Database\Eloquent\Collection;

class UserInfoRepository extends BaseRepository implements UserInfoRepositoryInterface
{
    /**
     * @var Model
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @param  Model  $model
     */
    public function __construct(UserInfo $model)
    {
        $this->model = $model;
    }

    /**
     * @param  mixed  $filters
     * @param  array  $with
     * @return [type]
     */
    public function filterCustomer($filters, $with = [])
    {
        $query = $this->model->filter($filters)->orderByColumn($filters['sortBy'], $filters['sortDirection']);
        if (count($with) > 0) {
            $query = $query->with($with);
        }
        $query = $query->where('role', 'customer');

        return $query->paginate($filters['rowPerPage'])->appends($filters);
    }

    /**
     * Method getByRoles
     *
     * @param  array  $roles [explicite description]
     */
    public function getByRoles(array $roles): ?Collection
    {
        return $this->model->whereIn('role', $roles)->get();
    }

    /**
     * @param  mixed  $filters
     * @param  array  $with
     * @return [type]
     */
    public function searchCustomer($filters, $with = [])
    {
        return $this->model->searchCustomer($filters, $with);
    }
}
