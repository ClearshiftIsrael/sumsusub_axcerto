<?php

namespace App\Repositories\Eloquent\Accounts;

use App\Models\AccountTeam;
use App\Repositories\Base\BaseRepository;
use App\Repositories\Interfaces\Accounts\AccountsTeamRepositoryInterface;

class AccountsTeamRepository extends BaseRepository implements AccountsTeamRepositoryInterface
{
    /**
     * @var Model
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @param  Model  $model
     */
    public function __construct(AccountTeam $model)
    {
        $this->model = $model;
    }
}
