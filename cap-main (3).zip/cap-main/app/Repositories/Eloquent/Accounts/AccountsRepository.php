<?php

namespace App\Repositories\Eloquent\Accounts;

use App\Models\Account;
use App\Repositories\Base\BaseRepository;
use App\Repositories\Interfaces\Accounts\AccountsRepositoryInterface;

class AccountsRepository extends BaseRepository implements AccountsRepositoryInterface
{
    /**
     * @var Model
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @param  Model  $model
     */
    public function __construct(Account $model)
    {
        $this->model = $model;
    }

    
    /**
     * getAccount
     *
     * @param  mixed $accountId
     * @param  mixed $userId
     * @return mixed
     */
    public function getAccount($accountId, $userId,$relations=[])
    {
        return $this->model->where('id', $accountId)->whereHas('users', function ($q) use ($userId) {
            $q->where('user_id', $userId);
        })->with($relations)->first();
    }

    
    /**
     * validateAccountWithEmail
     *
     * @param  mixed $email
     * @param  mixed $accountId
     * @return void
     */
    public function validateAccountWithEmail($email,$accountId) {
        return $this->model->where('id', $accountId)->whereHas('users', function($q) use ($email){
            $q->where('email', $email);
        })->exists();
    }
}
