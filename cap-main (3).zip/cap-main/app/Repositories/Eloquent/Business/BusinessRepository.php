<?php

namespace App\Repositories\Eloquent\Business;

use App\Models\Business;
use App\Repositories\Base\BaseRepository;
use App\Repositories\Interfaces\Business\BusinessRepositoryInterface;

class BusinessRepository extends BaseRepository implements BusinessRepositoryInterface
{
    /**
     * @var Model
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @param  Model  $model
     */
    public function __construct(Business $model)
    {
        $this->model = $model;
    }
}
