<?php

namespace App\Repositories\Eloquent\WebHooks;

use App\Models\Webhook;
use App\Repositories\Base\BaseRepository;
use App\Repositories\Interfaces\WebHooks\WebHooksRepositoryInterface;

class WebHooksRepository extends BaseRepository implements WebHooksRepositoryInterface
{
    /**
     * @var Model
     */
    protected $model;

    /**
     * BaseRepository constructor.
     *
     * @param  Model  $model
     */
    public function __construct(Webhook $model)
    {
        $this->model = $model;
    }
}
