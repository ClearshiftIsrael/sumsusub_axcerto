<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
    xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <!--[if !mso]><!-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--<![endif]-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style type="text/css">
        #outlook a {
            padding: 0;
        }

        body {
            margin: 0;
            padding: 0;
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
        }

        table,
        td {
            border-collapse: collapse;
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }

        img {
            border: 0;
            height: auto;
            line-height: 100%;
            outline: none;
            text-decoration: none;
            -ms-interpolation-mode: bicubic;
        }

        p {
            display: block;
            margin: 13px 0;
        }
    </style>
    <!--[if mso]>
        <noscript>
        <xml>
        <o:OfficeDocumentSettings>
          <o:AllowPNG/>
          <o:PixelsPerInch>96</o:PixelsPerInch>
        </o:OfficeDocumentSettings>
        </xml>
        </noscript>
        <![endif]-->
    <!--[if lte mso 11]>
        <style type="text/css">
          .mj-outlook-group-fix { width:100% !important; }
        </style>
        <![endif]-->
    <style type="text/css">
        @media only screen and (min-width:480px) {
            .mj-column-per-100 {
                width: 100% !important;
                max-width: 100%;
            }

            .mj-column-per-50 {
                width: 50% !important;
                max-width: 50%;
            }
        }
    </style>
    <style media="screen and (min-width:480px)">
        .moz-text-html .mj-column-per-100 {
            width: 100% !important;
            max-width: 100%;
        }

        .moz-text-html .mj-column-per-50 {
            width: 50% !important;
            max-width: 50%;
        }
    </style>
    <style type="text/css">
        @media only screen and (max-width:480px) {
            table.mj-full-width-mobile {
                width: 100% !important;
            }

            td.mj-full-width-mobile {
                width: auto !important;
            }
        }
    </style>
    <style type="text/css">
        @media (max-width: 479px) {
            .hide-on-mobile {
                display: none !important;
            }
        }

        .gr-headerviewonline-spwnud a,
        .gr-headerviewonline-spwnud a:visited {
            color: #808080;
            text-decoration: none;
        }

        .gr-mlimage-fyiqgq img {
            box-sizing: border-box;
        }

        @media (min-width: 480px) {
            .gr-mlimage-ahkjij {
                height: 38px !important;
            }
        }

        .gr-mltext-bjqbda a,
        .gr-mltext-bjqbda a:visited {
            text-decoration: none;
        }

        .gr-mltext-xhcgpw a,
        .gr-mltext-xhcgpw a:visited {
            text-decoration: none;
        }

        .gr-mltext-txdwed a,
        .gr-mltext-txdwed a:visited {
            text-decoration: none;
        }

        .gr-mltext-lqbrnc a,
        .gr-mltext-lqbrnc a:visited {
            text-decoration: none;
        }

        .gr-mlbutton-xaebgv p {
            direction: ltr;
        }

        .gr-mltext-aruycn a,
        .gr-mltext-aruycn a:visited {
            text-decoration: none;
        }

        .gr-mltext-aowlpd a,
        .gr-mltext-aowlpd a:visited {
            text-decoration: none;
        }

        .gr-footer-edkydp a,
        .gr-footer-edkydp a:visited {
            color: #7E7E7E;
            text-decoration: underline;
        }
    </style>
    <link
        href="https://fonts.googleapis.com/css?display=swap&family=Roboto:400,400i,700,700i|Libre Baskerville:400,400i,700,700i|serif:400,400i,700,700i&subset=cyrillic,greek,latin-ext,vietnamese"
        rel="stylesheet" type="text/css">
    <style type="text/css">
        @import url(https://fonts.googleapis.com/css?display=swap&family=Roboto:400,400i,700,700i|Libre Baskerville:400,400i,700,700i|serif:400,400i,700,700i&subset=cyrillic,greek,latin-ext,vietnamese);
    </style>
</head>



<body style="word-spacing:normal;background-color:#F8F8F8;">
    <div style="background-color:#F8F8F8;">
        <!--[if mso | IE]><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:center;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                    width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td align="center"
                                                                class="gr-headerviewonline-vpmait gr-headerviewonline-spwnud"
                                                                style="font-size:0px;padding:20px 0 10px 0;word-break:break-word;">

                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                    <tr style="text-align:center">
                        <td align="center" class="gr-mltext-sdeipq gr-mltext-bjqbda"
                            style="font-size:0px;padding:0;word-break:break-word;text-align:center;">
                            <div
                                style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:center;color:#000000;">
                                <div style="text-align: center;">
                                    <p
                                        style="text-align:center;font-family:Arial;font-size:10px;margin-top:0px;margin-bottom:16px;font-weight:normal;color:#000000;">
                                        <strong>
                                            <span style="font-size: 10px">
                                                <span style="font-family: Libre Baskerville, Georgia, serif">
                                                    Please verify your access
                                                </span>
                                            </span>
                                        </strong>
                                    </p>
                                </div>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#FFFFFF" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                    width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:30px;line-height:30px;">&#8202;</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="center" class="gr-mltext-sdeipq gr-mltext-bjqbda"
                                                                style="font-size:0px;padding:0;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:center;color:#000000;">
                                                                    <div style="text-align: center;">
                                                                        <p
                                                                            style="text-align:center;font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <strong><span style="font-size: 28px"><span
                                                                                        style="font-family: Libre Baskerville, Georgia, serif">@yield("title")</span></span></strong>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:5px;line-height:5px;">&#8202;</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="center"
                                                                style="font-size:0px;padding:20px;word-break:break-word;">
                                                                <p
                                                                    style="border-top:solid 1px #213963;font-size:1px;margin:0px auto;width:100%;">
                                                                </p>
                                                                <!--[if mso | IE]><table align="center" border="0" cellpadding="0" cellspacing="0" style="border-top:solid 1px #213963;font-size:1px;margin:0px auto;width:480px;" role="presentation" width="480px" ><tr><td style="height:0;line-height:0;"> &nbsp;</td></tr></table><![endif]-->
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:3px;line-height:3px;">&#8202;</div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        @yield('content')
        <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#FFFFFF" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                    width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td align="left" class="gr-mltext-sdeipq gr-mltext-aruycn"
                                                                style="font-size:0px;padding:17px 0 0 0;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:left;color:#000000;">
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #222222"><span
                                                                                    style="font-size: 14.666666666666666px"><span
                                                                                        style="font-family: Arial, sans-serif"><span
                                                                                            style="font-weight: 400"><span
                                                                                                style="background-color: transparent">
                                                                                                Best Regards,
                                                                                            </span>
                                                                                        </span>
                                                                                    </span>
                                                                                </span>
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #222222"><span
                                                                                    style="font-size: 14.666666666666666px"><span
                                                                                        style="font-family: Arial, sans-serif"><span
                                                                                            style="font-weight: 400"><span
                                                                                                style="background-color: transparent">@yield("institution")
                                                                                                - Clearshift Team
                                                                                            </span></span></span></span></span>
                                                                        </p>
                                                                         <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #222222"><span
                                                                                    style="font-size: 14.666666666666666px"><span
                                                                                        style="font-family: Arial, sans-serif"><span
                                                                                            style="font-weight: 400"><span
                                                                                                style="background-color: transparent">@yield("institution")
                                                                                                Call Us: (+972)39155726
                                                                                            </span></span></span></span></span>
                                                                        </p>
                                                                         <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #222222"><span
                                                                                    style="font-size: 14.666666666666666px"><span
                                                                                        style="font-family: Arial, sans-serif"><span
                                                                                            style="font-weight: 400"><span
                                                                                                style="background-color: transparent">@yield("institution")
                                                                                                Mail Us: support@clearshiftinc.com
                                                                                            </span></span></span></span></span>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <br>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <br>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#213963" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="background:#213963;background-color:#213963;margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="background:#213963;background-color:#213963;width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                    width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td align="left" class="gr-mltext-sdeipq gr-mltext-aowlpd"
                                                                style="font-size:0px;padding:10px;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.4;text-align:left;color:#000000;">
                                                                    <div style="text-align: center;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #FFFFFF">@ {{ date('Y')
                                                                                }} {{ __('mails.footer-credentials')
                                                                                }}.</span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 20px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:560px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                    width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:20px;line-height:20px;">&#8202;</div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    </div>
</body>

</html>