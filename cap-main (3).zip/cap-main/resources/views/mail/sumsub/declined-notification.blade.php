
{{-- <x-mail::message>
# Hello user,

Your application approved.

<x-mail::button :url="''">
Button Text
</x-mail::button>

Thanks,<br>
{{ config('app.name') }}
</x-mail::message> --}}
{{-- ////////////////////////////////////////////////////////////////////////////////////////////////////////////// --}}
<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
    xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <title></title><!--[if !mso]><!-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge"><!--<![endif]-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style type="text/css">
        #outlook a {
            padding: 0;
        }

        body {
            margin: 0;
            padding: 0;
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
        }

        table,
        td {
            border-collapse: collapse;
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }

        img {
            border: 0;
            height: auto;
            line-height: 100%;
            outline: none;
            text-decoration: none;
            -ms-interpolation-mode: bicubic;
        }

        p {
            display: block;
            margin: 13px 0;
        }
    </style><!--[if mso]>
        <noscript>
        <xml>
        <o:OfficeDocumentSettings>
          <o:AllowPNG/>
          <o:PixelsPerInch>96</o:PixelsPerInch>
        </o:OfficeDocumentSettings>
        </xml>
        </noscript>
        <![endif]--><!--[if lte mso 11]>
        <style type="text/css">
          .mj-outlook-group-fix { width:100% !important; }
        </style>
        <![endif]-->
    <style type="text/css">
        @media only screen and (min-width:480px) {
            .mj-column-per-100 {
                width: 100% !important;
                max-width: 100%;
            }
        }
    </style>
    <style media="screen and (min-width:480px)">
        .moz-text-html .mj-column-per-100 {
            width: 100% !important;
            max-width: 100%;
        }
    </style>
    <style type="text/css">
        @media only screen and (max-width:480px) {
            table.mj-full-width-mobile {
                width: 100% !important;
            }

            td.mj-full-width-mobile {
                width: auto !important;
            }
        }
    </style>
    <style type="text/css">
        @media (max-width: 479px) {
            .hide-on-mobile {
                display: none !important;
            }
        }

        .gr-headerviewonline-vkrbhx a,
        .gr-headerviewonline-vkrbhx a:visited {
            color: #808080;
            text-decoration: none;
        }

        .gr-mlimage-wyaklh img {
            box-sizing: border-box;
        }

        @media (min-width: 480px) {
            .gr-mlimage-mftlhk {
                height: 38px !important;
            }
        }

        .gr-mltext-nhdoef a,
        .gr-mltext-nhdoef a:visited {
            text-decoration: none;
        }

        .gr-mltext-huslrm a,
        .gr-mltext-huslrm a:visited {
            text-decoration: none;
        }

        .gr-mlbutton-chigyn p {
            direction: ltr;
        }

        .gr-mltext-cxesir a,
        .gr-mltext-cxesir a:visited {
            text-decoration: none;
        }

        .gr-mltext-uvfosm a,
        .gr-mltext-uvfosm a:visited {
            text-decoration: none;
        }

        .gr-mltext-baqhxx a,
        .gr-mltext-baqhxx a:visited {
            text-decoration: none;
        }

        .gr-footer-kpljnd a,
        .gr-footer-kpljnd a:visited {
            color: #7E7E7E;
            text-decoration: underline;
        }
    </style>
    <link
        href="https://fonts.googleapis.com/css?display=swap&family=Roboto:400,400i,700,700i|Libre Baskerville:400,400i,700,700i|serif:400,400i,700,700i&subset=cyrillic,greek,latin-ext,vietnamese"
        rel="stylesheet" type="text/css">
    <style type="text/css">
        @import url(https://fonts.googleapis.com/css?display=swap&family=Roboto:400,400i,700,700i|Libre Baskerville:400,400i,700,700i|serif:400,400i,700,700i&subset=cyrillic,greek,latin-ext,vietnamese);
    </style>
</head>

<body style="word-spacing:normal;background-color:#F8F8F8;">
    <div style="background-color:#F8F8F8;">
        <!--[if mso | IE]><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    role="presentation" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td align="center"
                                                                class="gr-headerviewonline-sstxsm gr-headerviewonline-vkrbhx"
                                                                style="font-size:0px;padding:20px 0 10px 0;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Roboto, Arial, sans-serif;font-size:10px;font-style:normal;line-height:1;text-align:center;text-decoration:none;color:#000000;">
                                                                    <div><a style="color: #808080;" href="#"
                                                                            target="_blank">View online</a></div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div><!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#FFFFFF" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    role="presentation" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:30px;line-height:30px;">&#8202;
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="center"
                                                                class="gr-mlimage-wyaklh gr-mlimage-mftlhk link-id-"
                                                                style="font-size:0px;padding:0;word-break:break-word;">
                                                                <table border="0" cellpadding="0" cellspacing="0"
                                                                    role="presentation"
                                                                    style="border-collapse:collapse;border-spacing:0px;">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td style="width:141px;"><img
                                                                                    alt="" height="auto"
                                                                                    src={{ asset("assets/image/logo.png") }}
                                                                                    style="border:0;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;border-bottom:0 none #000000;border-radius:0;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:13px;"
                                                                                    width="141"></td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:38px;line-height:38px;">&#8202;
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="left"
                                                                class="gr-mltext-jofcch gr-mltext-nhdoef"
                                                                style="font-size:0px;padding:0;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:left;color:#000000;">
                                                                    <div style="text-align: center;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000; text-align: center">
                                                                            <span style="color: #000000"><strong><span
                                                                                        style="font-size: 14.666666666666666px"><span
                                                                                            style="font-family: Arial, sans-serif"><span
                                                                                                style="font-weight: 700"><span
                                                                                                    style="background-color: transparent">
                                                                                                </span></span></span></span></strong></span><span
                                                                                style="color: #000000"><strong><span
                                                                                        style="font-size: 28px"><span
                                                                                            style="font-family: Libre Baskerville, Georgia, serif"><span
                                                                                                style="background-color: transparent">{{ __("mail.status.declined.title") }}</span></span></span></strong></span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:5px;line-height:5px;">&#8202;</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="center"
                                                                style="font-size:0px;padding:20px;word-break:break-word;">
                                                                <p
                                                                    style="border-top:solid 1px #008e9f;font-size:1px;margin:0px auto;width:100%;">
                                                                </p><!--[if mso | IE]><table align="center" border="0" cellpadding="0" cellspacing="0" style="border-top:solid 1px #008e9f;font-size:1px;margin:0px auto;width:480px;" role="presentation" width="480px" ><tr><td style="height:0;line-height:0;"> &nbsp;
</td></tr></table><![endif]-->
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:3px;line-height:3px;">&#8202;</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="left"
                                                                class="gr-mltext-jofcch gr-mltext-huslrm"
                                                                style="font-size:0px;padding:0;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:left;color:#000000;">
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><strong><span
                                                                                        style="font-size: 16px"><span
                                                                                            style="font-family: Roboto, Arial, sans-serif"><span
                                                                                                style="background-color: transparent">{{ __("mail.password.reset.dear") }}
                                                                                                {{ $user->name }},</span></span></span></strong></span>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <br>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif"><span
                                                                                            style="font-weight: 400"><span
                                                                                                style="background-color: transparent">Your application Declined by Sumsub verfaication platform.
                                                                                            </span></span></span></span></span>
                                                                        </p>
                                                                    </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div><!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#FFFFFF" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    role="presentation" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td align="left"
                                                                class="gr-mltext-jofcch gr-mltext-cxesir"
                                                                style="font-size:0px;padding:10px;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.4;text-align:left;color:#000000;">
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <br>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif"><span
                                                                                            style="font-weight: 400"><span
                                                                                                style="background-color: transparent">{{__( "mail.status.declined.intro")}}
                                                                                            </span></span></span></span></span>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <br>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif"><span
                                                                                            style="font-weight: 400"><span
                                                                                                style="background-color: transparent">{{__( "mail.status.declined.thanks.intro")}}</span></span></span></span></span>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <br>
                                                                        </p>
                                                                    </div>
                                                                    {{-- <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif"><span
                                                                                            style="font-weight: 400"><span
                                                                                                style="background-color: transparent">Enjoy
                                                                                                your
                                                                                                ride!</span></span></span></span></span>
                                                                        </p>
                                                                    </div> --}}
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="left"
                                                                class="gr-mltext-jofcch gr-mltext-uvfosm"
                                                                style="font-size:0px;padding:10px;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.4;text-align:left;color:#000000;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <br>
                                                                    </p>
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <span style="color: #000000"><span
                                                                                style="font-size: 16px"><span
                                                                                    style="font-family: Roboto, Arial, sans-serif"><span
                                                                                        style="font-weight: 400"><span
                                                                                            style="background-color: transparent">{{__("mail.status.declined.thanks")}}</span></span></span></span></span>
                                                                    </p>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif"><span
                                                                                            style="font-weight: 400"><span
                                                                                                style="background-color: transparent">Clearshift</span></span></span></span></span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div><!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#008e9f" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="background:#008e9f;background-color:#008e9f;margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="background:#008e9f;background-color:#008e9f;width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    role="presentation" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td align="left"
                                                                class="gr-mltext-jofcch gr-mltext-baqhxx"
                                                                style="font-size:0px;padding:10px;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.4;text-align:left;color:#000000;">
                                                                    <div style="text-align: center;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #FFFFFF">@2023 Clearshift
                                                                                , {{ __( "mail.footer") }}</span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div><!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 20px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:560px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    role="presentation" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:20px;line-height:20px;">&#8202;
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div><!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        {{-- <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    role="presentation" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td align="center"
                                                                class="gr-footer-lhjgdh gr-footer-kpljnd"
                                                                style="font-size:0px;padding:10px 0;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Roboto, Arial, sans-serif;font-size:10px;font-style:normal;line-height:1;text-align:center;text-decoration:none;color:#000000;">
                                                                    <div>LGH Platform, 15/6 Jayagath Road, Nawinna,
                                                                        10280, Maharagama, Sri Lanka<br><br>ඕනෑම
                                                                        අවස්ථාවක <a
                                                                            href="https://app.getresponse.com/unsubscribe.html?x=a62b&m=E&mc=J5&s=E&u=CKERi&z=EwiAQwc&pt=unsubscribe"
                                                                            target="_blank">ඔබගේ දායකත්වය ඉවත්
                                                                            කරගැනීමට</a> හෝ <a
                                                                            href="https://app.getresponse.com/change_details.html?x=a62b&m=E&s=E&u=CKERi&z=EQNJB5K&pt=change_details"
                                                                            target="_blank">ඔබගේ සම්බන්ධතා විස්තර වෙනස්
                                                                            කිරීමට</a> හැකිය.</div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div><!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div><!--[if mso | IE]></td></tr></table><![endif]-->
        <table align="center"
            style="font-family: 'Roboto', Helvetica, sans-serif; font-weight: 400; letter-spacing: .018em; text-align: center; font-size: 10px;">
            <tr>
                <td style="padding-bottom: 20px"><br />
                    <div style="color: #939598;">බලය ලබා දෙන්නේ:</div><a
                        href="https://app.getresponse.com/referral.html?x=a62b&c=XTPob&u=CKERi&z=ESsfStM&"><img
                            src="https://app.getresponse.com/images/common/templates/badges/gr_logo_2.png"
                            alt="GetResponse" border="0" style="display:block;" width="120"
                            height="24" /></a>
                </td>
            </tr>
        </table> --}}
    </div>
</body>

</html>

