@extends('layouts.mail-layout')

@section('title', 'Authorize your onboarding Platform login')

@section('content')
<!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#FFFFFF" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
<div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
    <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
        style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
        <tbody>
            <tr>
                <td
                    style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                    <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                    <div class="mj-column-per-100 mj-outlook-group-fix"
                        style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                        <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                            <tbody>
                                <tr>
                                    <td
                                        style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                        <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                            width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="left" class="gr-mltext-sdeipq gr-mltext-aruycn"
                                                        style="font-size:0px;padding:17px 0 0 0;word-break:break-word;">
                                                        <div
                                                            style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:left;color:#000000;">

                                                            <div style="text-align: justify;">
                                                                <p
                                                                    style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                    <br>
                                                                </p>
                                                            </div>
                                                            <div style="text-align: justify;">
                                                                <p
                                                                    style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                    <span style="color: #222222"><span
                                                                            style="font-size: 14.666666666666666px"><span
                                                                                style="font-family: Arial, sans-serif"><span
                                                                                    style="font-weight: 400"><span
                                                                                        style="background-color: transparent">Hello
                                                                                        {{ $user->full_name }} ,
                                                                                    </span></span></span></span></span>
                                                                </p>
                                                            </div>
                                                            <div style="margin-top:5px;text-align: justify;">
                                                                <p
                                                                    style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                    <span style="color: #222222"><span
                                                                            style="font-size: 16px"><span
                                                                                style="font-family: Roboto, Arial, sans-serif"><span
                                                                                    style="font-weight: 400"><span
                                                                                        style="background-color: transparent">
                                                                                        If you want to login to
                                                                                        clearshift onboarding system,
                                                                                        please,
                                                                                        enter the 6-digit code on the
                                                                                        sign in page for
                                                                                        confirmation.</span></span></span></span></span>
                                                                </p>
                                                            </div>
                                                            <div style="margin-top:40px;text-align: justify;">
                                                                <p
                                                                    style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                    <span style="color: #222222"><span
                                                                            style="font-size: 16px"><span
                                                                                style="font-family: Roboto, Arial, sans-serif"><span
                                                                                    style="font-weight: 400"><span
                                                                                        style="background-color: transparent">Code:
                                                                                        <strong>{{ $code
                                                                                            }}</strong></span></span></span></span></span>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!--[if mso | IE]></td></tr></table><![endif]-->
                </td>
            </tr>
        </tbody>
    </table>
</div>

<!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#FFFFFF" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
<div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
    <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
        style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
        <tbody>
            <tr>
                <td
                    style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                    <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                    <div class="mj-column-per-100 mj-outlook-group-fix"
                        style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                        <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                            <tbody>
                                <tr>
                                    <td
                                        style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                        <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                            width="100%">
                                            <tbody>
                                                <tr>
                                                    <td align="left" class="gr-mltext-sdeipq gr-mltext-aruycn"
                                                        style="font-size:0px;padding:17px 0 0 0;word-break:break-word;">
                                                        <div
                                                            style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:left;color:#000000;">
                                                            <div style="text-align: justify;">
                                                                <p
                                                                    style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                    <span style="color: #222222"><span
                                                                            style="font-size: 16px"><span
                                                                                style="font-family: Roboto, Arial, sans-serif"><span
                                                                                    style="font-weight: 400"><span
                                                                                        style="background-color: transparent">If
                                                                                        you have any concerns, please
                                                                                        feel free to contact us via
                                                                                        email or simply by dropping us a
                                                                                        message.</span></span></span></span></span>
                                                                </p>
                                                            </div>
                                                            <div style="text-align: justify;">
                                                                <p
                                                                    style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                    <br>
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <!--[if mso | IE]></td></tr></table><![endif]-->
                </td>
            </tr>
        </tbody>
    </table>
</div>
@endSection