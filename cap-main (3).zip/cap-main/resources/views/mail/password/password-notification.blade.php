<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
    xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <title inertia>{{ config('app.name') }}</title>
    <!--[if !mso]><!-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--<![endif]-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    {{-- <style type="text/css"> --}}
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="description"
        content="VIRTUAL EQUITY LANKA LTD is a Sri Lankan investment company that operates in various sectors, including the National Stock Exchange, private equity, government securities, and monetary and non-monetary investments."
        data-react-helmet="true" />
    <meta property="og:title" content="Virtual Equity Lanka Ltd" data-react-helmet="true" />
    <meta property="og:type" content="website" data-react-helmet="true" />
    <meta property="og:url" content="{{route('home') }}" data-react-helmet="true" />
    <meta property="og:image" content={{asset("/assets/images/meta/meta.png")}} data-react-helmet="true" />
    <meta property="og:image:alt" content="Virtual Equity Lanka Ltd Logo" data-react-helmet="true" />
    <meta property="og:description"
        content="VIRTUAL EQUITY LANKA LTD is a Sri Lankan investment company that operates in various sectors, including the National Stock Exchange, private equity, government securities, and monetary and non-monetary investments."
        data-react-helmet="true" />
    <link rel="icon" type="image/png" href="{{ asset('/assets/images/logo/favicon.png') }}" data-react-helmet="true" />

    <link href="{{ asset('templateStyle/email.css') }}" rel="stylesheet" type="text/css" />
    {{-- </style> --}}
</head>

<body style="word-spacing:normal;background-color:#F8F8F8;">
    <div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
            style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
            <tbody>
                <tr>
                    <td
                        style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                        <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                        <div class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                <tbody>
                                    <tr>
                                        <td
                                            style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td style="font-size:0px;word-break:break-word;">
                                                            <div style="height:30px;line-height:30px;">&#8202;</div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center"
                                                            class="gr-mlimage-fyiqgq gr-mlimage-swopet link-id-"
                                                            style="font-size:0px;padding:0;word-break:break-word;">
                                                            <table border="0" cellpadding="0" cellspacing="0"
                                                                role="presentation"
                                                                style="border-collapse:collapse;border-spacing:0px;">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="width:180px;">
                                                                            <img height="auto"
                                                                                {{-- src="https://vei.108.axcertro.dev/assets/images/logo/logo_with_text.png" --}}
                                                                                src="{{ asset('/assets/images/logo/logo_black.png')}}"
                                                                                alt="Logo "
                                                                                style="border:0;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;border-bottom:0 none #000000;border-radius:0;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:13px;"
                                                                                width="141">
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-size:0px;word-break:break-word;">
                                                            <div style="height:38px;line-height:38px;">&#8202;</div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align="left" class="gr-mltext-sdeipq gr-mltext-xntlln"
                                                            style="font-size:0px;padding:0;word-break:break-word;">
                                                            <div
                                                                style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:left;color:#000000;">
                                                                <div style="text-align: center;">
                                                                    <p style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;text-align:
                                                                        center">
                                                                        <span style="color: #000000"><strong><span
                                                                                    style="font-size: 28px"><span
                                                                                        style="font-family: Libre Baskerville, Georgia, serif"><span
                                                                                            style="background-color:
                                                                                            transparent">
                                                                                            Password Reset
                                                                                            Acknowledgement
                                                                                        </span></span></span></strong></span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-size:0px;word-break:break-word;">
                                                            <div style="height:5px;line-height:5px;">&#8202;</div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center"
                                                            style="font-size:0px;padding:20px;word-break:break-word;">
                                                            <p
                                                                style="border-top:solid 1px #00AEEF;font-size:1px;margin:0px auto;width:100%;">
                                                            </p>
                                                            <!--[if mso | IE]><table align="center" border="0" cellpadding="0" cellspacing="0" style="border-top:solid 1px #00AEEF;font-size:1px;margin:0px auto;width:480px;" role="presentation" width="480px" ><tr><td style="height:0;line-height:0;"> &nbsp;
</td></tr></table><![endif]-->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-size:0px;word-break:break-word;">
                                                            <div style="height:3px;line-height:3px;">&#8202;</div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align="left" class="gr-mltext-sdeipq gr-mltext-mbhvep"
                                                            style="font-size:0px;padding:0;word-break:break-word;">
                                                            <div
                                                                style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:left;color:#000000;">
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <span style="color: #000000"><strong><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif"><span
                                                                                            style="background-color: transparent">
                                                                                            Dear
                                                                                            {{ $user['first_name'] }}
                                                                                            {{ $user['last_name'] }},</span></span></span></strong></span>
                                                                    </p>
                                                                </div>
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <br></p>
                                                                </div>
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <br><span style="color: #000000"><span
                                                                                style="font-size: 16px"><span
                                                                                    style="font-family: Roboto, Arial, sans-serif"><span
                                                                                        style="font-weight: 400"><span
                                                                                            style="background-color:
                                                                                            transparent">Your password
                                                                                            has been successfully reset.
                                                                                            You can now log in to your
                                                                                            account using your new
                                                                                            password.

                                                                                             </span></span></span></span></span>
                                                                    </p>
                                                                </div>
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <br></p>
                                                                </div>
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <span style="color: #000000"><span
                                                                                style="font-size: 16px"><span
                                                                                    style="font-family: Roboto, Arial, sans-serif"><span
                                                                                        style="font-weight: 400"><span
                                                                                            style="background-color:
                                                                                                transparent">If you did
                                                                                            not request to reset
                                                                                            your password, please
                                                                                            contact us immediately.

                                                                                        </span></span></span></span></span>
                                                                    </p>
                                                                </div>
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <br><span style="color: #000000"><strong><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif"><span
                                                                                            style="background-color:
                                                                                            transparent">Thank you for
                                                                                            choosing Virtual Equity
                                                                                            Lanka Ltd!<br /><br />
                                                                                            Best
                                                                                            Wishes,</span></span></span></strong></span>
                                                                    </p>
                                                                </div>
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <span style="color: #000000"><span
                                                                                style="font-size: 16px"><span
                                                                                    style="font-family: Roboto, Arial, sans-serif"><span
                                                                                        style="font-weight: 400"><span
                                                                                            style="background-color:
                                                                                                transparent">{{ config('app.name') }}
                                                                                            Team</span></span></span></span></span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#FFFFFF" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    <div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
            style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
            <tbody>
                <tr>
                    <td
                        style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                        <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                        <div class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                <tbody>
                                    <tr>
                                        <td
                                            style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td style="font-size:0px;word-break:break-word;">
                                                            <div style="height:26px;line-height:26px;">&#8202;</div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#00AEEF" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    <div style="background:#00AEEF;background-color:#00AEEF;margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
            style="background:#00AEEF;background-color:#00AEEF;width:100%;">
            <tbody>
                <tr>
                    <td
                        style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                        <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                        <div class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                <tbody>
                                    <tr>
                                        <td
                                            style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td align="left" class="gr-mltext-sdeipq gr-mltext-mkkjis"
                                                            style="font-size:0px;padding:10px;word-break:break-word;">
                                                            <div
                                                                style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.4;text-align:left;color:#000000;">
                                                                <div style="text-align: center;">
                                                                    <p style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;text-align:
                                                                            center
">
                                                                        <strong>
                                                                            <span class="capitalize"
                                                                                style="color: #FFFFFF">&copy; Virtual
                                                                                Virtual Equity Lanka Ltd, All rights
                                                                                reserved.</span></strong></p>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    <div style="margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="width:100%;">
            <tbody>
                <tr>
                    <td
                        style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 20px;text-align:center;">
                        <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:560px;" ><![endif]-->
                        <div class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                <tbody>
                                    <tr>
                                        <td
                                            style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td align="left" class="gr-mltext-sdeipq gr-mltext-fwhiuv"
                                                            style="font-size:0px;padding:10px;word-break:break-word;">
                                                            <div
                                                                style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.4;text-align:left;color:#000000;">
                                                                <div style="text-align: center;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;text-align:center">
                                                                        <span style="font-size: 10px"><span
                                                                                style="font-family: Roboto, Arial, sans-serif"><span
                                                                                    style="font-weight: 400"><span
                                                                                        style="background-color: #FFFFFF"><span
                                                                                            style="color: #222222">If
                                                                                            you were unable to visit
                                                                                            the
                                                                                            page by any chance, please
                                                                                            click the link below:
                                                                                        </span><span
                                                                                            style="color: #828282">&nbsp;</span><span
                                                                                            style="color: #828282"><a
                                                                                                href={{ config('app.url')  }}
                                                                                                target="_blank">{{ config('app.url') }}</a>.</span></span></span></span></span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    </div>
</body>

</html>