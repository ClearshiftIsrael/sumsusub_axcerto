<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
    xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <title></title>
    <!--[if !mso]><!-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--<![endif]-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    {{-- <style type="text/css"> --}}
    <link href="{{ asset('templateStyle/email.css') }}" rel="stylesheet" type="text/css" />
    {{-- </style> --}}
</head>

<body style="word-spacing:normal;background-color:#F8F8F8;">
    <div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
            style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
            <tbody>
                <tr>
                    <td
                        style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                        <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                        <div class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                <tbody>
                                    <tr>
                                        <td
                                            style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td style="font-size:0px;word-break:break-word;">
                                                            <div style="height:30px;line-height:30px;">&#8202;</div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center"
                                                            class="gr-mlimage-fyiqgq gr-mlimage-swopet link-id-"
                                                            style="font-size:0px;padding:0;word-break:break-word;">
                                                            <table border="0" cellpadding="0" cellspacing="0"
                                                                role="presentation"
                                                                style="border-collapse:collapse;border-spacing:0px;">
                                                                <tbody>
                                                                    <tr>
                                                                        <td style="width:180px;">
                                                                            <img height="auto"
                                                                                {{-- src="https://vei.108.axcertro.dev/assets/images/logo/logo_with_text.png" --}}
                                                                                src={{ asset('assets/image/logo.png') }}
                                                                                alt="Logo "
                                                                                style="border:0;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;border-bottom:0 none #000000;border-radius:0;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:13px;"
                                                                                width="141">
                                                                        </td>
                                                                    </tr>
                                                                </tbody>
                                                            </table>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-size:0px;word-break:break-word;">
                                                            <div style="height:38px;line-height:38px;">&#8202;</div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align="left" class="gr-mltext-sdeipq gr-mltext-xntlln"
                                                            style="font-size:0px;padding:0;word-break:break-word;">
                                                            <div
                                                                style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:left;color:#000000;">
                                                                <div style="text-align: center;">
                                                                    <p style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;text-align:
                                                                        center">
                                                                        <span style="color: #000000"><strong><span
                                                                                    style="font-size: 28px"><span
                                                                                        style="font-family: Libre Baskerville, Georgia, serif"><span
                                                                                            style="background-color:
                                                                                            transparent">
                                                                                           {{__("mail.password.reset.title")}}
                                                                                        </span></span></span></strong></span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-size:0px;word-break:break-word;">
                                                            <div style="height:5px;line-height:5px;">&#8202;</div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align="center"
                                                            style="font-size:0px;padding:20px;word-break:break-word;">
                                                            <p
                                                                style="border-top:solid 1px #008e9f;font-size:1px;margin:0px auto;width:100%;">
                                                            </p>
                                                            <!--[if mso | IE]><table align="center" border="0" cellpadding="0" cellspacing="0" style="border-top:solid 1px #008e9f;font-size:1px;margin:0px auto;width:480px;" role="presentation" width="480px" ><tr><td style="height:0;line-height:0;"> &nbsp;
</td></tr></table><![endif]-->
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td style="font-size:0px;word-break:break-word;">
                                                            <div style="height:3px;line-height:3px;">&#8202;</div>
                                                        </td>
                                                    </tr>
                                                    <tr>
                                                        <td align="left" class="gr-mltext-sdeipq gr-mltext-mbhvep"
                                                            style="font-size:0px;padding:0;word-break:break-word;">
                                                            <div
                                                                style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:left;color:#000000;">
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <span style="color: #000000"><strong><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif"><span
                                                                                            style="background-color: transparent">
                                                                                           {{__("mail.password.reset.dear")}}
                                                                                            {{ $user }},</span></span></span></strong></span>
                                                                    </p>
                                                                </div>
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <br></p>
                                                                </div>

                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <span style="color: #000000"><span
                                                                                style="font-size: 16px"><span
                                                                                    style="font-family: Roboto, Arial, sans-serif"><span
                                                                                        style="font-weight: 400"><span
                                                                                            style="background-color:
                                                                                            transparent">{{__("mail.password.reset.intro")}}
                                                                                            <br />
                                                                                            <br />
                                                                                            {{__("mail.password.reset.instruction")}}
                                                                                        </span></span></span></span></span>
                                                                        <div
                                                                            style="text-align: center; margin-top: 20px">

                                                                            <a style="display:inline-block;background:#008e9f;color:#FFFFFF; font-family:Arial;font-size:16px;font-style:normal;font-weight:normal;line-height:100%;margin:0;text-decoration:none;text-transform:none;  mso-padding-alt:0px;border-radius:5px;  padding:12px; width:250px; justify-content:
                                                                        center; align-content: center;
                                                                        align-item:center; align-content: center;
                                                                                align-item:center; text-align: center"
                                                                                href={{ $url }}>
                                                                                {{ __("mail.password.reset.button") }}
                                                                            </a>
                                                                        </div>
                                                                    </p>
                                                                </div>

                                                                <br />
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <span style="color: #000000"><span
                                                                                style="font-size: 16px"><span
                                                                                    style="font-family: Roboto, Arial, sans-serif"><span
                                                                                        style="font-weight: 400"><span
                                                                                            style="background-color:
                                                                                                transparent">{{__("mail.password.reset.warning")}}
                                                                                            <br />
                                                                                            <br />
                                                                                           {{__("mail.password.reset.contact")}}

                                                                                        </span></span></span></span></span>
                                                                    </p>
                                                                </div>
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <br><span style="color: #000000"><strong><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif"><span
                                                                                            style="background-color:
                                                                                            transparent">{{__("mail.password.reset.thanks")}}<br /><br />
                                                                                            {{ __( "mail.password.reset.best.wishes") }}
                                                                                        </span></span></span></strong></span>
                                                                    </p>
                                                                </div>
                                                                <div style="text-align: justify;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <span style="color: #000000"><span
                                                                                style="font-size: 16px"><span
                                                                                    style="font-family: Roboto, Arial, sans-serif"><span
                                                                                        style="font-weight: 400"><span
                                                                                            style="background-color:
                                                                                                transparent">{{ config('app.name') }}
                                                                                            </span></span></span></span></span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#FFFFFF" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    <div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
            style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
            <tbody>
                <tr>
                    <td
                        style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                        <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                        <div class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                <tbody>
                                    <tr>
                                        <td
                                            style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td style="font-size:0px;word-break:break-word;">
                                                            <div style="height:26px;line-height:26px;">&#8202;</div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#008e9f" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    <div style="background:#008e9f;background-color:#008e9f;margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
            style="background:#008e9f;background-color:#008e9f;width:100%;">
            <tbody>
                <tr>
                    <td
                        style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                        <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                        <div class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                <tbody>
                                    <tr>
                                        <td
                                            style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td align="left" class="gr-mltext-sdeipq gr-mltext-mkkjis"
                                                            style="font-size:0px;padding:10px;word-break:break-word;">
                                                            <div
                                                                style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.4;text-align:left;color:#000000;">
                                                                <div style="text-align: center;">
                                                                    <p style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;text-align:
                                                                            center">
                                                                                @php
                                                                                    $currentYear = now()->year;
                                                                                @endphp
                                                                        <strong>
                                                                            <span class="capitalize"
                                                                                style="color: #FFFFFF">&copy; {{ $currentYear }}
                                                                                 {{ config('app.name') }}, {{__("mail.footer")}}</span></strong></p>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
    <div style="margin:0px auto;max-width:600px;">
        <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation" style="width:100%;">
            <tbody>
                <tr>
                    <td
                        style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 20px;text-align:center;">
                        <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:560px;" ><![endif]-->
                        <div class="mj-column-per-100 mj-outlook-group-fix"
                            style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                            <table border="0" cellpadding="0" cellspacing="0" role="presentation" width="100%">
                                <tbody>
                                    <tr>
                                        <td
                                            style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                            <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                                width="100%">
                                                <tbody>
                                                    <tr>
                                                        <td align="left" class="gr-mltext-sdeipq gr-mltext-fwhiuv"
                                                            style="font-size:0px;padding:10px;word-break:break-word;">
                                                            <div
                                                                style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.4;text-align:left;color:#000000;">
                                                                <div style="text-align: center;">
                                                                    <p
                                                                        style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;text-align:center">
                                                                        <span style="font-size: 10px"><span
                                                                                style="font-family: Roboto, Arial, sans-serif"><span
                                                                                    style="font-weight: 400"><span
                                                                                        style="background-color: #FFFFFF"><span
                                                                                            style="color: #222222">{{__("mail.password.reset.link")}}
                                                                                        </span><span
                                                                                            style="color: #828282">&nbsp;</span><span
                                                                                            style="color: #828282"><a
                                                                                                href={{ $url }}
                                                                                                target="_blank">{{ $url }}</a>.</span></span></span></span></span>
                                                                    </p>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!--[if mso | IE]></td></tr></table><![endif]-->
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    </div>
</body>

</html>