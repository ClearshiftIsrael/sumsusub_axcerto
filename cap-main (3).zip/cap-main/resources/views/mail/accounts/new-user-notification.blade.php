<!doctype html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:v="urn:schemas-microsoft-com:vml"
    xmlns:o="urn:schemas-microsoft-com:office:office">

<head>
    <title></title>
    <!--[if !mso]><!-->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--<![endif]-->
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <style type="text/css">
        #outlook a {
            padding: 0;
        }

        body {
            margin: 0;
            padding: 0;
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
        }

        table,
        td {
            border-collapse: collapse;
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }

        img {
            border: 0;
            height: auto;
            line-height: 100%;
            outline: none;
            text-decoration: none;
            -ms-interpolation-mode: bicubic;
        }

        p {
            display: block;
            margin: 13px 0;
        }
    </style>
    <!--[if mso]>
      <noscript>
         <xml>
            <o:OfficeDocumentSettings>
               <o:AllowPNG/>
               <o:PixelsPerInch>96</o:PixelsPerInch>
            </o:OfficeDocumentSettings>
         </xml>
      </noscript>
      <![endif]-->
    <!--[if lte mso 11]>
      <style type="text/css">
         .mj-outlook-group-fix { width:100% !important; }
      </style>
      <![endif]-->
    <style type="text/css">
        @media only screen and (min-width:480px) {
            .mj-column-per-100 {
                width: 100% !important;
                max-width: 100%;
            }
        }
    </style>
    <style media="screen and (min-width:480px)">
        .moz-text-html .mj-column-per-100 {
            width: 100% !important;
            max-width: 100%;
        }
    </style>
    <style type="text/css">
        @media only screen and (max-width:480px) {
            table.mj-full-width-mobile {
                width: 100% !important;
            }

            td.mj-full-width-mobile {
                width: auto !important;
            }
        }
    </style>
    <style type="text/css">
        @media (max-width: 479px) {
            .hide-on-mobile {
                display: none !important;
            }
        }

        .gr-headerviewonline-vkrbhx a,
        .gr-headerviewonline-vkrbhx a:visited {
            color: #808080;
            text-decoration: none;
        }

        .gr-mlimage-wyaklh img {
            box-sizing: border-box;
        }

        @media (min-width: 480px) {
            .gr-mlimage-mftlhk {
                height: 38px !important;
            }
        }

        .gr-mltext-nhdoef a,
        .gr-mltext-nhdoef a:visited {
            text-decoration: none;
        }

        .gr-mltext-huslrm a,
        .gr-mltext-huslrm a:visited {
            text-decoration: none;
        }

        .gr-mlbutton-chigyn p {
            direction: ltr;
        }

        .gr-mltext-cxesir a,
        .gr-mltext-cxesir a:visited {
            text-decoration: none;
        }

        .gr-mltext-uvfosm a,
        .gr-mltext-uvfosm a:visited {
            text-decoration: none;
        }

        .gr-mltext-baqhxx a,
        .gr-mltext-baqhxx a:visited {
            text-decoration: none;
        }

        .gr-footer-kpljnd a,
        .gr-footer-kpljnd a:visited {
            color: #7E7E7E;
            text-decoration: underline;
        }
    </style>
    <link
        href="https://fonts.googleapis.com/css?display=swap&family=Roboto:400,400i,700,700i|Libre Baskerville:400,400i,700,700i|serif:400,400i,700,700i&subset=cyrillic,greek,latin-ext,vietnamese"
        rel="stylesheet" type="text/css">
    <style type="text/css">
        @import url(https://fonts.googleapis.com/css?display=swap&family=Roboto:400,400i,700,700i|Libre Baskerville:400,400i,700,700i|serif:400,400i,700,700i&subset=cyrillic,greek,latin-ext,vietnamese);
    </style>
</head>

<body style="word-spacing:normal;background-color:#F8F8F8;">
    <div style="background-color:#F8F8F8;">
        <!--[if mso | IE]>
      <table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" >
         <tr>
            <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;">
               <![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]>
                              <table role="presentation" border="0" cellpadding="0" cellspacing="0">
                                 <tr>
                                    <td class="" style="vertical-align:top;width:520px;" >
                                       <![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    role="presentation" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td align="center"
                                                                class="gr-headerviewonline-sstxsm gr-headerviewonline-vkrbhx"
                                                                style="font-size:0px;padding:20px 0 10px 0;word-break:break-word;">
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!--[if mso | IE]>
                                    </td>
                                 </tr>
                              </table>
                              <![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]>
            </td>
         </tr>
      </table>
      <table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#FFFFFF" >
         <tr>
            <td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;">
               <![endif]-->
        <div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]>
                              <table role="presentation" border="0" cellpadding="0" cellspacing="0">
                                 <tr>
                                    <td class="" style="vertical-align:top;width:520px;" >
                                       <![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    role="presentation" width="100%">
                                                    <tbody>
                                                        {{-- <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:30px;line-height:30px;">&#8202;
                                                                </div>
                                                            </td>
                                                        </tr> --}}
                                                        <tr>
                                                            {{-- <td align="center"
                                                                class="gr-mlimage-wyaklh gr-mlimage-mftlhk link-id-"
                                                                style="font-size:0px;padding:0;word-break:break-word;">
                                                                <table border="0" cellpadding="0" cellspacing="0"
                                                                    role="presentation"
                                                                    style="border-collapse:collapse;border-spacing:0px;">
                                                                    <tbody>
                                                                        <tr>
                                                                            <td style="width:141px;"><img
                                                                                    alt="" height="auto"
                                                                                    src={{ asset('assets/image/logo.png') }}
                                                                                    style="border:0;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;border-bottom:0 none #000000;border-radius:0;display:block;outline:none;text-decoration:none;height:auto;width:100%;font-size:13px;"
                                                                                    width="141">
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </td>
                                                        </tr> --}}
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:38px;line-height:38px;">&#8202;
                                                                </div>
                                                            </td>
                                                        </tr>
                                                        {{-- <tr>
                                                            <td align="left"
                                                                class="gr-mltext-jofcch gr-mltext-nhdoef"
                                                                style="font-size:0px;padding:0;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:left;color:#000000;">
                                                                    <div style="text-align: center;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000; text-align: center">
                                                                            <span style="color: #000000"><strong><span
                                                                                        style="font-size: 14.666666666666666px"><span
                                                                                            style="font-family: Arial, sans-serif"><span
                                                                                                style="font-weight: 700"><span
                                                                                                    style="background-color: transparent">
                                                                                                </span></span></span></span></strong></span><span
                                                                                style="color: #000000"><strong><span
                                                                                        style="font-size: 28px"><span
                                                                                            style="font-family: Libre Baskerville, Georgia, serif"><span
                                                                                                style="background-color: transparent">You
                                                                                                have been
                                                                                                invited.</span></span></span></strong></span>
                                                                        </p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr> --}}
                                                        {{-- <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:5px;line-height:5px;">&#8202;</div>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td align="center"
                                                                style="font-size:0px;padding:20px;word-break:break-word;">
                                                                <p
                                                                    style="border-top:solid 1px #008e9f;font-size:1px;margin:0px auto;width:100%;">
                                                                </p>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:3px;line-height:3px;">&#8202;</div>
                                                            </td>
                                                        </tr> --}}
                                                        <tr>
                                                            <td align="left"
                                                                class="gr-mltext-jofcch gr-mltext-huslrm"
                                                                style="font-size:0px;padding:0;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.6;text-align:left;color:#000000;">
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><strong><span
                                                                                        style="font-size: 16px"><span
                                                                                            style="font-family: Roboto, Arial, sans-serif"><span
                                                                                                style="background-color: transparent">Hello
                                                                                                {{ $data['name'] }},</span>
                                                                                        </span>
                                                                                    </span>
                                                                                </strong>
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000">
                                                                                <span style="font-size: 16px">
                                                                                    <span
                                                                                        style="font-family: Roboto, Arial, sans-serif">
                                                                                        <span style="font-weight: 400">
                                                                                            <span
                                                                                                style="background-color: transparent">
                                                                                                The following is the
                                                                                                list of documents that
                                                                                                you need to prepare for
                                                                                                the application form:
                                                                                            </span>
                                                                                            <ul
                                                                                                style="list-style: numbers">
                                                                                                <li>
                                                                                                    A scan of two valid
                                                                                                    identification
                                                                                                    documents, from the
                                                                                                    following options:
                                                                                                    <ul>
                                                                                                        <li>Driver's
                                                                                                            License</li>
                                                                                                        <li>Teudat Zehut
                                                                                                            (if
                                                                                                            biometric,
                                                                                                            please also
                                                                                                            upload a
                                                                                                            scan of the
                                                                                                            back of the
                                                                                                            card)</li>
                                                                                                        <li>Passport
                                                                                                        </li>
                                                                                                    </ul>
                                                                                                </li>
                                                                                                <li>
                                                                                                    One of the following
                                                                                                    documents for each
                                                                                                    the source and
                                                                                                    destination bank
                                                                                                    accounts:
                                                                                                    <ul>
                                                                                                        <li>Bank
                                                                                                            Statement
                                                                                                            (if the
                                                                                                            account
                                                                                                            holder’s
                                                                                                            name and
                                                                                                            full bank
                                                                                                            account
                                                                                                            number
                                                                                                            appear)</li>
                                                                                                        <li>Account
                                                                                                            Management
                                                                                                            Certif</li>
                                                                                                        <li>Account
                                                                                                            Management
                                                                                                            Certificate
                                                                                                            (ishur nihul
                                                                                                            cheshbon)
                                                                                                        </li>
                                                                                                    </ul>
                                                                                                    <span>Note: If there
                                                                                                        are additional
                                                                                                        beneficiaries in
                                                                                                        the bank
                                                                                                        accounts, an ID
                                                                                                        must be attached
                                                                                                        for each
                                                                                                        beneficiary.</span>
                                                                                                </li>
                                                                                                <li>An explanation of
                                                                                                    the source of the
                                                                                                    wealth along with
                                                                                                    supporting
                                                                                                    documents. For
                                                                                                    example, if the
                                                                                                    source of funds is
                                                                                                    the sale of a
                                                                                                    property, please
                                                                                                    send us the contract
                                                                                                    of sale, if it is
                                                                                                    from an investment,
                                                                                                    please send periodic
                                                                                                    statement, etc.
                                                                                                </li>
                                                                                                <li>
                                                                                                    Explain the purpose
                                                                                                    of the transfer and
                                                                                                    provide supporting
                                                                                                    documents, if any.
                                                                                                </li>
                                                                                            </ul>
                                                                                            <span>
                                                                                                When you have the
                                                                                                necessary documents,
                                                                                                please enter the
                                                                                                application form at the
                                                                                                following link: <a
                                                                                                    href="{{ $data['link'] }}">Clearshift
                                                                                                    Account
                                                                                                    Application</a>.
                                                                                            </span>
                                                                                        </span>
                                                                                    </span>
                                                                                </span>
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:700;color:#000000;">
                                                                            <span style="color: #000000">
                                                                                <span style="font-size: 16px">
                                                                                    <span
                                                                                        style="font-family: Roboto, Arial, sans-serif">
                                                                                        <span style="font-weight: 400">
                                                                                            <span
                                                                                                style="background-color: transparent">
                                                                                                <p style="height:10px">
                                                                                                </p>
                                                                                                <p
                                                                                                    style="font-weight:400;">
                                                                                                    Please note: that
                                                                                                    once you have
                                                                                                    completed the form,
                                                                                                    you will receive an
                                                                                                    additional email to
                                                                                                    complete your
                                                                                                    onboarding process.
                                                                                                    This email will
                                                                                                    include the
                                                                                                    following forms for
                                                                                                    your signature:</p>

                                                                                                <ul
                                                                                                    style="list-style: disc">
                                                                                                    <li>Declaration of
                                                                                                        Beneficiaries
                                                                                                    </li>
                                                                                                    <li>CRS form.</li>
                                                                                                    <li>Terms &
                                                                                                        Conditions.
                                                                                                    </li>
                                                                                                </ul>
                                                                                            </span>
                                                                                        </span>
                                                                                    </span>
                                                                                </span>
                                                                            </span>
                                                                        </p>
                                                                    </div>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!--[if mso | IE]>
                                    </td>
                                 </tr>
                              </table>
                              <![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <!--[if mso | IE]>
            </td>
         </tr>
      </table>
      <table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" bgcolor="#FFFFFF" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="background:#FFFFFF;background-color:#FFFFFF;margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="background:#FFFFFF;background-color:#FFFFFF;width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 40px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:520px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    role="presentation" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td align="left"
                                                                class="gr-mltext-jofcch gr-mltext-cxesir"
                                                                style="font-size:0px;padding:10px;word-break:break-word;">
                                                                <div
                                                                    style="font-family:Ubuntu, Helvetica, Arial, sans-serif;font-size:13px;line-height:1.4;text-align:left;color:#000000;">
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <br>
                                                                        </p>
                                                                    </div>
                                                                    <div style="text-align: justify;">
                                                                        <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif">
                                                                                        <span style="font-weight: 600">
                                                                                            <span style="background-color: transparent">
                                                                                                Bracha Silverberg
                                                                                            </span>
                                                                                        </span>
                                                                                    </span>
                                                                                </span>
                                                                            </span>
                                                                        </p>
                                                                         <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif">
                                                                                        <span style="font-weight: 300">
                                                                                            <span style="background-color: transparent">
                                                                                                Telephone:+972-3-915-5726
                                                                                            </span>
                                                                                        </span>
                                                                                    </span>
                                                                                </span>
                                                                            </span>
                                                                        </p>
                                                                          <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif">
                                                                                        <span style="font-weight: 300">
                                                                                            <span style="background-color: transparent">
                                                                                                <a href="mailto:sales@clearshiftinc.com">sales@clearshiftinc.com</a>
                                                                                            </span>
                                                                                        </span>
                                                                                    </span>
                                                                                </span>
                                                                            </span>
                                                                        </p>
                                                                          <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif">
                                                                                        <span style="font-weight: 300">
                                                                                            <span style="background-color: transparent">
                                                                                                <a href="https://clearshiftinc.com">www.clearshiftinc.com</a>
                                                                                            </span>
                                                                                        </span>
                                                                                    </span>
                                                                                </span>
                                                                            </span>
                                                                        </p>
                                                                        <p class="height:5px"></p>
                                                                          <div
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                        <img
                                                                                    alt="" height="auto"
                                                                                    src={{ asset('assets/image/logo.png') }}
                                                                                    style="border:0;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;border-bottom:0 none #000000;border-radius:0;display:block;outline:none;text-decoration:none;height:auto;width:30%;font-size:13px;"
                                                                                    width="50">
                                                                        </div>
                                                                          <p
                                                                            style="font-family:Arial;font-size:14px;margin-top:0px;margin-bottom:0px;font-weight:normal;color:#000000;">
                                                                            <span style="color: #000000"><span
                                                                                    style="font-size: 16px"><span
                                                                                        style="font-family: Roboto, Arial, sans-serif">
                                                                                        <span style="font-weight: 300">
                                                                                            <span style="background-color: transparent">
                                                                                                Transparent Finance.Globally Delivered.
                                                                                            </span>
                                                                                        </span>
                                                                                    </span>
                                                                                </span>
                                                                            </span>
                                                                        </p>
                                                                        <p class="height:60px"></p>
                                                                    </div>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!--[if mso | IE]></td></tr></table><table align="center" border="0" cellpadding="0" cellspacing="0" class="" role="presentation" style="width:600px;" width="600" ><tr><td style="line-height:0px;font-size:0px;mso-line-height-rule:exactly;"><![endif]-->
        <div style="margin:0px auto;max-width:600px;">
            <table align="center" border="0" cellpadding="0" cellspacing="0" role="presentation"
                style="width:100%;">
                <tbody>
                    <tr>
                        <td
                            style="border-bottom:0 none #000000;border-left:0 none #000000;border-right:0 none #000000;border-top:0 none #000000;direction:ltr;font-size:0px;padding:0 20px;text-align:center;">
                            <!--[if mso | IE]><table role="presentation" border="0" cellpadding="0" cellspacing="0"><tr><td class="" style="vertical-align:top;width:560px;" ><![endif]-->
                            <div class="mj-column-per-100 mj-outlook-group-fix"
                                style="font-size:0px;text-align:left;direction:ltr;display:inline-block;vertical-align:top;width:100%;">
                                <table border="0" cellpadding="0" cellspacing="0" role="presentation"
                                    width="100%">
                                    <tbody>
                                        <tr>
                                            <td
                                                style="background-color:transparent;border-bottom:none;border-left:none;border-right:none;border-top:none;vertical-align:top;padding:0;">
                                                <table border="0" cellpadding="0" cellspacing="0"
                                                    role="presentation" width="100%">
                                                    <tbody>
                                                        <tr>
                                                            <td style="font-size:0px;word-break:break-word;">
                                                                <div style="height:20px;line-height:20px;">&#8202;
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <!--[if mso | IE]></td></tr></table><![endif]-->
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</body>

</html>
