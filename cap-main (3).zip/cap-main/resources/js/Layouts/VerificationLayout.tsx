import FlashAlerts from "@/Components/elements/alerts/FlashAlerts";
import Footer from "@/Components/shared/footer";
import { PageProps } from "@/types";
import { ArrowLeftIcon } from "@heroicons/react/24/outline";
import { Link, usePage } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { PropsWithChildren } from "react";
import Internationalization from "@/Components/shared/internationalization";

export default function VerificationLayout({
    account,
    children,
}: PropsWithChildren<{ account: any }>) {
    const { flash, auth } = usePage<PageProps>().props;

      const { t } = useLaravelReactI18n();

    return (
        <div className={" min-h-full scroll-smooth bg-slate-100 "}>
            {/* <MemberNav /> */}
            <div className="bg-white py-6 w-full sticky top-0">
                <div className="container mx-auto flex relative">
                    <div className="mx-auto flex justify-between w-full">
                        <div>
                            <h2 className="font-[800] text-xl">
                                <span className="text-gray-600">
                                    {t("pp.verification.account")}:
                                </span>{" "}
                                <span className="text-primary">
                                    {account.account_name}
                                </span>
                            </h2>
                        </div>
                        <div className=" text-slate-900 rounded-full flex justify-center">
                            {/* <Internationalization guest={false} /> */}
                        </div>
                    </div>
                </div>
            </div>
            <div className="relative min-h-[88vh] flex py-8">
                <main className="container mx-auto">
                    <div className="flex">
                        <Link
                            href={route("accounts.index")}
                            className="flex self-center font-[800] space-x-2 mb-4 bg-gray-800 text-white py-2 px-8 rounded-xl hover:bg-gray-900"
                        >
                            <ArrowLeftIcon className="w-5 h-5 self-center" />
                            <span className="self-center">
                                {t("pp.verification.back")}
                            </span>
                        </Link>
                    </div>
                    <div>{children}</div>
                </main>
            </div>
            <Footer />
            <FlashAlerts flash={flash} />
        </div>
    );
}
