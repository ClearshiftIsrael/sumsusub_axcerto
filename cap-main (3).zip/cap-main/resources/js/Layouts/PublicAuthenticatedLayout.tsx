import FlashAlerts from "@/Components/elements/alerts/FlashAlerts";
import Footer from "@/Components/shared/footer";
import Sidebar from "@/Components/shared/sidebar/sidebar";
import { PageProps, User } from "@/types";
import { Link, usePage } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { PropsWithChildren, ReactNode, useState } from "react";
import PublicHeader from "@/Components/shared/PublicHeader";
import Internationalization from "@/Components/shared/internationalization";
import MemberNav from "@/Components/shared/member-nav/MemberHeader";
import ZendeskWidget from "@/Components/shared/ZendeskWidget";

export default function PublicAuthenticated({
    children,
}: PropsWithChildren<{}>) {
    const { flash, auth } = usePage<PageProps>().props;
 const { t, currentLocale } = useLaravelReactI18n();
    return (
        <div
            className={" min-h-full scroll-smooth bg-slate-100 "}
            // style={{ direction: currentLocale() == "he" ? "rtl" : "ltr" }}
        >
            <MemberNav />
            <div className="relative min-h-[88vh] ">
                <div className="flex h-full">
                    <main className="container p-8 mx-auto">{children}</main>
                </div>
                <ZendeskWidget />
            </div>

            <Footer />
            <FlashAlerts flash={flash} />
        </div>
    );
}
