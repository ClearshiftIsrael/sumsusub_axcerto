import FooterGuest from "@/Components/shared/footer-guest";
import Internationalization from "@/Components/shared/internationalization";
import { Link } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { PropsWithChildren } from "react";

export default function Guest({ children }: PropsWithChildren) {
    const { t,currentLocale } = useLaravelReactI18n();
    return (
        <div className="flex flex-col items-center min-h-screen pt-6 bg-gray-100 sm:justify-center sm:pt-0"
        // style={{ direction: currentLocale()=='he'?"rtl":'ltr'}}
        >
            <div className=" fixed bg-white py-4 top-0 right-0 left-0">
                <div className="container mx-auto flex justify-between">
                    <div>
                        <Link href="/">
                            <img
                                className="self-center object-contain w-[160px]"
                                src={"/assets/image/logo.png?a=10"}
                                width="120"
                                height="100"
                            />
                        </Link>
                    </div>
                    <div className=" flex justify-center">
                        <Internationalization guest={true} />
                    </div>
                </div>
            </div>
            <main className="pt-32 pb-8">{children}</main>
            <FooterGuest />
        </div>
    );
}
