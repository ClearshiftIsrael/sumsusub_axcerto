import FlashAlerts from "@/Components/elements/alerts/FlashAlerts";
import ZendeskWidget from "@/Components/shared/ZendeskWidget";
import Footer from "@/Components/shared/footer";
import Header from "@/Components/shared/header";
import Sidebar from "@/Components/shared/sidebar/sidebar";
import { PageProps, User } from "@/types";
import { usePage } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { PropsWithChildren, ReactNode, useState } from "react";
import Zendesk from "react-zendesk";

export default function Authenticated({
    header,
    children,
    bRoutes,
}: PropsWithChildren<{
    header?: ReactNode;
    bRoutes?: any;
}>) {
    const { currentLocale } = useLaravelReactI18n();
    const { flash, auth } = usePage<PageProps>().props;


    return (
        <div className={" min-h-full scroll-smooth bg-slate-100 "}>
            <Header bRoutes={bRoutes}   />
            <div className="relative lg:mt-[85px]">
                <Sidebar user={auth.user} />
                <div className="flex flex-1 flex-col lg:pl-[260px] min-h-[100vh]">
                    <main className="flex-1 bg-slate-100 p-8 h-[100%]">
                        {children}
                    </main>
                    {/* <Footer /> */}
                </div>
            </div>
            <FlashAlerts flash={flash} />
            <Footer/>
        </div>
    );
}
