import { Square3Stack3DIcon } from "@heroicons/react/20/solid";
import { Link } from "@inertiajs/react";

export default function Statistics({ data, t, currentLocale }: any) {
    return (
        <div className="mx-auto space-y-6 container">
            <div className="mt-5 report-box-2 intro-y">
                <div className="flex gap-5 box justify-center">
                    <Link
                        href={route("accounts.index")}
                        className="w-full md:w-2/3 lg:w-1/3 flex flex-col justify-center px-8 py-8 bg-white rounded-md hover:border hover:border-primary"
                    >
                        <h1 className="text-gray-800 text-[18px] font-semibold mb-2 flex justify-between items-center">
                            {t("pp.dashboard.statistics.title")}{" "}
                            <Square3Stack3DIcon className="w-10 h-10 text-primary" />
                        </h1>
                        <h2
                            className={`text-gray-700 font-semibold text-[17px]`}
                        >
                            {/* <span> */}
                            <span>
                                {t("pp.dashboard.statistics.totalAccount")}:{" "}
                            </span>
                            <span
                                className={`  ${
                                    currentLocale() == "en" ? "float-right" : ""
                                }`}
                            >
                                {data?.total_accounts}
                            </span>
                        </h2>
                        <h2 className="text-gray-700 font-semibold text-[17px]">
                            {t("pp.dashboard.statistics.individualAccount")}:{" "}
                            <span
                                className={`  ${
                                    currentLocale() == "en" ? "float-right" : ""
                                }`}
                            >
                                {data?.individual_accounts}
                            </span>
                        </h2>
                        <h2 className="text-gray-700 font-semibold text-[17px]">
                            {t("pp.dashboard.statistics.businessAccount")}:{" "}
                            <span
                                className={`  ${
                                    currentLocale() == "en" ? "float-right" : ""
                                }`}
                            >
                                {data?.business_accounts}
                            </span>
                        </h2>
                    </Link>
                </div>
                <div className="mt-4">
                    <div className="flex justify-center">
                        <h6
                            className={`flex items-center ${
                                currentLocale() === "he"
                                    ? "justify-start flex-row-reverse"
                                    : "justify-end"
                            }`}
                        >
                            <span
                                className={`font-bold ${
                                    currentLocale() === "he" ? "ml-2" : "mr-2"
                                }`}
                            >
                                {currentLocale() === "he"
                                    ? ":התקשרו אלינו"
                                    : "Call Us:"}
                            </span>
                            <span dir="ltr" className="inline-block">
                                <strong>(+972)39155726</strong>
                            </span>
                        </h6>
                    </div>
                    <div className="flex justify-center">
                        <h6
                            className={`flex items-center ${
                                currentLocale() === "he"
                                    ? "justify-start flex-row-reverse"
                                    : "justify-end"
                            }`}
                        >
                            <span
                                className={`font-bold ${
                                    currentLocale() === "he" ? "ml-2" : "mr-2"
                                }`}
                            >
                                {t("pp.dashboard.statistics.mail")}
                            </span>
                            <span dir="ltr" className="inline-block">
                                <strong>support@clearshiftinc.com</strong>
                            </span>
                        </h6>
                    </div>
                </div>
            </div>
        </div>
    );
}
