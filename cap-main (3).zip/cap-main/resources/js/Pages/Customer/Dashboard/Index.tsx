import PublicAuthenticated from "@/Layouts/PublicAuthenticatedLayout";
import { useLaravelReactI18n } from "laravel-react-i18n";
import Statistics from "./Partials/Statistics";
import { Head } from "@inertiajs/react";

export default function Dashboard({ auth, dashboardData }: any) {
    const { t, currentLocale } = useLaravelReactI18n();
    const user = auth.user;
    return (
        <PublicAuthenticated>
            <Head title={t("pp.dashboard.title")} />
            <div className="self-center space-y-4">
                <h6 className="text-3xl font-[700] text-gray-600 text-center">
                    {t("pp.dashboard.hello", { name: user.first_name })}
                </h6>
                <p className="text-gray-700 text-center">
                    {t("pp.dashboard.welcome")}
                </p>
                <Statistics
                    data={dashboardData}
                    t={t}
                    currentLocale={currentLocale}
                />
            </div>
        </PublicAuthenticated>
    );
}
