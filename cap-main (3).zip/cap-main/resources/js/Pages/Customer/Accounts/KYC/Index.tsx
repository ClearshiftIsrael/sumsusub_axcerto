import PublicAuthenticated from "@/Layouts/PublicAuthenticatedLayout";
import VerificationLayout from "@/Layouts/VerificationLayout";
import SumsubWebSdk from "@sumsub/websdk-react";
import axios from "axios";
import { useLaravelReactI18n } from "laravel-react-i18n";

export default function KYCIndex({ verificationData, adminStatus,account }: any) {
    const { t, currentLocale } = useLaravelReactI18n();

    const config = {
        lang: currentLocale() == "en" ? "en" : "he",
    };
    const options = {};
    const accessTokenExpirationHandler = async () => {
        return await axios.get(route("api.verification.new-token",{account:account.id})).then((res: any) => {
            return res;
        });
    };
    const errorHandler = (err: any) => {
        console.error(err);
    };

    return (
        <VerificationLayout account={account}>
            <div className="w-full self-center">
                {/* {adminStatus == "inprogress" ? (
                    <KycInprogress />
                ) : ( */}
                <SumsubWebSdk
                    accessToken={verificationData?.token}
                    expirationHandler={() => accessTokenExpirationHandler()}
                    config={config}
                    options={options}
                    onError={errorHandler}
                />
                {/* // )} */}
            </div>
        </VerificationLayout>
    );
}
