import { Head } from "@inertiajs/react";
import MasterTable, {
    TableBody,
    TableTd,
} from "@/Components/elements/tables/masterTable";
import { PrimaryLink } from "@/Components/elements/buttons/PrimaryButton";
import { PencilIcon } from "@heroicons/react/20/solid";
import { useLaravelReactI18n } from "laravel-react-i18n";
import PublicAuthenticated from "@/Layouts/PublicAuthenticatedLayout";
import { spawn } from "child_process";

export default function UserIndex({
    accounts,
    filters,
}: {
    accounts: any;
    filters: any;
}) {
    const { t } = useLaravelReactI18n();

    const tableColumns = [
        {
            label: "",
            sortField: "",
            sortable: false,
        },
        {
            label: t("pp.accounts.table.account"),
            sortField: "name",
            sortable: true,
        },
        // {
        //     label: "Verification Level",
        //     sortField: "verification_level",
        //     sortable: false,
        // },
        {
            label: t("pp.accounts.table.type"),
            sortField: "type",
            sortable: false,
        },
        {
            label: t("pp.accounts.table.applicationStatus"),
            sortField: "kyc_status",
            sortable: false,
        },
        {
            label: t("pp.accounts.table.role"),
            sortField: "role",
            sortable: false,
        },
        {
            label: t("pp.accounts.table.createdAt"),
            sortField: "created_at",
            sortable: true,
        },
    ];

    const createLink = {
        url: route("accounts.create"),
        label: t("pp.accounts.create"),
    };
    const search = {
        placeholder: t("pp.accounts.search"),
    };

    return (
        <PublicAuthenticated>
            <Head title={t("pp.accounts.title")} />
            <div className="md:flex md:items-center md:justify-between">
                <div className="flex-1 min-w-0">
                    <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:truncate sm:text-3xl sm:tracking-tight">
                        {t("pp.accounts.title")}
                    </h2>
                </div>
            </div>

            <div>
                {/* Table */}
                <MasterTable
                    tableColumns={tableColumns}
                    filters={filters}
                    url={route("accounts.index")}
                    createLink={createLink}
                    search={search}
                    links={accounts?.meta?.links}
                >
                    {accounts?.data?.map((account: any, index: number) => (
                        <TableBody
                            buttons={
                                <>
                                    <PrimaryLink
                                        className="!py-2 "
                                        href={route("accounts.edit", {
                                            id: account.id,
                                        })}
                                    >
                                        <PencilIcon className="w-3 h-3 mr-2" />{" "}
                                        {t("pp.accounts.table.buttons.edit")}
                                    </PrimaryLink>
                                    <PrimaryLink
                                        className="!py-2 "
                                        href={route("accounts.verification", {
                                            id: account.id,
                                        })}
                                    >
                                        <PencilIcon className="w-3 h-3 mr-2" />{" "}
                                        {account.kyc_status == "notStarted" &&
                                            t(
                                                "pp.accounts.table.buttons.startOnbording"
                                            )}
                                        {account.kyc_status != "notStarted" &&
                                            t(
                                                "pp.accounts.table.buttons.continueOnbording"
                                            )}
                                    </PrimaryLink>
                                </>
                            }
                            key={index}
                        >
                            {/* <TableTd>{user.id}</TableTd> */}
                            <TableTd>
                                <span className="capitalize">
                                    {account.account_name}
                                </span>
                            </TableTd>
                            {/* <TableTd>
                                <span className="bg-gray-200 py-0.5 px-2 rounded-xl">
                                    {account.verification_level}
                                </span>
                            </TableTd> */}
                            <TableTd>
                                <TypeView t={t} type={account.type} />
                            </TableTd>
                            <TableTd>
                                <StatusView t={t} status={account.kyc_status} />
                            </TableTd>
                            <TableTd>
                                <Role t={t} role={account?.role_of_me} />
                            </TableTd>
                            <TableTd>
                                <span>{account.created_at_human}</span>
                            </TableTd>
                        </TableBody>
                    ))}
                </MasterTable>
            </div>
        </PublicAuthenticated>
    );
}

function StatusView({ status, t }: { status: string; t: any }) {
    switch (status) {
        case "notCompleted":
            return (
                <span className="bg-sky-500 text-sky-800 px-3 py-1 rounded-xl">
                    {t("pp.accounts.table.status.notStated")}
                </span>
            );
        case "pending":
            return (
                <span className="bg-orange-500 text-orange-800 px-3 py-1 rounded-xl">
                    {t("pp.accounts.table.status.pending")}
                </span>
            );
        case "success":
            return (
                <span className="bg-green-500 text-green-800 px-3 py-1 rounded-xl">
                    {t("pp.accounts.table.status.success")}
                </span>
            );
        case "declined":
            return (
                <span className="bg-red-500 text-red-800 px-3 py-1 rounded-xl">
                    {t("pp.accounts.table.status.declined")}
                </span>
            );
        case "changeRequest":
            return (
                <span className="bg-gray-500 text-gray-800 px-3 py-1 rounded-xl">
                    {t("pp.accounts.table.status.changeRequest")}
                </span>
            );
        case "notStarted":
        default:
            return (
                <span className="bg-gray-200 text-gray-800 px-3 py-1 rounded-xl">
                    {t("pp.accounts.table.status.notStated")}
                </span>
            );
    }
}

function TypeView({ type, t }: { type: string; t: any }) {
    switch (type) {
        case "business":
            return (
                <span className="bg-gray-500 text-gray-800 px-3 py-1 rounded-xl">
                    {t("pp.accounts.table.type.business")}
                </span>
            );
        case "individual":
        default:
            return (
                <span className="bg-gray-200 text-gray-800 px-3 py-1 rounded-xl">
                    {t("pp.accounts.table.type.individual")}
                </span>
            );
    }
}


function Role({ role, t }: { role: string; t: any }) {
    switch (role) {
        case "owner":
            return (
                <span className="bg-gray-500 text-gray-800 px-3 py-1 rounded-xl">
                    {t("pp.accounts.table.role.owner")}
                </span>
            );
        case "member":
        default:
            return (
                <span className="bg-gray-200 text-gray-800 px-3 py-1 rounded-xl">
                    {t("pp.accounts.table.role.member")}
                </span>
            );
    }
}
