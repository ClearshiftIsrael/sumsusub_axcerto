import { SecondaryButton } from "@/Components/elements/buttons/SecondaryButton";
import SelectInput from "@/Components/elements/inputs/SelectInput";
import InputError from "@/Components/InputError";
import InputLabel from "@/Components/InputLabel";
import Modal from "@/Components/Modal";
import PrimaryButton from "@/Components/PrimaryButton";
import TextInput from "@/Components/TextInput";
import PublicAuthenticated from "@/Layouts/PublicAuthenticatedLayout";
import { PlusIcon } from "@heroicons/react/24/outline";
import { Head, useForm, usePage } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { FormEventHandler, useState } from "react";

export default function EditAccount({
    account,
    type,
    roles,
    accTypes,
}: {
    account: any;
    type: string;
    roles: any;
    accTypes: any;
}) {
    const { t } = useLaravelReactI18n();
    const { url, props } = usePage();
    const { user }: any = props.auth;

    const {
        data,
        setData,
        errors,
        post,
        reset,
        processing,
        recentlySuccessful,
    } = useForm({
        first_name: account.meta_data?.first_name ?? user?.first_name,
        last_name: account.meta_data?.last_name ?? user?.last_name,
        middlename: account.meta_data?.middlename,
        surname: account.meta_data?.surname,
        status: 'active',
        type: account.type,
        business_name: account.meta_data?.business_name,
        verification_level: account.verification_level,
        ui: type
    });

    const submit: FormEventHandler = (e) => {
        e.preventDefault();

        post(route("accounts.update-data", { id: account.id }));
    };

    const title =
        type == "create"
            ? t("pp.accounts.create.title")
            : t("pp.accounts.edit.title");

    return (
        <PublicAuthenticated>
            <Head title={title} />
            <div className="md:flex md:items-center md:justify-between">
                <div className="flex-1 min-w-0">
                    <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:truncate sm:text-3xl sm:tracking-tight">
                        {title}
                    </h2>
                </div>
            </div>

            <div>
                <form
                    onSubmit={submit}
                    className="grid md:grid-cols-2 gap-6 mt-4"
                >
                    {/*  */}

                    <div className="space-y-6">
                        <div className="space-y-6">
                            <div className="p-6 bg-white rounded-lg">
                                <div>
                                    <InputLabel
                                        htmlFor="types"
                                        value={t("pp.accounts.edit.form.type")}
                                    />

                                    <SelectInput
                                        className="border-gray-300 mt-1.5 focus:border-primary focus:ring-0.5 focus:ring-primary rounded-md shadow-sm "
                                        options={accTypes}
                                        selectedOption={accTypes.filter(
                                            (obj: any) => {
                                                return obj.value === data.type;
                                            }
                                        )}
                                        setData={(e: any) => setData("type", e)}
                                    />

                                    <InputError
                                        message={errors.type}
                                        className="mt-2"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="space-y-6">
                        {/* individual */}
                        {data.type == "individual" && (
                            <div className="p-6 bg-white rounded-lg">
                                <div className="grid md:grid-cols-2 gap-4">
                                    <div>
                                        <InputLabel
                                            htmlFor="first_name"
                                            value={t(
                                                "pp.accounts.edit.form.first_name"
                                            )}
                                            required={true}
                                        />

                                        <TextInput
                                            id="first_name"
                                            value={data.first_name}
                                            onChange={(e) =>
                                                setData(
                                                    "first_name",
                                                    e.target.value
                                                )
                                            }
                                            type="text"
                                            className="block w-full mt-1"
                                        />

                                        <InputError
                                            message={errors.first_name}
                                            className="mt-2"
                                        />
                                    </div>
                                    {/* last name */}
                                    <div>
                                        <InputLabel
                                            htmlFor="last_name"
                                            value={t(
                                                "pp.accounts.edit.form.last_name"
                                            )}
                                            required={true}
                                        />

                                        <TextInput
                                            id="last_name"
                                            value={data.last_name}
                                            onChange={(e) =>
                                                setData(
                                                    "last_name",
                                                    e.target.value
                                                )
                                            }
                                            type="text"
                                            className="block w-full mt-1"
                                        />

                                        <InputError
                                            message={errors.last_name}
                                            className="mt-2"
                                        />
                                    </div>
                                </div>
                            </div>
                        )}
                        {/* Business */}
                        {data.type == "business" && (
                            <div className="p-6 bg-white rounded-lg">
                                <div className="">
                                    <div>
                                        <InputLabel
                                            htmlFor="business_name"
                                            value={t(
                                                "pp.accounts.edit.form.business_name"
                                            )}
                                            required={true}
                                        />

                                        <TextInput
                                            id="business_name"
                                            value={data.business_name}
                                            onChange={(e) =>
                                                setData(
                                                    "business_name",
                                                    e.target.value
                                                )
                                            }
                                            type="text"
                                            className="block w-full mt-1"
                                        />

                                        <InputError
                                            message={errors.business_name}
                                            className="mt-2"
                                        />
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                    <div className="flex md:col-span-2 mt-4">
                        <PrimaryButton className="ml-auto">
                            {type == "edit"
                                ? t("pp.accounts.edit.form.btn.save")
                                : t("pp.accounts.edit.form.btn.save")}
                        </PrimaryButton>
                    </div>
                </form>
            </div>
            <hr className="mt-12" />
            {/*  */}
            {type == "edit" && (
                <div className="mt-12">
                    <AccountTeam
                        users={account.users}
                        account={account}
                        roles={roles}
                        pageType={type}
                        t={t}
                    />
                </div>
            )}
        </PublicAuthenticated>
    );
}

function AccountTeam({ users, account, roles,pageType,t }: any) {
    const [isModalOpen, closeModal] = useState(false);
    const [isChangeModalOpen, closeChangeModal] = useState(false);

    //    const { showModal, ModalProps, handleClose } = useConfirm();

    return (
        <div className="">
            <div className="sm:flex sm:items-center">
                <div className="sm:flex-auto">
                    <h1 className="text-base font-[800] leading-6 text-gray-900">
                        {t("pp.accounts.edit.accounts.title")}
                    </h1>
                    <p className="mt-2 text-sm text-gray-700">
                        {t("pp.accounts.edit.accounts.description")}
                    </p>
                </div>
                <div className="mt-4 space-x-2 sm:ml-16 sm:mt-0 sm:flex-none">
                    <SecondaryButton
                        onClick={() => closeModal(true)}
                        type="button"
                        className="space-x-2"
                    >
                        <span className="self-center">
                            {t("pp.accounts.edit.accounts.add_button")}
                        </span>
                        <PlusIcon className="self-center w-4 h-4" />
                    </SecondaryButton>
                </div>
            </div>
            <div className="flow-root mt-8">
                <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                    <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                        <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
                            <table className="min-w-full divide-y divide-gray-300">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th
                                            scope="col"
                                            className="py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6"
                                        >
                                            {t(
                                                "pp.accounts.edit.accounts.table.user"
                                            )}
                                        </th>
                                        <th
                                            scope="col"
                                            className="px-3 py-3.5 text-left text-sm font-semibold text-gray-900"
                                        >
                                            {t(
                                                "pp.accounts.edit.accounts.table.role"
                                            )}
                                        </th>
                                        <th
                                            scope="col"
                                            className="relative py-3.5 pl-3 pr-4 sm:pr-6"
                                        >
                                            <span className="sr-only">
                                                Edit
                                            </span>
                                        </th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-200">
                                    {users?.map((user: any, index: number) => (
                                        <tr key={user.email}>
                                            <td className="py-4 pl-4 pr-3 text-sm font-medium text-gray-900 whitespace-nowrap sm:pl-6">
                                                <h6>{user.name}</h6>
                                                <p>{user.email}</p>
                                            </td>
                                            <td className="whitespace-nowrap font-[800] px-3 py-4 text-sm text-gray-500 uppercase">
                                                {user.pivot.role}
                                            </td>
                                            <td className="relative py-4 pl-3 pr-4 text-sm font-medium text-right whitespace-nowrap sm:pr-6">
                                                {/* <button
                                                    onClick={() =>
                                                        deleteUser(user.id)
                                                    }
                                                    className="flex px-6 py-2 space-x-2 text-white bg-gray-800 rounded-lg"
                                                >
                                                    <TrashIcon className="self-center w-4 h-4" />
                                                </button> */}

                                                {/* <button
                                                    onClick={() =>
                                                        showModal({
                                                            theme: ModalTheme.DeleteConfirmation,
                                                            title: "Confirm Deletion",
                                                            description:
                                                                "Are you sure you want to delete this item? This action cannot be undone.",
                                                            onConfirm: () => {
                                                                console.log(
                                                                    "Item deleted."
                                                                );
                                                                handleClose();
                                                            },
                                                            onCancel:
                                                                handleClose,
                                                        })
                                                    }
                                                >
                                                    Delete Item
                                                </button>
                                                <ConfirmModal {...ModalProps} /> */}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
            {/* test */}
            <AddUser
                isModalOpen={isModalOpen}
                closeModal={closeModal}
                account={account}
                roles={roles}
                t={t}
            />
            <ChangeOwner
                isModalOpen={isChangeModalOpen}
                closeModal={closeChangeModal}
                account={account}
            />
        </div>
    );
}

function AddUser({ isModalOpen, closeModal, account, roles,t }: any) {
    const {
        data,
        setData,
        errors,
        post,
        reset,
        processing,
        recentlySuccessful,
    } = useForm({
        email: "",
        role: "",
        accountId: account.id,
    });

    const submit: FormEventHandler = (e) => {
        e.preventDefault();

        post(route("accounts.add-user"),{
            preserveScroll: false,
            onSuccess(res){
                closeModal(false);
            }
        });
    };

    return (
        <Modal
            maxWidth="2xl"
            show={isModalOpen}
            onClose={() => closeModal(false)}
            className="bg-white w-[500px] p-8"
        >
            <h5 className="font-[700]">
                {t("pp.accounts.edit.accounts.modal.title")}
            </h5>
            <form onSubmit={submit} className="mt-4 space-y-4">
                <div>
                    <InputLabel
                        htmlFor="status"
                        value={t("pp.accounts.edit.accounts.modal.input.role")}
                    />

                    <SelectInput
                        className="border-gray-300 mt-1.5 focus:border-primary focus:ring-0.5 focus:ring-primary rounded-md shadow-sm "
                        options={roles}
                        selectedOption={roles.filter((obj: any) => {
                            return obj.value === data.role;
                        })}
                        setData={(e: any) => setData("role", e)}
                    />

                    <InputError message={errors.role} className="mt-2" />
                </div>
                {/* Status input */}
                <div>
                    <InputLabel
                        htmlFor="email"
                        value={t("pp.accounts.edit.accounts.modal.input.email")}
                    />

                    <TextInput
                        id="email"
                        value={data.email}
                        onChange={(e) => setData("email", e.target.value)}
                        type="text"
                        className="block w-full mt-1"
                    />

                    <InputError message={errors.email} className="mt-2" />
                </div>

                {/* Submit button */}
                <div className="flex justify-center mt-4">
                    <button
                        type="submit"
                        className="px-12 py-3 text-white bg-gray-900 rounded-xl"
                        disabled={processing}
                    >
                        {processing ? (
                            <div className="flex items-center">
                                <svg
                                    aria-hidden="true"
                                    role="status"
                                    className="inline w-4 h-4 mr-3 text-white animate-spin"
                                    viewBox="0 0 100 101"
                                    fill="none"
                                    xmlns="http://www.w3.org/2000/svg"
                                >
                                    <path
                                        d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z"
                                        fill="#E5E7EB"
                                    ></path>
                                    <path
                                        d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z"
                                        fill="currentColor"
                                    ></path>
                                </svg>
                                {t(
                                    "pp.accounts.edit.accounts.modal.button.loading"
                                )}
                            </div>
                        ) : (
                            t("pp.accounts.edit.accounts.modal.button")
                        )}
                    </button>
                </div>
            </form>
        </Modal>
    );
}

function ChangeOwner({ isModalOpen, closeModal, account }: any) {
    const {
        data,
        setData,
        errors,
        post,
        reset,
        processing,
        recentlySuccessful,
    } = useForm({
        email: "",
        role: "owner",
        accountId: account.id,
    });

    const submit: FormEventHandler = (e) => {
        e.preventDefault();

        post(route("accounts.add-user"), {
            preserveScroll: false,
            onSuccess(res) {
                closeModal(false);
            }
        });
    };

    return (
        <Modal
            maxWidth="2xl"
            show={isModalOpen}
            onClose={() => closeModal(false)}
            className="bg-white w-[500px] p-8"
        >
            <h5 className="font-[700]">Transfer Ownership</h5>
            <form onSubmit={submit} className="mt-4 space-y-4">
                {/* <div>
                    <InputLabel htmlFor="status" value="Status" />

                    <SelectInput
                        className="border-gray-300 mt-1.5 focus:border-primary focus:ring-0.5 focus:ring-primary rounded-md shadow-sm "
                        // options={roles}
                        options={roles.filter((obj: { value: string; }) => obj.value !== 'owner')}
                        selectedOption={roles.filter((obj: any) => {
                            return obj.value === data.role;
                        })}
                        setData={(e: any) => setData("role", e)}
                    />

                    <InputError message={errors.role} className="mt-2" />
                </div> */}
                {/* Status input */}
                <div>
                    <InputLabel htmlFor="email" value="Email" />

                    <TextInput
                        id="email"
                        value={data.email}
                        onChange={(e) => setData("email", e.target.value)}
                        type="text"
                        className="block w-full mt-1"
                    />

                    <InputError message={errors.email} className="mt-2" />
                </div>

                {/* Submit button */}
                <div className="flex justify-center mt-4">
                    <button
                        type="submit"
                        className="px-12 py-3 text-white bg-gray-900 rounded-xl"
                        disabled={processing}
                    >
                        {processing ? (
                            <div className="flex items-center">
                                <svg aria-hidden="true" role="status" className="inline w-4 h-4 mr-3 text-white animate-spin" viewBox="0 0 100 101" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M100 50.5908C100 78.2051 77.6142 100.591 50 100.591C22.3858 100.591 0 78.2051 0 50.5908C0 22.9766 22.3858 0.59082 50 0.59082C77.6142 0.59082 100 22.9766 100 50.5908ZM9.08144 50.5908C9.08144 73.1895 27.4013 91.5094 50 91.5094C72.5987 91.5094 90.9186 73.1895 90.9186 50.5908C90.9186 27.9921 72.5987 9.67226 50 9.67226C27.4013 9.67226 9.08144 27.9921 9.08144 50.5908Z" fill="#E5E7EB"></path>
                                    <path d="M93.9676 39.0409C96.393 38.4038 97.8624 35.9116 97.0079 33.5539C95.2932 28.8227 92.871 24.3692 89.8167 20.348C85.8452 15.1192 80.8826 10.7238 75.2124 7.41289C69.5422 4.10194 63.2754 1.94025 56.7698 1.05124C51.7666 0.367541 46.6976 0.446843 41.7345 1.27873C39.2613 1.69328 37.813 4.19778 38.4501 6.62326C39.0873 9.04874 41.5694 10.4717 44.0505 10.1071C47.8511 9.54855 51.7191 9.52689 55.5402 10.0491C60.8642 10.7766 65.9928 12.5457 70.6331 15.2552C75.2735 17.9648 79.3347 21.5619 82.5849 25.841C84.9175 28.9121 86.7997 32.2913 88.1811 35.8758C89.083 38.2158 91.5421 39.6781 93.9676 39.0409Z" fill="currentColor"></path>
                                </svg>
                                Inviting...
                            </div>
                        ) : (
                            'Invite'
                        )}
                    </button>
                </div>
            </form>
        </Modal>
    );
}
