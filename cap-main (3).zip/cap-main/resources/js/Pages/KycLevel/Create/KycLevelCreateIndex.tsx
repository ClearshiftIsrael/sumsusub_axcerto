export default function KycLevelCreateIndex() {

};
