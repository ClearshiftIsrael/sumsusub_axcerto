import Modal from "@/Components/Modal";
import ConfirmButton from "@/Components/elements/buttons/ConfirmButton";
import {
    PrimaryButton,
    PrimaryLink,
} from "@/Components/elements/buttons/PrimaryButton";
import InputError from "@/Components/elements/inputs/InputError";
import InputLabel from "@/Components/elements/inputs/InputLabel";
import SelectInput from "@/Components/elements/inputs/SelectInput";
import TextArea from "@/Components/elements/inputs/TextArea";
import TextInput from "@/Components/elements/inputs/TextInput";
import MasterTable, {
    TableBody,
    TableTd,
} from "@/Components/elements/tables/masterTable";
import Authenticated from "@/Layouts/AuthenticatedLayout";
import {
    CircleStackIcon,
    PencilIcon,
    XCircleIcon,
} from "@heroicons/react/24/outline";
import { Head, Link, router } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { useState } from "react";
import useStateRef from "react-usestateref";

export default function KycLevelAllIndex({ filters, levels, types }: any) {
    const { t } = useLaravelReactI18n();
    const bRoutes = [
        {
            name: "breadcrumbs.dashboard",
            hasArrow: true,
            link: route("dashboard"),
        },
        {
            name: "breadcrumbs.kyc-levels",
            hasArrow: true,
            link: route("kyc-levels.index"),
        },
    ];

    const tableColumns = [
        {
            label: "",
            sortField: "",
            sortable: false,
        },
        {
            label: t("level.all.table.id"),
            sortField: "id",
            sortable: true,
        },
        {
            label: t("level.all.table.name"),
            sortField: "name",
            sortable: true,
        },
        {
            label: t("level.all.table.key"),
            sortField: "key",
            sortable: true,
        },
        {
            label: t("level.all.table.description"),
            sortField: "key",
            sortable: true,
        },
        {
            label: t("level.all.table.level"),
            sortField: "type",
            sortable: true,
        },
        {
            label: t("level.all.table.created_at"),
            sortField: "created_at",
            sortable: true,
        },
    ];

    const search = {
        placeholder: t("users.all.search"),
    };

    const [buttonName, setButtonName, buttonNameRef] = useStateRef("Create");
    const showModal = () => {
        setButtonName("Create");
        setIsModalOpen(true);
    };

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [name, setName, NameRef] = useStateRef("");
    const [key, setKey, KeyRef] = useStateRef("");
    const [description, setDescription, DescriptionRef] = useStateRef("");
    const [type, setType, TypeRef] = useStateRef("");
    const [levelId, setLevelId, LevelRef] = useStateRef("");

    function openSelectionModal(level: any) {
        setKey(level.key);
        setName(level?.name);
        setType(level?.level_type);
        setDescription(level?.description);
        setIsModalOpen(true);
    }
    function closeModal() {
        setKey("");
        setName("");
        setType("")
        setDescription("");
        setIsModalOpen(false);
    }
    const submit = () => {
        if (KeyRef.current && NameRef.current) {
            if (buttonNameRef.current == "Create") {
                router.post(route("kyc-levels.store"), {
                    name: NameRef.current,
                    key: KeyRef.current,
                    level_type: TypeRef.current,
                    description: DescriptionRef.current,
                });
            } else {
                if (LevelRef.current) {
                    router.patch(
                        route("kyc-levels.update", {
                            id: LevelRef.current,
                        }),
                        {
                            key: KeyRef.current,
                            level_type: TypeRef.current,
                            name: NameRef.current,
                            description: DescriptionRef.current,
                        }
                    );
                }
            }

            closeModal();
        } else {
        }
        setKey("");
        setName("");
        setType("");
        setDescription("");
        setLevelId("");
    };

    const defaultHandler = (id: any) => {
        router.patch(
            route("kyc-levels.update", {
                id: id,
            })
        );
    };

    return (
        <Authenticated bRoutes={bRoutes}>
            <Head title={t("level.all.title")} />
            <div className="md:flex md:items-center md:justify-between">
                <div className="flex-1 min-w-0">
                    <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:truncate sm:text-3xl sm:tracking-tight">
                        {t("level.all.title")}
                    </h2>
                </div>
            </div>

            <div>
                {/* Table */}
                <MasterTable
                    tableColumns={tableColumns}
                    filters={filters}
                    url={route("kyc-levels.index")}
                    modalOpen={showModal}
                    // createLink={createLink}
                    search={search}
                    links={levels?.meta?.links}
                >
                    {levels?.data?.map((level: any, index: number) => (
                        <TableBody
                            buttons={
                                <>
                                    <PrimaryButton
                                        className="!py-2 "
                                        onClick={() => {
                                            openSelectionModal(level);
                                            setButtonName("Edit");
                                            setLevelId(level.id);
                                        }}
                                    >
                                        <PencilIcon className="w-3 h-3 mr-2" />{" "}
                                        Edit
                                    </PrimaryButton>
                                    <PrimaryButton
                                        className="!py-2 bg-secondary"
                                        onClick={() => defaultHandler(level.id)}
                                    >
                                        <CircleStackIcon className="w-3 h-3 mr-2" />{" "}
                                        Default
                                    </PrimaryButton>
                                    <ConfirmButton
                                        className="!py-2"
                                        url={route("kyc-levels.destroy", {
                                            id: level.id,
                                        })}
                                        label={t(
                                            "table.all.delete"
                                        )}
                                    />
                                </>
                            }
                            key={level.id}
                        >
                            <TableTd>{level.id}</TableTd>
                            <TableTd>{level?.name}</TableTd>
                            <TableTd>
                                <span
                                    className={` rounded-md  ${level.default === "yes"
                                        ? "text-primary   bg-green-50"
                                        : ""
                                        }`}
                                >
                                    {level.key}
                                </span>
                            </TableTd>
                            <TableTd>{level.description}</TableTd>
                            <TableTd>
                                <span className="uppercase">
                                    {level?.level_type}
                                </span>
                            </TableTd>
                            <TableTd>{level.created_at_human}</TableTd>
                        </TableBody>
                    ))}
                </MasterTable>
            </div>
            {/* //////////// */}
            <Modal
                show={isModalOpen}
                onClose={() => console.log("g")}
            // className=""
            >
                <div className="absolute top-0 right-0">
                    <XCircleIcon
                        onClick={() => {
                            closeModal();
                            // reset()
                        }}
                        className="w-10 h-10 hover:cursor-pointer"
                    />
                </div>
                <div className=" h-[98%] mt-8bg-white">
                    <div className="grid w-full grid-cols-1 p-4 bg-white rounded-lg shadow-md ">
                        {/* <div className="grid grid-cols-2 gap-2"> */}
                        <div>
                            <span className="pb-4 font-semibold capitalize">
                                {buttonNameRef.current} KYC-KYB Level.
                            </span>
                            <div className="relative border-[1px] rounded-xl border-slate-400  flex p-1 mt-2">
                                {/* <form onSubmit={submit}> */}
                                <div className="bg-[#FFFFFF] p-8">
                                    <div className="grid grid-flow-col gap-4">
                                        <div className="row-span-3">
                                            {/* Name */}
                                            <div>
                                                <label
                                                    htmlFor="name"
                                                    className="block text-sm font-medium text-gray-700"
                                                >
                                                    Name{" "}
                                                    <span className="text-red-600">
                                                        *
                                                    </span>
                                                </label>

                                                <TextInput
                                                    id="name"
                                                    className="block w-full mt-1"
                                                    value={NameRef.current}
                                                    onChange={(e) => {
                                                        // setData(
                                                        //     "name",
                                                        //     e.target.value
                                                        // );
                                                        setName(e.target.value);
                                                    }}
                                                    isFocused
                                                    placeholder="Name"
                                                    autoComplete="name"
                                                />

                                                <InputError
                                                    className="mt-2"
                                                // message={errors.name}
                                                />
                                            </div>
                                            {/* description */}
                                            <div className="mt-5">
                                                <label
                                                    htmlFor="key"
                                                    className="block text-sm font-medium text-gray-700"
                                                >
                                                    Key{" "}
                                                    <span className="text-red-600">
                                                        *
                                                    </span>
                                                </label>

                                                <TextInput
                                                    id="description"
                                                    className="block w-full mt-1"
                                                    value={KeyRef.current}
                                                    onChange={(e) => {
                                                        setKey(e.target.value);
                                                    }}
                                                    // rows={5}
                                                    placeholder="Reason"
                                                    autoComplete="reason"
                                                />

                                                <InputError
                                                    className="mt-2"
                                                // message={errors.reason}
                                                />
                                            </div>

                                            <div className="mt-5">
                                                <label
                                                    htmlFor="description"
                                                    className="block text-sm font-medium text-gray-700"
                                                >
                                                    Description{" "}
                                                    <span className="text-red-600">
                                                        *
                                                    </span>
                                                </label>

                                                <TextArea
                                                    id="description"
                                                    className="block w-full mt-1"
                                                    value={
                                                        DescriptionRef.current
                                                    }
                                                    onChange={(e) => {
                                                        setDescription(
                                                            e.target.value
                                                        );
                                                    }}
                                                    // rows={5}
                                                    placeholder="description"
                                                    autoComplete="description"
                                                />

                                                <InputError
                                                    className="mt-2"
                                                // message={errors.reason}
                                                />
                                            </div>
                                            <div>
                                                <InputLabel
                                                    htmlFor="level"
                                                    value="Level"
                                                    required={true}
                                                />

                                                <SelectInput
                                                    className="border-gray-300 mt-1.5 focus:border-primary focus:ring-0.5 focus:ring-primary rounded-md shadow-sm "
                                                    options={types}
                                                    selectedOption={types.filter(
                                                        (obj: any) => {
                                                            return (
                                                                obj.value === TypeRef.current
                                                            );
                                                        }
                                                    )}
                                                    setData={(e: any) =>
                                                        setType(e)
                                                    }
                                                />

                                                {/* <InputError
                                                    message={errors.status}
                                                    className="mt-2"
                                                /> */}
                                            </div>
                                        </div>
                                    </div>
                                    <div className="px-4 py-4 sm:px-8">
                                        <div className="flex items-center justify-center">
                                            <PrimaryButton
                                                //  disabled={processing}
                                                onClick={submit}
                                            >
                                                {buttonNameRef.current}
                                            </PrimaryButton>

                                            {/* <Transition
                                                    show={recentlySuccessful}
                                                    enterFrom="opacity-0"
                                                    leaveTo="opacity-0"
                                                    className="transition ease-in-out"
                                                >
                                                    <p className="text-sm text-gray-600">
                                                        Account {buttonNameRef.current} successfully.
                                                    </p>
                                                </Transition> */}
                                        </div>
                                    </div>
                                </div>

                                {/* </form> */}
                            </div>
                        </div>
                        <div></div>
                        {/* </div> */}
                    </div>
                </div>
            </Modal>
        </Authenticated>
    );
}
