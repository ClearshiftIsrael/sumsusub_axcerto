import Authenticated from "@/Layouts/AuthenticatedLayout";
import { ArrowDownTrayIcon, ArrowLeftIcon, ArrowPathIcon, BackwardIcon } from "@heroicons/react/24/outline";
import { Head, router } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import PrimaryInformation from "./Components/PrimaryInformation";
import PrimaryButton from "@/Components/PrimaryButton";
import { useState } from "react";
import AddressInformation from "./Components/AddressInformation";
import StepInformation from "./Components/StepInformation";
import KycStatus from "./Components/KycStatus";
import Questionary from "./Components/Questionary";
import UserCompanyInformation from "./Components/UserCompanyInformation";
import { PrimaryLink } from "@/Components/elements/buttons/PrimaryButton";
import { SecondaryLink } from "@/Components/elements/buttons/SecondaryButton";
import { BackspaceIcon } from "@heroicons/react/20/solid";
import CompanyInformation from "./Components/CompanyInformation";

export default function UserInfoIndex({ user, images, questionary, businessAccount }: any) {
    const { t } = useLaravelReactI18n();
    const [isRefetching, setIsRefetching] = useState(false);
    console.log(businessAccount);
    const bRoutes = [
        {
            name: "breadcrumbs.users",
            hasArrow: true,
            link: route("users.index"),
        },
        {
            name: user.name,
            hasArrow: true,
        },
    ];
    function reFetch() {
        setIsRefetching(true);
        router.visit(route("users.refetch", { id: user.id }), {
            method: "post",
            preserveState: false,
            preserveScroll: false,
            onProgress: (progress) => {
                setIsRefetching(true);
            },
            onSuccess: (page) => {
                setIsRefetching(false);
            },
        });
    }


    return (
        <Authenticated bRoutes={bRoutes}>
            <Head title={t("users.all.title")} />
            <div className="mb-16 md:flex md:items-center md:justify-between ">
                <div className="flex items-center justify-between w-full">
                    {/* Use flex container */}
                    <div className="flex-1 min-w-0">
                        <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:truncate sm:text-3xl sm:tracking-tight">
                           User {" - "} {user?.name}
                            {businessAccount && <SecondaryLink  
                                href={route('users.show', { user: businessAccount?.id })}
                                className="!rounded-md ml-2 !p-2"
                            >
                                <ArrowLeftIcon className="w-5 h-5 mr-1" />Back to Business
                            </SecondaryLink>}

                        </h2>
                    </div>
                    {/* Button */}
                    {user?.has_kyc && <PrimaryButton
                        onClick={() => reFetch()}
                        className="mr-2 space-x-4 !p-2"
                        disabled={isRefetching}
                    >
                        <ArrowPathIcon
                            className={` ${isRefetching && "animate-spin"
                                } self-center text-lg font-bold h-5 w-5 `}
                        />{" "}
                        {!isRefetching && <span>Refetch Information</span>}
                        {isRefetching && <span>Fetching...</span>}
                    </PrimaryButton>}
                    {user?.meta_data?.summary &&
                        <a
                            href={route('file.download', { id: user?.id })}
                            target="_self"
                            className="space-x-4 !rounded-md !p-2 inline-flex items-center px-4 py-2 bg-gray-800 border border-transparent font-semibold text-xs text-white uppercase tracking-widest hover:bg-gray-700 focus:bg-gray-700 active:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 transition ease-in-out duration-150"
                        >
                            <ArrowDownTrayIcon className="self-center w-5 h-5 text-lg font-bold " />{" "}
                            <span>Summary File</span>
                        </a>
                    }
                </div>
            </div>
            <div className="space-y-12">
                {/* Status */}
                <KycStatus user={user} />
                {/* Primary */}
                <PrimaryInformation
                    user={user}
                    images={images?.LivenessImage}
                />
                {/* business */}
                {businessAccount &&
                    <CompanyInformation
                        business={businessAccount}
                        user={user}
                    />}
                {/* Address */}
                {user?.meta_data?.addresses?.length > 0 && (
                    <AddressInformation
                        addresses={user?.meta_data?.addresses}
                    />
                )}
                {/* show docs */}
                {user.meta_data?.iddocs?.map((document: any, index: number) => {
                    const step = findImages(document, user.meta_data?.images);
                    return (
                        <StepInformation
                            step={index + 1}
                            document={document}
                            imageData={step}
                            user={user}
                        />
                    );
                })}
                {user?.meta_data?.questionnaires?.length > 0 && (
                    <Questionary
                        questionnaires={questionary}
                    />
                )}
            </div>
        </Authenticated>
    );
}

function findImages(document: any, images: any) {
    let response: any = [];
    Object.keys(images).map((key: any, index: number) => {
        const item = images[key];
        if (item.document == document.idDocType) {
            response = item;
        }
    });
    return response;
}
