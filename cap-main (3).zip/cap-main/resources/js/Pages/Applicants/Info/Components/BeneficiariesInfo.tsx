import { PrimaryButton, PrimaryLink } from "@/Components/elements/buttons/PrimaryButton";
import { EyeIcon } from "@heroicons/react/24/outline";

export default function BeneficiariesInfo({ beneficiaries }: any) {
    console.log(beneficiaries)
    return (
        <div className="p-8 bg-white border rounded-lg shadow-sm">
            <div className="px-4 sm:px-0">
                <h3 className="text-base font-semibold leading-7 text-gray-900">
                    Beneficiaries Information
                </h3>
                <p className="max-w-2xl mt-1 text-sm leading-6 text-gray-500">
                    Beneficiaries details.
                </p>
            </div>
            <div className="w-full mt-6 border-t border-gray-100">
                {/* <dl className="divide-y divide-gray-100"> */}
                {/* <div className="px-4 py-6 sm:grid sm:grid-cols-4 sm:gap-4 sm:px-0 md:divide-x-2 md:text-center"> */}
                {/* <h2 className="pb-4 text-lg font-semibold text-gray-500">Transacciones</h2>
                        <div className="my-1"></div> */}
                {/* <div className="h-px mb-6 bg-gradient-to-r from-cyan-300 to-cyan-500"></div> */}
                <table className="w-full text-sm table-auto">
                    <thead>
                        <tr className="text-sm leading-normal">
                            <th className="px-4 py-2 text-sm font-bold uppercase border-b bg-grey-lightest text-grey-light border-grey-light">Name</th>
                            <th className="px-4 py-2 text-sm font-bold uppercase border-b bg-grey-lightest text-grey-light border-grey-light">Sumsub Status</th>
                            <th className="px-4 py-2 text-sm font-bold uppercase border-b bg-grey-lightest text-grey-light border-grey-light">Admin Status</th>
                            <th className="px-4 py-2 text-sm font-bold uppercase border-b bg-grey-lightest text-grey-light border-grey-light">Position</th>
                            <th className="px-4 py-2 text-sm font-bold uppercase border-b bg-grey-lightest text-grey-light border-grey-light">Type</th>
                            <th className="px-4 py-2 text-sm font-bold text-right uppercase border-b bg-grey-lightest text-grey-light border-grey-light">Show</th>
                        </tr>
                    </thead>
                    <tbody>
                        {beneficiaries.map((user: any, index: any) => (
                            <tr className="hover:bg-grey-lighter">
                                <td className="px-4 py-2 text-center border-b border-grey-light">{user?.name}</td>
                                <td className="px-4 py-2 text-center border-b border-grey-light">
                                    <SumsubStatus kycInfo={user?.kyc_info} />
                                    {/* {user?.kyc_info?.status} */}
                                </td>
                                <td className="px-4 py-2 text-center border-b border-grey-light">
                                    <AdminStatus kycInfo={user?.kyc_info} />
                                    {/* {user?.kyc_info?.admin_status} */}
                                </td>
                                <td className="px-4 py-2 text-center border-b border-grey-light">
                                    {user?.meta_data?.position ?? '-'}
                                    {/* {user?.kyc_info?.admin_status} */}
                                </td>
                                <td className="px-4 py-2 text-center border-b border-grey-light">
                                    {user?.meta_data?.type ?? '-'}
                                    {/* {user?.kyc_info?.admin_status} */}
                                </td>
                                <td className="px-4 py-2 text-right border-b border-grey-light">
                                    <PrimaryLink
                                        href={route("users.show", {
                                            id: user.id,
                                        })}
                                    >
                                        <EyeIcon className="w-3 h-3 mr-2" />{" "}
                                        Show
                                    </PrimaryLink>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                {/* </div> */}
                {/* </dl> */}
            </div>

        </div>
    );
};

function AdminStatus({ kycInfo }: any) {
    return (
        <p>
            {kycInfo?.admin_status == "pending" && (
                <span className="px-6 py-2 text-yellow-700 bg-yellow-100 rounded-md">
                    Pending
                </span>
            )}
            {kycInfo?.admin_status == "inprogress" && (
                <span className="px-6 py-2 text-yellow-700 bg-yellow-100 rounded-md">
                    Inprogress
                </span>
            )}
            {kycInfo?.admin_status == "approved" && (
                <span className="px-6 py-2 text-green-700 bg-green-100 rounded-md">
                    Success
                </span>
            )}
            {kycInfo?.admin_status == "rejected" && (
                <span className="px-6 py-2 text-red-700 bg-red-100 rounded-md">
                    Declined
                </span>
            )}
            {kycInfo?.admin_status == undefined && (
                <span className="px-6 py-2 text-yellow-700 bg-red-100 rounded-md">
                    Not Started
                </span>
            )}
        </p>);
}
function SumsubStatus({ kycInfo }: any) {
    return (
        <p>
            {(kycInfo?.status == "notStarted" || kycInfo?.status == undefined) && (
                <span className="px-6 py-2 text-yellow-700 bg-yellow-100 rounded-md">
                    Not Started
                </span>
            )}
            {kycInfo?.status == "notCompleted" && (
                <span className="px-6 py-2 text-yellow-700 bg-yellow-100 rounded-md">
                    Not Completed
                </span>
            )}
            {kycInfo?.status == "pending" && (
                <span className="px-6 py-2 text-yellow-700 bg-yellow-100 rounded-md">
                    Pending
                </span>
            )}
            {kycInfo?.status == "success" && (
                <span className="px-6 py-2 text-green-700 bg-green-100 rounded-md">
                    Success
                </span>
            )}
            {kycInfo?.status == "declined" && (
                <span className="px-6 py-2 text-red-700 bg-red-100 rounded-md">
                    Declined
                </span>
            )}
        </p>
    );
}