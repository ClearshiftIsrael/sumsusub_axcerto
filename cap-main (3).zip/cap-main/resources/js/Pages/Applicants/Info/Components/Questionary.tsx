
import React from 'react';

interface questionnaires {
    id: string;
    sections: {
        [key: string]: {
            items: {
                [key: string]: { value: string };
            };
        };
    };
}

interface Props {
    questionnaires: questionnaires[];
}

export default function ({ questionnaires }: Props) {
    console.log(questionnaires)
    return (
        <div className="p-8 bg-white border rounded-lg shadow-sm">
            <div className="px-4 sm:px-0">
                <h3 className="text-base font-semibold leading-7 text-gray-900">
                    Applicant Questions
                </h3>
                <p className="max-w-2xl mt-1 text-sm leading-6 text-gray-500">
                    Check all the answers filled by the applicant.
                </p>
            </div>
            <div className="w-full mt-6 border-t border-gray-100">
                <dl className="divide-y divide-gray-100">
                    <div className="px-4 py-6 sm:grid sm:grid-cols-2 sm:gap-4 sm:px-0 md:divide-x-2">
                        {/* <div className="p-4"></div> */}
                        {questionnaires?.map((userData) => (
                            <div className=" bg-gray-50 rounded-xl">
                                <div key={userData.id}>
                                    <div className="px-4 py-2 text-center bg-gray-100 rounded-t-xl">
                                        <h6>Applicant answers</h6>
                                    </div>
                                    <div className="pt-6 divide-y divide-gray-250">
                                        {/* <h3>User ID: {userData.id}</h3> */}
                                        {Object.keys(userData.sections).map((sectionKey, tIndex) => (
                                            <div className='pt-6 pb-6' key={sectionKey}>

                                                <h4 className='pl-1 text-xl font-bold'>{tIndex + 1}. {sectionKey}</h4>
                                                <div>
                                                    {Object.entries(userData.sections[sectionKey].items).map(
                                                        ([itemKey, item], index:any) => (
                                                            <div key={itemKey} className="px-4 py-2 text-left sm:grid sm:grid-cols-11 sm:gap-4 sm:px-0">
                                                                <dt className="col-span-5 pl-3 text-sm font-medium leading-6 text-gray-900 capitalize ">
                                                                    <span className="font-extrabold">{tIndex + 1}.{index + 1}.</span> {itemKey}
                                                                </dt>
                                                                <dt className="text-sm">:</dt>
                                                                <dd className="col-span-5 mt-1 text-sm leading-6 text-gray-700 sm:mt-0">
                                                                    {item.value}
                                                                </dd>
                                                            </div>
                                                        )
                                                    )}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                </dl>
            </div>
        </div>

    );
};



