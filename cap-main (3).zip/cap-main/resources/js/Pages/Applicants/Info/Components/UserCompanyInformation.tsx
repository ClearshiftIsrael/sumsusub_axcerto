export default function UserCompanyInformation({ businessAccount }:any) {
    return (
        <div className="p-8 bg-white border rounded-lg shadow-sm">
            <div className="px-4 sm:px-0">
                <h3 className="text-base font-semibold leading-7 text-gray-900">
                    Applicant Business Information
                </h3>
                <p className="max-w-2xl mt-1 text-sm leading-6 text-gray-500">
                    Business details .
                </p>
            </div>
            <div className="w-full mt-6 border-t border-gray-100">
                <dl className="divide-y divide-gray-100">
                    <div className="px-4 py-6 sm:grid sm:grid-cols-4 sm:gap-4 sm:px-0 md:divide-x-2 md:text-center">
                        <div className="grid grid-cols-2 md:grid-cols-1">
                            <dt className="text-sm font-medium leading-6 text-gray-900">
                                Company Name
                            </dt>
                            <dd className="mt-0 text-sm leading-6 text-gray-700 capitalize md:mt-1 sm:col-span-2 sm:mt-0">
                                {businessAccount?.company_name}
                            </dd>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-1">
                            <dt className="text-sm font-medium leading-6 text-gray-900">
                                Registration Number
                            </dt>
                            <dd className="mt-1 text-sm leading-6 text-gray-700 capitalize sm:col-span-2 sm:mt-0">
                                {businessAccount?.registration_number}
                            </dd>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-1">
                            <dt className="text-sm font-medium leading-6 text-gray-900">
                                Country
                            </dt>
                            <dd className="mt-1 text-sm leading-6 text-gray-700 capitalize sm:col-span-2 sm:mt-0">
                                {businessAccount?.country}
                            </dd>
                        </div>
                        {/* <div className="grid grid-cols-2 md:grid-cols-1">
                            <dt className="text-sm font-medium leading-6 text-gray-900">
                                Last name
                            </dt>
                            <dd className="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">
                                {user.last_name}
                            </dd>
                        </div> */}
                    </div>
                </dl>
            </div>
            {/* <div className="grid w-full grid-cols-7 mt-6 border-t border-gray-100">
                <div className="flex justify-center order-2 col-span-2 p-4 bg-gray-50">
                    {user.meta_data?.images?.SELFIE ? (
                        <div className="flex">
                            {user.meta_data?.images?.SELFIE?.files?.map(
                                (image: any, index: number) => (
                                    <div className="self-center">
                                        <img
                                            className="w-[auto] max-h-[300px] h-[auto] rounded-xl border border-primary object-contain"
                                            src={image.url}
                                        />
                                    </div>
                                )
                            )}
                        </div>
                    ) : (
                        <div className="self-center">
                            <img
                                className="w-[200px] h-[auto] rounded-xl border border-primary"
                                src="/assets/image/noImage.png?a=10"
                            />
                        </div>
                    )}
                </div>
                <dl className="order-1 col-span-5 divide-y divide-gray-100">
                    <div className="px-4 py-6 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-0">
                        <dt className="text-sm font-medium leading-6 text-gray-900 sm:col-span-1">
                            Email address
                        </dt>
                        <dd className="mt-1 text-sm leading-6 text-gray-700 sm:mt-0">
                            {user.email}
                        </dd>
                        <dd className="flex">
                            {user.email_verified_at && (
                                <span className="flex px-4 py-1 space-x-2 text-green-700 bg-green-100 rounded-lg">
                                    <CheckBadgeIcon className="self-center w-4 h-4" />{" "}
                                    <span className="self-center">
                                        Verified
                                    </span>
                                </span>
                            )}
                            {!user.email_verified_at && (
                                <span className="flex px-4 py-1 space-x-2 text-red-700 bg-red-100 rounded-lg">
                                    <ExclamationCircleIcon className="self-center w-4 h-4" />{" "}
                                    <span className="self-center">
                                        Not Verified
                                    </span>
                                </span>
                            )}
                        </dd>
                    </div>
                    <div className="px-4 py-6 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-0">
                        <dt className="text-sm font-medium leading-6 text-gray-900">
                            Phone Number
                        </dt>
                        <dd className="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">
                            {user.meta_data?.phone_number ?? "-"}
                        </dd>
                    </div>
                    <div className="px-4 py-6 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-0">
                        <dt className="text-sm font-medium leading-6 text-gray-900">
                            Nationality
                        </dt>
                        <dd className="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">
                            {user.meta_data?.nationality ?? "-"}
                        </dd>
                    </div>
                    <div className="px-4 py-6 sm:grid sm:grid-cols-2 sm:gap-4 sm:px-0 md:divide-x-2 md:text-center">
                        <div className="grid grid-cols-2 md:grid-cols-1">
                            <dt className="text-sm font-medium leading-6 text-gray-900">
                                Birthday
                            </dt>
                            <dd className="mt-0 text-sm leading-6 text-gray-700 md:mt-1 sm:col-span-2 sm:mt-0">
                                {user.meta_data?.date_of_birth ?? "-"}
                            </dd>
                        </div>
                        <div className="grid grid-cols-2 md:grid-cols-1">
                            <dt className="text-sm font-medium leading-6 text-gray-900">
                                Birth Place
                            </dt>
                            <dd className="mt-1 text-sm leading-6 text-gray-700 sm:col-span-2 sm:mt-0">
                                {user.meta_data?.place_of_birth ?? "-"}
                            </dd>
                        </div>
                    </div>
                </dl>
            </div> */}
        </div>
    );
};
