import InputError from "@/Components/InputError";
import InputLabel from "@/Components/InputLabel";
import Modal from "@/Components/Modal";
import { PrimaryButton } from "@/Components/elements/buttons/PrimaryButton";
import { SecondaryButton } from "@/Components/elements/buttons/SecondaryButton";
import SelectInput from "@/Components/elements/inputs/SelectInput";
import TextArea from "@/Components/elements/inputs/TextArea";
import { camelCaseToWords } from "@/lib/utility";
import { CheckBadgeIcon, XCircleIcon } from "@heroicons/react/20/solid";
import { useForm } from "@inertiajs/react";
import { FormEventHandler, useRef, useState, WheelEvent } from "react";
import { Document, Page, pdfjs } from "react-pdf";


pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;

export default function StepInformation({
    document,
    step,
    imageData,
    user,
}: any) {
    let title = <span>Step ({step}) Information</span>;
    switch (document.idDocType) {
        case "ID_CARD":
            title = <span>Applicant NIC Information</span>;
            break;
        case "PASSPORT":
            title = <span>Applicant Passport Information</span>;
            break;
        case "DRIVERS":
            title = <span>Applicant Driver License Information</span>;
            break;
        case "RESIDENCE_PERMIT":
            title = (
                <span>Applicant residential permit document Information</span>
            );
            break;
    }

    return (
        <div className="p-8 bg-white border rounded-lg shadow-sm">
            <div className="flex justify-between px-4 sm:px-0">
                <div>
                    <h3 className="text-base font-semibold leading-7 text-gray-900">
                        {title}{" "}
                        <small className="font-bold text-blue-600">
                            {imageData.type}
                        </small>
                    </h3>
                    <p className="max-w-2xl mt-1 text-sm leading-6 text-gray-500">
                        User submitted information for the step {step}
                    </p>
                </div>
            </div>
            <div className="grid w-full grid-cols-6 mt-6 border-t border-gray-100">
                {imageData.files && (
                    <div className="flex justify-center order-2 col-span-3 p-4 bg-gray-50">
                        {imageData.files?.length > 0 ? (
                            <div className="flex self-center space-x-2">
                                {imageData.files.map((image: any, index: any) => (
                                    <div key={index} className="object-contain h-auto border w-52 rounded-xl border-primary">
                                        {image.url.includes('pdf') ? (
                                            // <div className="overflow-auto h-96"
                                            // >
                                            //     <Document file={image.url} loading="Loading">
                                            //         <Page pageNumber={1} width={200} height={300} />
                                            //     </Document>

                                            // </div>
                                            <div className="embed-responsive" style={{ height: "25vh" }}>
                                                <embed
                                                    src={image.url}
                                                    type="application/pdf"
                                                    width="100%"
                                                    height="100%"
                                                />
                                            </div>
                                        ) : (
                                            <img
                                                src={image.url}
                                                alt={`Image ${index + 1}`}
                                                className="object-contain w-full h-full rounded-xl"
                                            />
                                        )}
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="self-center">
                                <img
                                    src="/assets/image/noImage.png?a=10"
                                    className="w-[200px] rounded-xl object-contain border border-primary"
                                    alt="No Image"
                                />
                            </div>
                        )}
                    </div>
                )}


                <dl className="order-1 col-span-3 divide-y divide-gray-100">
                    <div className="p-4">
                        {Object.keys(document).map((key: any, index: any) => {
                            const line = document[key];
                            return (
                                <div className="px-4 py-2 text-left sm:grid sm:grid-cols-11 sm:gap-4 sm:px-0">
                                    <dt className="col-span-5 text-sm font-medium leading-6 text-gray-900 capitalize">
                                        {camelCaseToWords(key)}
                                    </dt>
                                    <dt>:</dt>
                                    <dd
                                        className={` ${key == "idDocType"
                                            ? "text-blue-800 font-[700]"
                                            : "text-gray-700"
                                            } mt-1 text-sm leading-6  col-span-5 sm:mt-0`}
                                    >
                                        {line}
                                    </dd>
                                </div>
                            );
                        })}
                    </div>
                    <div className="grid grid-cols-3 pt-8 divide-x">
                        <div className="col-span-2">
                            {imageData && <StepStatus imageData={imageData} />}
                        </div>
                        <div className="flex justify-center">
                            {imageData && (
                                <StepFunctions
                                    user={user}
                                    imageData={imageData}
                                />
                            )}
                        </div>
                    </div>
                </dl>
            </div>
        </div>
    );
}

function StepStatus({ imageData }: any) {
    return (
        <div className="flex divide-x">
            <div className="w-1/2 space-y-2 text-center">
                <h6>Sum Sub Status</h6>
                <p>
                    {imageData.status == "GREEN" && (
                        <span className="px-6 py-2 text-green-700 bg-green-100 rounded-md">
                            Approved
                        </span>
                    )}
                    {imageData.status == "RED" && (
                        <span className="px-6 py-2 text-red-700 bg-red-100 rounded-md">
                            Declined
                        </span>
                    )}
                    {(imageData.status == undefined || imageData.status == null) && (
                        <span className="px-6 py-2 text-red-700 bg-red-100 rounded-md">
                            Not Started
                        </span>
                    )}
                </p>
                {imageData.moderationComment && (
                    <p>
                        <small>
                            Comments:{" "}
                            <span className="text-blue-800">
                                {imageData.moderationComment}
                            </span>
                        </small>
                    </p>
                )}
            </div>
            <div className="w-1/2 space-y-2 text-center">
                <h6>Admin's Status</h6>
                <p>
                    {imageData.admin_status == "GREEN" && (
                        <span className="px-6 py-2 text-green-700 bg-green-100 rounded-md">
                            Approved
                        </span>
                    )}
                    {imageData.admin_status == "RED" && (
                        <span className="px-6 py-2 text-red-700 bg-red-100 rounded-md">
                            Declined
                        </span>
                    )}
                    {imageData.admin_status == null && (
                        <span className="px-6 py-2 text-gray-700 bg-gray-100 rounded-md">
                            No Change
                        </span>
                    )}
                </p>
                {imageData.admin_comment && (
                    <p>
                        <small>
                            Comments:{" "}
                            <span className="text-blue-800">
                                {imageData.admin_comment}
                            </span>
                        </small>
                    </p>
                )}
            </div>
        </div>
    );
}

function StepFunctions({ imageData, user }: any) {
    const [showModal, setShowModal] = useState("");
    return (
        <>
            <span className="self-center">
                {imageData.admin_status == "GREEN" && (
                    <p className="text-center">
                        <p className="text-gray-700">Is something wrong ?</p>{" "}
                        <button
                            onClick={() => setShowModal("reject")}
                            className="text-red-500"
                        >
                            Reject
                        </button>
                    </p>
                )}
                {(imageData.admin_status == "RED" || imageData.admin_status == undefined) && (
                    <p className="text-center ">
                        <p className="text-gray-700">
                            Want to manual approve?
                        </p>{" "}
                        <button
                            className="text-green-500"
                            onClick={() => setShowModal("approve")}
                        >
                            Approve
                        </button>
                    </p>
                )}
            </span>
            {showModal != "" && (
                <ChangeStatus
                    showModal={showModal}
                    setShowModal={setShowModal}
                    imageData={imageData}
                    user={user}
                />
            )}
        </>
    );
}

function ChangeStatus({ showModal, setShowModal, imageData, user }: any) {
    const { data, setData, post, progress, errors, reset } = useForm({
        comment: "",
        step: imageData.type,
        document: imageData.document,
        status: showModal,
    });

    const submit: FormEventHandler = (e) => {
        e.preventDefault();
        post(route("users.reset", { id: user.id }), {
            onSuccess: (page) => {
                reset();
                setShowModal("");
            },
        });
    };
    return (
        <Modal
            show={showModal != "" ? true : false}
            onClose={() => { }}
            className="p-8 bg-white "
        >
            <div className="">
                <h2 className="text-lg font-medium text-gray-900">
                    <span
                        className={` ${showModal == "approve"
                            ? "text-green-800"
                            : "text-red-800"
                            }  capitalize font-[800]`}
                    >
                        {showModal}
                    </span>{" "}
                    the <span>{imageData.type}</span> Step
                </h2>
            </div>
            <p>
                You can't approve the step status in Subsub. instead of that you
                can override SumSub status in our database.
            </p>
            <form onSubmit={submit} className="w-full mt-8">
                <div className="w-[100%]">
                    <InputLabel
                        htmlFor="status"
                        value={"Please write a comment"}
                    />
                    <TextArea
                        id="comment"
                        value={data.comment}
                        rows={3}
                        required
                        onChange={(e) => setData("comment", e.target.value)}
                    />
                    <InputError message={errors.comment} />
                </div>
                <div className="mt-4 space-x-4">
                    <SecondaryButton
                        type="button"
                        onClick={() => setShowModal("")}
                    >
                        Close
                    </SecondaryButton>
                    <PrimaryButton>Submit</PrimaryButton>
                </div>
            </form>
        </Modal>
    );
}
