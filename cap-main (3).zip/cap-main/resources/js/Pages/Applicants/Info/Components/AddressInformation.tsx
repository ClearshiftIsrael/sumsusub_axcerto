export default function AddressInformation({ addresses }: any) {
    return (
        <div className="p-8 bg-white border rounded-lg shadow-sm">
            <div className="px-4 sm:px-0">
                <h3 className="text-base font-semibold leading-7 text-gray-900">
                    Applicant Address Information
                </h3>
                <p className="max-w-2xl mt-1 text-sm leading-6 text-gray-500">
                    Check all the address/es that user have.
                </p>
            </div>
            <div className="w-full mt-6 border-t border-gray-100">
                <dl className="divide-y divide-gray-100">
                    <div className="px-4 py-6 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-0 md:divide-x-2 md:text-center">
                        {addresses?.map((address: any, index: number) => (
                            <Address address={address} />
                        ))}
                    </div>
                </dl>
            </div>
        </div>
    );
}

function Address({ address }: any) {
    return (
        <div className="bg-gray-50 rounded-xl">
            <div className="px-4 py-2 text-center bg-gray-100 rounded-t-xl">
                <h6>Address 01</h6>
            </div>
            <div className="p-4">
                {Object.keys(address).map((key: any, index: any) => {
                    const line = address[key];
                    return (
                        <div className="px-4 py-2 text-left sm:grid sm:grid-cols-11 sm:gap-4 sm:px-0">
                            <dt className="col-span-5 text-sm font-medium leading-6 text-gray-900 capitalize">
                                {key}
                            </dt>
                            <dt>:</dt>
                            <dd className="col-span-5 mt-1 text-sm leading-6 text-gray-700 sm:mt-0">
                                {line}
                            </dd>
                        </div>
                    );
                })}
            </div>
        </div>
    );
}
