import Modal from "@/Components/Modal";
import { PrimaryButton } from "@/Components/elements/buttons/PrimaryButton";
import { SecondaryButton } from "@/Components/elements/buttons/SecondaryButton";
import InputError from "@/Components/elements/inputs/InputError";
import InputLabel from "@/Components/elements/inputs/InputLabel";
import TextArea from "@/Components/elements/inputs/TextArea";
import { useForm } from "@inertiajs/react";
import { FormEventHandler, useState } from "react";

export default function KycStatus({ user }: any) {
    console.log(user?.kyc_info?.admin_status);
    return (
        <div className="p-8 bg-white border rounded-lg shadow-smx">
            <div className="px-4 sm:px-0">
                <h3 className="text-base font-semibold leading-7 text-gray-900">
                    Overall Status
                </h3>
            </div>
            <hr className="my-4" />
            <div className="grid grid-cols-4 divide-x ">
                <div className="col-span-2">
                    <StepStatus kycInfo={user?.kyc_info} />
                </div>
            </div>
        </div>
    );
}

function StepStatus({ kycInfo }: any) {
    return (
        <div className="flex divide-x">
            <div className="w-1/2 space-y-2 text-center">
                <h6>Sum Sub Status</h6>
                <p>
                    {(kycInfo?.status == "notStarted" || kycInfo?.status == undefined) && (
                        <span className="px-6 py-2 text-yellow-700 bg-yellow-100 rounded-md">
                            Not Started
                        </span>
                    )}
                    {kycInfo?.status == "notCompleted" && (
                        <span className="px-6 py-2 text-yellow-700 bg-yellow-100 rounded-md">
                            Not Completed
                        </span>
                    )}
                    {kycInfo?.status == "pending" && (
                        <span className="px-6 py-2 text-yellow-700 bg-yellow-100 rounded-md">
                            Pending
                        </span>
                    )}
                    {kycInfo?.status == "success" && (
                        <span className="px-6 py-2 text-green-700 bg-green-100 rounded-md">
                            Success
                        </span>
                    )}
                    {kycInfo?.status == "declined" && (
                        <span className="px-6 py-2 text-red-700 bg-red-100 rounded-md">
                            Declined
                        </span>
                    )}
                </p>
                {kycInfo?.moderationComment && (
                    <p>
                        <small>
                            Comments:{" "}
                            <span className="text-blue-800">
                                {kycInfo?.moderationComment}
                            </span>
                        </small>
                    </p>
                )}
            </div>
            <div className="w-1/2 space-y-2 text-center">
                <h6>Admin Status</h6>
                <p>
                    {kycInfo?.admin_status == "pending" && (
                        <span className="px-6 py-2 text-yellow-700 bg-yellow-100 rounded-md">
                            Pending
                        </span>
                    )}
                    {kycInfo?.admin_status == "inprogress" && (
                        <span className="px-6 py-2 text-yellow-700 bg-yellow-100 rounded-md">
                            Inprogress
                        </span>
                    )}
                    {kycInfo?.admin_status == "approved" && (
                        <span className="px-6 py-2 text-green-700 bg-green-100 rounded-md">
                            Success
                        </span>
                    )}
                    {kycInfo?.admin_status == "rejected" && (
                        <span className="px-6 py-2 text-red-700 bg-red-100 rounded-md">
                            Declined
                        </span>
                    )}
                    {kycInfo?.admin_status == undefined && (
                        <span className="px-6 py-2 text-yellow-700 bg-red-100 rounded-md">
                            Not Started
                        </span>
                    )}
                </p>
                {kycInfo?.adminComment && (
                    <p>
                        <small>
                            Comments:{" "}
                            <span className="text-blue-800">
                                {kycInfo?.adminComment}
                            </span>
                        </small>
                    </p>
                )}
            </div>
            <StepFunctions
                kyc={ kycInfo }
            />
        </div>
    );
}

function StepFunctions({ kyc }: any) {
    const [showModal, setShowModal] = useState("");
    return (
        <>
            <span className="self-center">
                {kyc.admin_status == "approved" && (
                    <p className="text-center">
                        <p className="text-gray-700">Is something wrong ?</p>{" "}
                        <button
                            onClick={() => setShowModal("reject")}
                            className="text-red-500"
                        >
                            Reject
                        </button>
                    </p>
                )}
                {['rejected', 'pending', 'inprogress'].includes(kyc.admin_status) && (
                    <p className="text-center ">
                        <p className="text-gray-700">
                            Want to manual approve?
                        </p>{" "}
                        <button
                            className="text-green-500"
                            onClick={() => setShowModal("approve")}
                        >
                            Approve
                        </button>
                    </p>
                )}
            </span>
            {showModal != "" && (
                <ChangeStatus
                    showModal={showModal}
                    setShowModal={setShowModal}
                    kyc={kyc}
                />
            )}
        </>
    );
}


function ChangeStatus({ showModal, setShowModal, kyc }: any) {
    const { data, setData, post, progress, errors, reset } = useForm({
        comment: "",
        admin_status: showModal,
    });

    const submit: FormEventHandler = (e) => {
        e.preventDefault();
        post(route("users.status.change", { id: kyc.user_id }), {
            onSuccess: (page) => {
                reset();
                setShowModal("");
            },
        });
    };
    return (
        <Modal
            show={showModal != "" ? true : false}
            onClose={() => { }}
            className="p-8 bg-white "
        >
            <div className="">
                <h2 className="text-lg font-medium text-gray-900">
                    <span
                        className={` ${showModal == "approve"
                            ? "text-green-800"
                            : "text-red-800"
                            }  capitalize font-[800]`}
                    >
                        {showModal}
                    </span>{" "}
                    the <span>Overall Status</span>
                </h2>
            </div>
            <p>
                You can't approve the step status in Subsub. instead of that you
                can override SumSub status in our database.
            </p>
            <form onSubmit={submit} className="w-full mt-8">
                <div className="w-[100%]">
                    <InputLabel
                        htmlFor="status"
                        value={"Please write a comment"}
                    />
                    <TextArea
                        id="comment"
                        value={data.comment}
                        rows={3}
                        required
                        onChange={(e) => setData("comment", e.target.value)}
                    />
                    <InputError message={errors.comment} />
                </div>
                <div className="mt-4 space-x-4">
                    <SecondaryButton
                        type="button"
                        onClick={() => setShowModal("")}
                    >
                        Close
                    </SecondaryButton>
                    <PrimaryButton>Submit</PrimaryButton>
                </div>
            </form>
        </Modal>
    );
}

