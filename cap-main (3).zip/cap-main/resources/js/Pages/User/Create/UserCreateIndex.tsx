import { PrimaryButton } from "@/Components/elements/buttons/PrimaryButton";
import InputError from "@/Components/elements/inputs/InputError";
import InputLabel from "@/Components/elements/inputs/InputLabel";
import SelectInput from "@/Components/elements/inputs/SelectInput";
import TextArea from "@/Components/elements/inputs/TextArea";
import TextInput from "@/Components/elements/inputs/TextInput";
import Authenticated from "@/Layouts/AuthenticatedLayout";
import { Transition } from "@headlessui/react";
import { Head, useForm } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { useEffect, useState } from "react";

export default function UserCreateIndex() {
    const status = [{
        label: 'Active',
        value: 'active'
    }, {
        label: 'Inactive',
        value: 'inactive'
    }]
    console.log(status);
    const { t } = useLaravelReactI18n();
    const bRoutes = [
        {
            name: "breadcrumbs.dashboard",
            hasArrow: true,
            link: route("dashboard"),
        },
        {
            name: "breadcrumbs.users",
            hasArrow: true,
            link: route("users.index"),
        },
        {
            name: "Create",
            hasArrow: true,
            // link: route("users.index"),
        },
    ];


    const { data, setData, post, processing, errors, recentlySuccessful } =
        useForm({
            first_name: "",
            last_name: "",
            email: "",
            kyc_level_id: "",
            business: "",
            status: status[0]['value']
        });

    function submit(e: any) {
        e.preventDefault();
        post(route("users.store"));
    }

    return (
        <Authenticated bRoutes={bRoutes}>
            <Head title={t("users.all.title")} />
            <div className="md:flex md:items-center md:justify-between">
                <div className="flex-1 min-w-0">
                    <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:truncate sm:text-3xl sm:tracking-tight">
                        {t("users.all.title")}
                    </h2>
                </div>
            </div>

            {/* ----------------- */}
            <div className="grid w-full grid-cols-1 p-10 text-left">
                <form
                    onSubmit={submit}
                    className="col-span-4 space-y-8 divide-y divide-gray-200 xl:col-span-3 "
                >
                    <div className="grid grid-cols-3 gap-4 divide-gray-200">
                        <div className="col-span-3 bg-white border rounded-md shadow">
                            <div className="p-5 pt-4 bg-white rounded-md">
                                <div className="flex items-center mb-4 space-x-2 text-lg font-medium leading-8 text-gray-900">
                                    <span className="text-primary">
                                        <svg
                                            className="w-5 h-5"
                                            xmlns="http://www.w3.org/2000/svg"
                                            fill="none"
                                            viewBox="0 0 24 24"
                                            strokeWidth="2"
                                            stroke="currentColor"
                                        >
                                            <path
                                                strokeLinecap="round"
                                                strokeLinejoin="round"
                                                d="M15 9h3.75M15 12h3.75M15 15h3.75M4.5 19.5h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5zm6-10.125a1.875 1.875 0 11-3.75 0 1.875 1.875 0 013.75 0zm1.294 6.336a6.721 6.721 0 01-3.17.789 6.721 6.721 0 01-3.168-.789 3.376 3.376 0 016.338 0z"
                                            />
                                        </svg>
                                    </span>
                                    <span className="tracking-wide">
                                        {t("user.card.in.title")}
                                    </span>
                                    <div className="flex items-center justify-end flex-1">
                                        <PrimaryButton
                                            className="pb-2 ml-auto"
                                            type="submit"
                                        >
                                            {t(
                                                "user.create&edit.card.save&submit"
                                            )}
                                        </PrimaryButton>
                                    </div>
                                </div>
                                <div className="grid grid-cols-1 mt-6 gap-y-6 gap-x-4 sm:grid-cols-6">
                                    <div className="sm:col-span-3">
                                        <InputLabel
                                            htmlFor="name"
                                            value={t(
                                                "user.create&edit.card.first_name"
                                            )}
                                            required={true}
                                        />
                                        <TextInput
                                            // disabled
                                            type="text"
                                            name="first_name"
                                            id="first_name"
                                            value={data.first_name}
                                            placeholder="Enter First Name"
                                            className="block w-full mt-1.5 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                                            isFocused={true}
                                            onChange={(e) =>
                                                setData(
                                                    "first_name",
                                                    e.target.value
                                                )
                                            }
                                        />
                                    </div>
                                    <div className="sm:col-span-2">
                                        <InputLabel
                                            htmlFor="email"
                                            value={t(
                                                "user.create&edit.card.email"
                                            )}
                                            required={true}
                                        />

                                        <TextInput
                                            // disabled
                                            type="email"
                                            name="email"
                                            id="email"
                                            value={data.email}
                                            placeholder="Enter Email"
                                            className="block w-full mt-1.5 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                                            onChange={(e) =>
                                                setData(
                                                    "email",
                                                    e.target.value
                                                )
                                            }
                                        />

                                        <InputError
                                            message={errors.email}
                                            className="mt-2"
                                        />
                                    </div>
                                    <div>
                                        <InputLabel
                                            htmlFor="status"
                                            value='Status'
                                        // required={true}
                                        />
                                        <SelectInput
                                            className="border-gray-300 mt-1.5 focus:border-primary focus:ring-0.5 focus:ring-primary rounded-md shadow-sm w-full "
                                            options={status}
                                            selectedOption={status.filter(
                                                (obj: any) => {
                                                    return (
                                                        obj.value ===
                                                        data.status
                                                    );
                                                }
                                            )}
                                            setData={(e: any) =>
                                                setData("status", e)
                                            }

                                        />

                                        <InputError
                                            message={errors?.status}
                                            className="mt-2"
                                        />
                                    </div>
                                </div>
                                <div className="grid grid-cols-1 mt-6 gap-y-6 gap-x-4 sm:grid-cols-2">
                                    <div className="sm:col-span-1">

                                        <div className="sm:col-span-3">
                                            <InputLabel
                                                htmlFor="last_name"
                                                value={t(
                                                    "user.create&edit.card.last_name"
                                                )}
                                                required={true}
                                            />
                                            <TextInput
                                                // disabled
                                                type="text"
                                                name="last_name"
                                                id="last_name"
                                                value={data.last_name}
                                                placeholder="Enter Last Name"
                                                className="block w-full mt-1.5 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                                                onChange={(e) =>
                                                    setData(
                                                        "last_name",
                                                        e.target.value
                                                    )
                                                }
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </Authenticated>
    );
}
