import { PageProps } from "@/types";
import { Head, Link, router, usePage } from "@inertiajs/react";
import MasterTable, {
    TableBody,
    TableTd,
} from "@/Components/elements/tables/masterTable";
import {
    PrimaryButton,
    PrimaryLink,
} from "@/Components/elements/buttons/PrimaryButton";
import { EyeIcon, PencilIcon } from "@heroicons/react/20/solid";
import ConfirmButton from "@/Components/elements/buttons/ConfirmButton";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { useEffect, useState } from "react";
import {
    SecondaryButton,
    SecondaryLink,
} from "@/Components/elements/buttons/SecondaryButton";
import CopyToClipboard from "react-copy-to-clipboard";
import {
    ClipboardDocumentCheckIcon,
    ClipboardDocumentIcon,
} from "@heroicons/react/24/outline";

export default function UserIndex({
    users,
    filters,
    dfKycLevel,
    dfKybLevel,
}: {
    users: any;
    filters: any;
    dfKycLevel: any;
    dfKybLevel: any;
}) {
    console.log(users.data);
    const { t } = useLaravelReactI18n();
    const bRoutes = [
        {
            name: "breadcrumbs.dashboard",
            hasArrow: true,
            link: route("admin.dashboard"),
        },
        {
            name: "breadcrumbs.users",
            hasArrow: true,
            link: route("users.index"),
        },
    ];

    const tableColumns = [
        {
            label: "",
            sortField: "",
            sortable: false,
        },
        {
            label: t("users.all.table.user"),
            sortField: "name",
            sortable: true,
        },
        {
            label: t("users.all.table.email"),
            sortField: "email",
            sortable: true,
        },
        {
            label: "Accounts",
            sortField: "id",
            sortable: false,
        },
        {
            label: "Create/Delete At",
            sortField: "created_at",
            sortable: true,
        },
    ];

    const createLink = {
        url: route("users.create"),
        label: t("users.all.buttons.create"),
    };
    const search = {
        placeholder: t("users.all.search"),
    };

    const [isTooltipVisible, setIsTooltipVisible] = useState(false);
    const [isCopySuccess, setIsCopySuccess] = useState(false);

    useEffect(() => {
        const handleClickOutside = () => {
            setIsCopySuccess(false);
        };
        window.addEventListener("click", handleClickOutside);
        return () => {
            window.removeEventListener("click", handleClickOutside);
        };
    }, []);
    const [copyStates, setCopyStates] = useState<Record<number, boolean>>({});

    const handleCopyClick = (index: number) => {
        // Toggle the state for the clicked button at the specified index
        setCopyStates((prevCopyStates) => ({
            ...prevCopyStates,
            [index]: !prevCopyStates[index],
        }));

        // Set a timeout to reset the state back to its original value after 10 seconds
        setTimeout(() => {
            setCopyStates((prevCopyStates) => ({
                ...prevCopyStates,
                [index]: false,
            }));
        }, 1000); // 10 seconds in milliseconds
    };

    const { type } = usePage().props;
    const [activeTab, setActiveTab] = useState(filters.type ?? "all");

    const changeTab = (tab: string) => {
        setActiveTab(tab);
        filters.type = tab;
        router.get(
            route("users.index"),
            {
                type: filters["type"],
            },
            {
                replace: true,
                preserveState: true,
            }
        );
    };

    return (
        <AuthenticatedLayout bRoutes={bRoutes}>
            <Head title={t("users.all.title")} />
            <div className="md:flex md:items-center md:justify-between">
                <div className="flex-1 min-w-0">
                    <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:truncate sm:text-3xl sm:tracking-tight">
                        {t("users.all.title")}
                    </h2>
                </div>
            </div>

            <div>
                {/* Table */}
                <MasterTable
                    tableColumns={tableColumns}
                    filters={filters}
                    url={route("users.index")}
                    createLink={createLink}
                    search={search}
                    links={users?.meta?.links}
                >
                    {users?.data?.map((user: any, index: number) => (
                        <TableBody
                            buttons={
                                <>
                                    <PrimaryLink
                                        className="!py-2 "
                                        href={route("users.edit", {
                                            id: user.id,
                                        })}
                                    >
                                        <PencilIcon className="w-3 h-3 mr-2" />{" "}
                                        {t("users.all.table.edit")}
                                    </PrimaryLink>
                                    {user.deleted_at == null ? (
                                        <ConfirmButton
                                            className="!py-2"
                                            url={route("users.destroy", {
                                                id: user.id,
                                            })}
                                            label={t("table.all.delete")}
                                        />
                                    ) : (
                                        <ConfirmButton
                                            className="!py-2"
                                            url={route(
                                                "users.permanent.delete",
                                                {
                                                    id: user.id,
                                                }
                                            )}
                                            label={"Permanent delete"}
                                        />
                                    )}
                                </>
                            }
                            key={user.id}
                        >
                            <TableTd>
                                <div className="flex">
                                    <Link
                                        href={route("users.edit", {
                                            id: user.id,
                                        })}
                                        className="self-center text-blue-600 font-[700]"
                                    >
                                        {user?.name}
                                    </Link>
                                </div>
                            </TableTd>
                            <TableTd>{user.email}</TableTd>
                            <TableTd>
                                {user?.accounts_count > 0
                                    ? user?.accounts_count
                                    : "-"}
                            </TableTd>
                            <TableTd>
                                {user.deleted_at == null ? (
                                    <p>{user.created_at_human}</p>
                                ) : (
                                    <p>{user?.deleted_at_human}</p>
                                )}
                            </TableTd>
                        </TableBody>
                    ))}
                </MasterTable>
            </div>
        </AuthenticatedLayout>
    );
}
