import { PrimaryButton } from "@/Components/elements/buttons/PrimaryButton";
import Checkbox from "@/Components/elements/inputs/Checkbox";
import { User } from "@/types";
import { LockOpenIcon, LockClosedIcon } from "@heroicons/react/24/outline";
import { useForm } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { FormEventHandler } from "react";

export default function TwoFa({ user }: { user: User }) {
    const { t } = useLaravelReactI18n();
    const { data, setData, patch, errors, processing, recentlySuccessful } =
        useForm({
            twofa_enabled_at: user.twofa_enabled_at ? "true" : "false",
        });

    const submit: FormEventHandler = (e) => {
        e.preventDefault();

        patch(route("profile.update.twofa"), {
            preserveState: true,
            preserveScroll: true,
        });
    };

    return (
        <form onSubmit={submit} className="bg-white rounded-xl shadow">
            <div className=" p-4">
                <h6 className="text-xl font-[800] leading-8 text-gray-700 flex">
                    <LockClosedIcon className="w-5 h-5 self-center" />
                    <span className="tracking-wide pl-4">
                        {t("profile.2fa.title")}
                    </span>
                </h6>
                <p className="text-gray-600 font-[400]">
                    Enable email two factor authentication to protect your
                    information.
                </p>
            </div>
            {/* settings */}
            <div className="p-4">
                <div className="grid grid-cols-2 gap-4">
                    {/* first name */}
                    <label className="flex items-center">
                        <Checkbox
                            name="remember"
                            checked={
                                data.twofa_enabled_at == "true" ? true : false
                            }
                            onChange={(e) =>
                                setData(
                                    "twofa_enabled_at",
                                    e.target.checked == true ? "true" : "false"
                                )
                            }
                        />
                        <span className="ml-2 text-sm text-gray-600">
                            {t("profile.2fa.label")}
                        </span>
                    </label>
                </div>
            </div>
            <div className="bg-gray-50 p-3 rounded-b-xl flex">
                <PrimaryButton className="ml-auto" type="submit">
                    {t("profile.2fa.button.enable")}
                </PrimaryButton>
            </div>
        </form>
    );
}
