import { PrimaryButton } from "@/Components/elements/buttons/PrimaryButton";
import InputError from "@/Components/elements/inputs/InputError";
import InputLabel from "@/Components/elements/inputs/InputLabel";
import TextInput from "@/Components/elements/inputs/TextInput";
import { EyeSlashIcon, LockClosedIcon } from "@heroicons/react/24/outline";
import { EyeIcon } from "@heroicons/react/24/solid";
import { router, useForm } from "@inertiajs/react";
import { FormEventHandler, useState } from "react";
import { useLaravelReactI18n } from "laravel-react-i18n";

export default function DeleteAccount({ user }: any) {
    const { t } = useLaravelReactI18n();
    const { data, setData, post, errors, processing, recentlySuccessful } =
        useForm({
            password: "",
            password_confirmation: "",
        });

    const [password, setPassword] = useState("");
    const [passwordShown, setPasswordShown] = useState(true);
    const [confirmed_password, setPasswordConfirm] = useState("");
    const [passwordConfirmShown, setPasswordConfirmShown] = useState(true);

    // visibility on password
    const togglePassword = () => {
        setPasswordShown(!passwordShown);
    };
    // visibility on password confirm
    const togglePasswordConfirm = () => {
        setPasswordConfirmShown(!passwordConfirmShown);
    };
    const submit: FormEventHandler = (e) => {
        e.preventDefault();
        post(route("profile.delete"));
    };
    // const delete = () => {
    //     router.delete('profile.destroy')
    // }
    return (
        <form onSubmit={submit}>
            <div className="bg-white rounded-xl shadow">
                <div className=" p-4">
                    <h6 className="text-xl font-[800] leading-8 text-gray-700 flex">
                        <LockClosedIcon className="w-5 h-5 self-center" />
                        <span className="tracking-wide pl-4">
                            {t("profile.delete.title")}
                        </span>
                    </h6>
                    <p className="text-gray-600 font-[400]">
                        Do you want to delete your account.
                    </p>
                </div>
                <div className="p-4">
                    <div className="sm:col-span-3">
                        <InputLabel
                            htmlFor="password"
                            value={t("profile.delete.password")}
                            required={true}
                        />
                        <div className="relative mt-1">
                            <TextInput
                                type={passwordShown ? "text" : "password"}
                                name="password"
                                id="password"
                                value={data.password}
                                onChange={(e) =>
                                    setData("password", e.target.value)
                                }
                                autoComplete="off"
                                placeholder="Enter Password"
                                className="block w-full mt-1.5 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                            />
                            <div className="absolute flex items-center justify-center p-1 rounded-md top-1 right-1">
                                {passwordShown ? (
                                    <button
                                        type="button"
                                        onClick={togglePassword}
                                    >
                                        <EyeSlashIcon className="w-5 h-5 fill-white" />
                                    </button>
                                ) : (
                                    <button
                                        type="button"
                                        onClick={togglePassword}
                                    >
                                        <EyeIcon className="w-5 h-5 fill-white" />
                                    </button>
                                )}
                            </div>
                        </div>

                        <InputError
                            message={errors?.password}
                            className="mt-2"
                        />
                    </div>
                    {/* <div className="sm:col-span-3">
                                            <InputLabel
                                                htmlFor="confirmed_password"
                                                value="Confirm Password"
                                                required={true}
                                            />
                                            <div className="relative mt-1">
                                                <TextInput
                                                    type={
                                                        passwordConfirmShown
                                                            ? "text"
                                                            : "password"
                                                    }
                                                    name="password_confirmation"
                                                    id="password_confirmation"
                                                    value={
                                                        data.password_confirmation
                                                    }

                                                    onChange={(e) =>
                                                        setData(
                                                            "password_confirmation",
                                                            e.target.value
                                                        )
                                                    }
                                                    autoComplete="off"
                                                    placeholder="Enter Confirm Password"
                                                    className="block w-full mt-1.5 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                                                />
                                                <div className="absolute flex items-center justify-center p-1 rounded-md top-1 right-1">
                                                    {passwordConfirmShown ? (
                                                        <button
                                                            type="button"
                                                            onClick={
                                                                togglePasswordConfirm
                                                            }
                                                        >
                                                            <EyeIcon className="w-5 h-5 fill-white" />
                                                        </button>
                                                    ) : (
                                                        <button
                                                            type="button"
                                                            onClick={
                                                                togglePasswordConfirm
                                                            }
                                                        >
                                                            <EyeIcon className="w-5 h-5 fill-white" />
                                                        </button>
                                                    )}
                                                </div>
                                            </div>

                                            <InputError
                                                message={
                                                    errors?.password_confirmation
                                                }
                                                className="mt-2"
                                            />
                                        </div> */}
                </div>
                <div className="bg-gray-50 p-3 rounded-b-xl flex justify-end space-x-4">
                    <PrimaryButton className=" bg-red-700" type="submit">
                        {t("profile.delete-buttons")}
                    </PrimaryButton>
                </div>
            </div>
        </form>
    );
}
