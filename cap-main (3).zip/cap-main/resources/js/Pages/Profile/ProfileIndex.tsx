import { PrimaryButton } from "@/Components/elements/buttons/PrimaryButton";
import { SecondaryLink } from "@/Components/elements/buttons/SecondaryButton";
import InputError from "@/Components/elements/inputs/InputError";
import InputLabel from "@/Components/elements/inputs/InputLabel";
import SelectInput from "@/Components/elements/inputs/SelectInput";
import TextArea from "@/Components/elements/inputs/TextArea";
import TextInput from "@/Components/elements/inputs/TextInput";
import Authenticated from "@/Layouts/AuthenticatedLayout";
import PublicAuthenticated from "@/Layouts/PublicAuthenticatedLayout";
import { Head, Link, useForm, usePage } from "@inertiajs/react";
import { FormEventHandler } from "react";
import { PageProps, User } from "@/types";
import PrivacyInfo from "./Partials/PrivacyInfo";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { TrashIcon, UserCircleIcon } from "@heroicons/react/24/outline";
import DeleteAccount from "./Partials/DeleteAccount";
import TwoFa from "./Partials/TwoFa";
import { ArrowLeftCircleIcon, LockClosedIcon } from "@heroicons/react/20/solid";

export default function ProfileIndex() {
    const { t } = useLaravelReactI18n();
    const { auth } = usePage<PageProps>().props;
    const user = auth.user;
    const bRoutes = [
        {
            name: t("profile.title"),
            hasArrow: true,
            // link: route("dashboard"),
        },
    ];
    return (
        <PublicAuthenticated>
            <div className="space-y-12">
                <Profile user={user} />
                {user?.provider == "basic" && <PrivacyInfo user={user} />}
                {user?.provider == "basic" && <TwoFa user={user} />}
                <DeleteAccount user={user} />
            </div>
        </PublicAuthenticated>
    );
}

function Profile({ user }: any) {
    const { t } = useLaravelReactI18n();
    const { data, setData, patch, errors, processing, recentlySuccessful } =
        useForm({
            first_name: user?.first_name,
            last_name: user?.last_name,
            email: user?.email,
            privacy: "false",
        });

    const submit: FormEventHandler = (e) => {
        e.preventDefault();
        patch(
            route("profile.update", {
                profile: user.id,
            })
        );
    };
    const openModal = () => {};
    return (
        <>
            <Head title={"Profile"} />
            <div className="md:flex md:items-center md:justify-between">
                <div className="flex justify-between w-full min-w-0">
                    <div>
                        <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:truncate sm:text-3xl sm:tracking-tight">
                            {t("profile.title")}
                        </h2>
                        <p>Update your profile information here.</p>
                    </div>
                </div>
            </div>
            <div className="mt-8">
                {user && (
                    <form onSubmit={submit} className="">
                        <div className="bg-white shadow rounded-xl">
                            <div className="p-4 ">
                                <h6 className="text-xl font-[800] leading-8 text-gray-700 flex">
                                    <UserCircleIcon className="self-center w-5 h-5" />
                                    <span className="pl-4 tracking-wide">
                                        {t("profile.basic-info.title")}
                                    </span>
                                </h6>
                                <p className="text-gray-600 font-[400]">
                                    Update your basic information here.
                                </p>
                            </div>
                            <div className="grid grid-cols-1 p-5 mt-6 gap-y-6 gap-x-4 sm:grid-cols-6">
                                <div className="sm:col-span-3">
                                    <InputLabel
                                        htmlFor="name"
                                        value={t(
                                            "profile.basic-info.first-name"
                                        )}
                                        required={true}
                                    />
                                    <TextInput
                                        type="text"
                                        name="name"
                                        id="name"
                                        value={data.first_name}
                                        placeholder="Enter First Name"
                                        className="block w-full mt-1.5 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                                        isFocused={true}
                                        onChange={(e) =>
                                            setData(
                                                "first_name",
                                                e.target.value
                                            )
                                        }
                                    />

                                    <InputError
                                        message={errors?.first_name}
                                        className="mt-2"
                                    />
                                </div>
                                <div className="sm:col-span-3">
                                    <InputLabel
                                        htmlFor="last_name"
                                        value={t(
                                            "profile.basic-info.last-name"
                                        )}
                                        required={true}
                                    />
                                    <TextInput
                                        type="text"
                                        name="last_name"
                                        id="last_name"
                                        value={data.last_name}
                                        placeholder="Enter Last Name"
                                        className="block w-full mt-1.5 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                                        onChange={(e) =>
                                            setData("last_name", e.target.value)
                                        }
                                    />

                                    <InputError
                                        message={errors?.last_name}
                                        className="mt-2"
                                    />
                                </div>
                            </div>
                            {user?.provider == 'basic' && <div className="p-5 sm:col-span-3">
                                <InputLabel
                                    htmlFor="email"
                                    value={t("profile.basic-info.email")}
                                    required={true}
                                />
                                <TextInput
                                    type="email"
                                    name="email"
                                    id="email"
                                    value={data.email}
                                    placeholder="Enter Email"
                                    className="block w-full mt-1.5 rounded-md border-gray-300 shadow-sm focus:border-primary focus:ring-primary sm:text-sm"
                                    onChange={(e) =>
                                        setData("email", e.target.value)
                                    }
                                />

                                <InputError
                                    message={errors?.email}
                                    className="mt-2"
                                />
                            </div>}
                            <div className="flex p-3 bg-gray-50 rounded-b-xl">
                                <PrimaryButton
                                    className="ml-auto"
                                    type="submit"
                                >
                                    {t("profile.submit-buttons")}
                                </PrimaryButton>
                            </div>
                        </div>
                    </form>
                )}
            </div>
        </>
    );
}
