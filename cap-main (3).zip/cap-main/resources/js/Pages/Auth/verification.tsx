import InputError from "@/Components/InputError";
import InputLabel from "@/Components/InputLabel";
import PrimaryButton from "@/Components/PrimaryButton";
import TextInput from "@/Components/TextInput";
import GuestLayout from "@/Layouts/GuestLayout";
import { Head, Link, router, useForm } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { FormEventHandler, useEffect } from "react";
import { useCookies } from "react-cookie";

export default function Verification({ status }: { status?: string }) {
    const { t } = useLaravelReactI18n();
    const [cookies, setCookie, removeCookie] = useCookies(["asp2quora"]);

    const { data, setData, post, processing, errors, reset } = useForm({
        twofa_code: null,
    });

    useEffect(() => {
        setTimeout(function () {
            if (!cookies["asp2quora"]) {
                router.get(route("login"));
            }
        }, 5000);
    }, []);

    const submit: FormEventHandler = (e) => {
        e.preventDefault();

        post(route("validate2fa"));
    };

    return (
        <GuestLayout>
            <Head title={t("login.title")} />

            <h1 className="font-[700] text-4xl">{t("gg.2fa.title")}</h1>
            <p className="">{t("gg.2fa.subTitle")}</p>
            <div className="w-full px-6 py-4 mt-3 overflow-hidden bg-white shadow-md sm:max-w-xl sm:rounded-lg">
                {status && (
                    <div className="mb-4 font-medium text-sm text-green-600">
                        {status}
                    </div>
                )}
                <form onSubmit={submit} className="mt-8">
                    <div className="mx-auto">
                        <InputLabel
                            htmlFor="email"
                            value={t("gg.2fa.input.code.label")}
                        />
                        <TextInput
                            type="text"
                            onChange={(e: any) =>
                                setData("twofa_code", e.target.value)
                            }
                            className="w-full rounded-md font-[800] border border-gray-300 text-center text-3xl tracking-[4px]  shadow-sm "
                        />
                        <InputError
                            message={errors.twofa_code}
                            className="mt-2"
                        />
                    </div>

                    <div className="flex items-center justify-end mt-4">
                        <PrimaryButton className="ml-4" disabled={processing}>
                            {t("gg.2fa.button")}
                        </PrimaryButton>
                    </div>
                    <div className="flex items-center mt-4">
                        <Link
                            href={route("login")}
                            className="underline text-sm text-gray-600 hover:text-gray-900 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        >
                            {t("gg.2fa.msg")}
                        </Link>
                    </div>
                </form>
            </div>
        </GuestLayout>
    );
}
