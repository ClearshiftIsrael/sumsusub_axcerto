import { useEffect, FormEventHandler, useState } from "react";
import GuestLayout from "@/Layouts/GuestLayout";
import InputError from "@/Components/InputError";
import InputLabel from "@/Components/InputLabel";
import PrimaryButton from "@/Components/PrimaryButton";
import TextInput from "@/Components/TextInput";
import { Head, Link, useForm } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";

export default function Invitation({ user,code }:any) {
    const { t } = useLaravelReactI18n();
    const { data, setData, post, processing, errors, reset } = useForm({
        first_name: "",
        last_name: "",
        password: "",
        password_confirmation: "",
    });
    useEffect(() => {
        return () => {
            reset("password", "password_confirmation");
        };
    }, []);

    const submit: FormEventHandler = (e) => {
        e.preventDefault();

        post(route("invitation.update", { code: code }));
    };

    return (
        <GuestLayout>
            <Head title="Invitation" />

            <div className="w-full px-6 py-6 mt-3 overflow-hidden bg-white shadow-md sm:max-w-md sm:rounded-xl">
                <div className="text-center">
                    <h1 className="font-[700] text-primary text-5xl">
                        Onboarding
                    </h1>
                    <p className="mt-2 font-[500]">
                        Complete your onboarding here.
                    </p>
                </div>
                <form onSubmit={submit} className="mt-8 grid grid-cols-2 gap-4">
                    <div>
                        <InputLabel
                            htmlFor="first_name"
                            value={t("onboardin.s1.form.first_name.label")}
                        />

                        <TextInput
                            id="first_name"
                            type="text"
                            name="first_name"
                            value={data.first_name}
                            className="block w-full mt-1"
                            autoComplete="given name"
                            isFocused={true}
                            onChange={(e) =>
                                setData("first_name", e.target.value)
                            }
                        />

                        <InputError
                            message={errors.first_name}
                            className="mt-2"
                        />
                    </div>
                    <div>
                        <InputLabel
                            htmlFor="last_name"
                            value={t("onboardin.s1.form.last_name.label")}
                        />

                        <TextInput
                            id="last_name"
                            type="text"
                            name="last_name"
                            value={data.last_name}
                            className="block w-full mt-1"
                            isFocused={true}
                            onChange={(e) =>
                                setData("last_name", e.target.value)
                            }
                        />

                        <InputError
                            message={errors.last_name}
                            className="mt-2"
                        />
                    </div>
                    <div className="col-span-2">
                        <InputLabel htmlFor="email" value={t("gg.email")} />

                        <TextInput
                            id="email"
                            type="email"
                            value={user.email}
                            disabled={true}
                            className="block w-full mt-1 readonly bg-gray-100"
                        />
                    </div>
                    <div className="col-span-2">
                        <InputLabel
                            htmlFor="password"
                            value={t("gg.password")}
                        />

                        <TextInput
                            id="password"
                            type="password"
                            name="password"
                            value={data.password}
                            className="block w-full mt-1"
                            autoComplete="new-password"
                            onChange={(e) =>
                                setData("password", e.target.value)
                            }
                            required
                        />

                        <InputError
                            message={errors.password}
                            className="mt-2"
                        />
                    </div>
                    <div className="col-span-2">
                        <InputLabel
                            htmlFor="password_confirmation"
                            value={t("gg.confirm-password")}
                        />

                        <TextInput
                            id="password_confirmation"
                            type="password"
                            name="password_confirmation"
                            value={data.password_confirmation}
                            className="block w-full mt-1"
                            autoComplete="new-password"
                            onChange={(e) =>
                                setData("password_confirmation", e.target.value)
                            }
                            required
                        />

                        <InputError
                            message={errors.password_confirmation}
                            className="mt-2"
                        />
                    </div>
                    <div className="col-span-2 flex items-center justify-end mt-4">
                        <PrimaryButton className="ml-4" disabled={processing}>
                            {t("Submit & Next")}
                        </PrimaryButton>
                    </div>
                </form>
            </div>
        </GuestLayout>
    );
}
