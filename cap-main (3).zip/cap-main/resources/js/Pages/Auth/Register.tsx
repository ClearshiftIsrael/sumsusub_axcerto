import InputError from "@/Components/InputError";
import InputLabel from "@/Components/InputLabel";
import PrimaryButton from "@/Components/PrimaryButton";
import TextInput from "@/Components/TextInput";
import GuestLayout from "@/Layouts/GuestLayout";
import { Head, Link, useForm } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { FormEventHandler, useEffect } from "react";

export default function Register() {
    const { t } = useLaravelReactI18n();
    const { data, setData, post, processing, errors, reset } = useForm({
        first_name: "",
        last_name: "",
        email: "",
        password: "",
        password_confirmation: "",
    });
    useEffect(() => {
        return () => {
            reset("password", "password_confirmation");
        };
    }, []);

    const submit: FormEventHandler = (e) => {
        e.preventDefault();

        post(route("register"));
    };

    return (
        <GuestLayout>
            <Head title="Register" />

            <div className="w-full px-6 py-6 mt-3 overflow-hidden bg-white shadow-md sm:max-w-md sm:rounded-xl">
                <div className="text-center">
                    <h1 className="font-[700] text-primary text-5xl">
                        {t("gg.register.title")}
                    </h1>
                    <p className="mt-2 font-[500]">
                        {t("gg.register.subtitle")}
                    </p>
                </div>
                <form onSubmit={submit} className="grid grid-cols-2 gap-4 mt-8">
                    <div>
                        <InputLabel
                            htmlFor="first_name"
                            value={t("gg.register.form.label.first_name")}
                        />

                        <TextInput
                            id="first_name"
                            type="text"
                            name="first_name"
                            value={data.first_name}
                            className="block w-full mt-1"
                            autoComplete="given name"
                            isFocused={true}
                            onChange={(e) =>
                                setData("first_name", e.target.value)
                            }
                        />

                        <InputError
                            message={errors.first_name}
                            className="mt-2"
                        />
                    </div>
                    <div>
                        <InputLabel
                            htmlFor="last_name"
                            value={t("gg.register.form.label.last_name")}
                        />

                        <TextInput
                            id="last_name"
                            type="text"
                            name="last_name"
                            value={data.last_name}
                            className="block w-full mt-1"
                            isFocused={true}
                            onChange={(e) =>
                                setData("last_name", e.target.value)
                            }
                        />

                        <InputError
                            message={errors.last_name}
                            className="mt-2"
                        />
                    </div>
                    <div className="col-span-2">
                        <InputLabel
                            htmlFor="email"
                            value={t("gg.register.form.label.email")}
                        />

                        <TextInput
                            id="email"
                            type="email"
                            name="email"
                            value={data.email}
                            className="block w-full mt-1"
                            autoComplete="username"
                            onChange={(e) => setData("email", e.target.value)}
                            required
                        />

                        <InputError message={errors.email} className="mt-2" />
                    </div>
                    <div className="col-span-2">
                        <InputLabel
                            htmlFor="password"
                            value={t("gg.register.form.label.password")}
                        />

                        <TextInput
                            id="password"
                            type="password"
                            name="password"
                            value={data.password}
                            className="block w-full mt-1"
                            autoComplete="new-password"
                            onChange={(e) =>
                                setData("password", e.target.value)
                            }
                            required
                        />

                        <InputError
                            message={errors.password}
                            className="mt-2"
                        />
                    </div>
                    <div className="col-span-2">
                        <InputLabel
                            htmlFor="password_confirmation"
                            value={t(
                                "gg.register.form.label.password_confirmation"
                            )}
                        />

                        <TextInput
                            id="password_confirmation"
                            type="password"
                            name="password_confirmation"
                            value={data.password_confirmation}
                            className="block w-full mt-1"
                            autoComplete="new-password"
                            onChange={(e) =>
                                setData("password_confirmation", e.target.value)
                            }
                            required
                        />

                        <InputError
                            message={errors.password_confirmation}
                            className="mt-2"
                        />
                    </div>
                    <div className="flex items-center justify-end col-span-2 mt-4">
                        <Link
                            href={route("login")}
                            className="text-sm text-gray-600 underline rounded-md hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                        >
                            {t("gg.register.already-have")}
                        </Link>

                        <PrimaryButton className="ml-4" disabled={processing}>
                            {t("gg.register.submit")}
                        </PrimaryButton>
                    </div>
                </form>
            </div>
            <div className="py-4 text-center">
                <h6 className="font-[500] text-xl">
                    {t("gg.register.or-continue")}
                </h6>
            </div>
            <div className="grid md:flex w-full space-x-2 sm:max-w-md">
                <a
                    href={route("social.openAuth", { provider: "google" })}
                    className="flex px-6 py-2 space-x-2 text-xl duration-300 ease-in-out bg-white border hover:bg-gray-100 rounded-xl"
                >
                    {" "}
                    <img
                        className="self-center w-6 h-6"
                        src="/assets/image/social-logo/google.png"
                        alt=""
                    />{" "}
                    <span className="self-center">Google</span>
                </a>
                <a
                    href={route("social.openAuth", { provider: "facebook" })}
                    className="flex px-6 py-2 space-x-2 text-xl duration-300 ease-in-out bg-white border hover:bg-gray-100 rounded-xl"
                >
                    {" "}
                    <img
                        className="self-center w-6 h-6"
                        src="/assets/image/social-logo/facebook.png"
                        alt=""
                    />{" "}
                    <span className="self-center">Facebook</span>
                </a>
                <a
                    href={route("social.openAuth", { provider: "linkedin" })}
                    className="flex px-6 py-2 space-x-2 text-xl duration-300 ease-in-out bg-white border hover:bg-gray-100 rounded-xl"
                >
                    {" "}
                    <img
                        className="self-center w-6 h-6"
                        src="/assets/image/social-logo/linkedin.png"
                        alt=""
                    />{" "}
                    <span className="self-center">LinkedIn</span>
                </a>
            </div>
        </GuestLayout>
    );
}
