import { useEffect, FormEventHandler } from "react";
import Checkbox from "@/Components/Checkbox";
import GuestLayout from "@/Layouts/GuestLayout";
import InputError from "@/Components/InputError";
import InputLabel from "@/Components/InputLabel";
import PrimaryButton from "@/Components/PrimaryButton";
import TextInput from "@/Components/TextInput";
import { Head, Link, router, useForm } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { useCookies } from "react-cookie";

export default function Login({
    status,
    canResetPassword,
}: {
    status?: string;
    canResetPassword: boolean;
}) {
    const { t } = useLaravelReactI18n();
    const { data, setData, post, processing, errors, reset } = useForm({
        email: "",
        password: "",
        remember: false,
    });

    const [cookies, setCookie, removeCookie] = useCookies(["asp2quora"]);

    useEffect(() => {
        return () => {
            reset("password");
        };
    }, []);

    const submit: FormEventHandler = (e) => {
        e.preventDefault();

        post(route("login"), {
            onSuccess: (page) => {
                setCookie("asp2quora", true, { maxAge: 60 * 1 });
                router.get(route("show2Fa"));
            },
        });
    };

    return (
        <GuestLayout>
            <Head title="Log in" />

            <div className="w-full px-6 py-4 mt-3 overflow-hidden bg-white shadow-md sm:max-w-md sm:rounded-lg">
                <div className="text-center">
                    <h1 className="font-[700] text-primary text-5xl">
                        {t("gg.login.title")}
                    </h1>
                    <p className="mt-2 font-[500]">{t("gg.login.subtitle")}</p>
                </div>
                {status && (
                    <div className="mb-4 text-sm font-medium text-green-600">
                        {status}
                    </div>
                )}
                <form onSubmit={submit} className="mt-4">
                    <div>
                        <InputLabel
                            htmlFor="email"
                            value={t("gg.login.form.label.email")}
                        />

                        <TextInput
                            id="email"
                            type="email"
                            name="email"
                            value={data.email}
                            className="block w-full mt-1"
                            autoComplete="username"
                            isFocused={true}
                            onChange={(e) => setData("email", e.target.value)}
                        />

                        <InputError message={errors.email} className="mt-2" />
                    </div>

                    <div className="mt-4">
                        <InputLabel
                            htmlFor="password"
                            value={t("gg.login.form.label.password")}
                        />

                        <TextInput
                            id="password"
                            type="password"
                            name="password"
                            value={data.password}
                            className="block w-full mt-1"
                            autoComplete="current-password"
                            onChange={(e) =>
                                setData("password", e.target.value)
                            }
                        />

                        <InputError
                            message={errors.password}
                            className="mt-2"
                        />
                    </div>

                    <div className="block mt-4">
                        <label className="flex items-center">
                            <Checkbox
                                name="remember"
                                checked={data.remember}
                                onChange={(e) =>
                                    setData("remember", e.target.checked)
                                }
                            />
                            <span className="ml-2 text-sm text-gray-600">
                                {t("gg.login.form.label.remember")}
                            </span>
                        </label>
                    </div>
                    <div className="flex items-center justify-end mt-4">
                        {canResetPassword && (
                            <Link
                                href={route("password.request")}
                                className="text-sm text-gray-600 underline rounded-md hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                            >
                                {t("gg.login.forgot")}
                            </Link>
                        )}

                        <PrimaryButton className="ml-4" disabled={processing}>
                            {t("gg.login.submit")}
                        </PrimaryButton>
                    </div>
                </form>
                <p className="mt-4">
                    <Link
                        href={route("register")}
                        className="text-sm text-gray-700 underline rounded-md hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
                    >
                        {t("gg.login.new-account")}
                    </Link>
                </p>
            </div>
            <div className="py-4 text-center">
                <h6 className="font-[500] text-xl">
                    {t("gg.login.or-continue")}
                </h6>
            </div>
            <div className="grid gap-4 md:gap-0 md:flex w-full md:space-x-2 mx-auto max-w-[60vw] md:max-w-md">
                <a
                    href={route("social.openAuth", { provider: "google" })}
                    className="flex px-6 py-2 space-x-2 text-2xl lg:text-xl duration-300 ease-in-out bg-white border hover:bg-gray-100 rounded-xl"
                >
                    {" "}
                    <img
                        className="self-center w-12 h-12 lg:w-6 lg:h-6"
                        src="/assets/image/social-logo/google.png"
                        alt=""
                    />{" "}
                    <span className="self-center">Google</span>
                </a>
                <a
                    href={route("social.openAuth", { provider: "facebook" })}
                    className="flex px-6 py-2 space-x-2 text-2xl lg:text-xl duration-300 ease-in-out bg-white border hover:bg-gray-100 rounded-xl"
                >
                    {" "}
                    <img
                        className="self-center w-12 h-12 lg:w-6 lg:h-6"
                        src="/assets/image/social-logo/facebook.png"
                        alt=""
                    />{" "}
                    <span className="self-center">Facebook</span>
                </a>
                <a
                    href={route("social.openAuth", { provider: "linkedin" })}
                    className="flex px-6 py-2 space-x-2 text-2xl lg:text-xl duration-300 ease-in-out bg-white border hover:bg-gray-100 rounded-xl"
                >
                    {" "}
                    <img
                        className="self-center w-12 h-12 lg:w-6 lg:h-6"
                        src="/assets/image/social-logo/linkedin.png"
                        alt=""
                    />{" "}
                    <span className="self-center">LinkedIn</span>
                </a>
            </div>
        </GuestLayout>
    );
}
