import { useEffect, FormEventHandler, useState } from 'react';
import GuestLayout from '@/Layouts/GuestLayout';
import InputError from '@/Components/InputError';
import InputLabel from '@/Components/InputLabel';
import PrimaryButton from '@/Components/PrimaryButton';
import TextInput from '@/Components/TextInput';
import { Head, useForm } from '@inertiajs/react';
import { ArrowLeftCircleIcon } from '@heroicons/react/20/solid';
import { ArrowRightCircleIcon, ArrowRightIcon } from '@heroicons/react/24/outline';
import { useLaravelReactI18n } from "laravel-react-i18n";

export default function SetPassword({ id }: any) {
    const { t } = useLaravelReactI18n();
    const { data, setData, post, processing, errors, reset } = useForm({
        id: id,
        password: '',
        password_confirmation: '',
    });

    useEffect(() => {
        return () => {
            reset('password', 'password_confirmation');
        };
    }, []);

    const submit: FormEventHandler = (e) => {
        e.preventDefault();

        post(route('password.set'));
    };
    const [isWelcome, setIsWelcome] = useState(false)

    return (
        <GuestLayout>
            <Head title="Set Password" />
            {!isWelcome && <>
                <div className='p-5'>
                    {/* <ArrowRightIcon className="w-5 h-5"/> */}
                    <p className="pb-3 text-xl font-bold"> {t("gg.set-password.welcome.card.title")}</p>
                    <p className="font-semibold">  {t("gg.set-password.welcome.card.intro")}</p>
                </div>
                <div className='flex justify-end'>
                    <PrimaryButton
                        onClick={() => setIsWelcome(true)}
                    >
                        {t("gg.set-password.button")}
                        <ArrowRightCircleIcon className="w-5 h-5 ml-1" />
                    </PrimaryButton>
                </div></>}

            {isWelcome && <form onSubmit={submit}>


                <div className="mt-4">
                    <InputLabel htmlFor="password" value={t("gg.password")} />

                    <TextInput
                        id="password"
                        type="password"
                        name="password"
                        value={data.password}
                        className="block w-full mt-1"
                        autoComplete="new-password"
                        isFocused={true}
                        onChange={(e) => setData('password', e.target.value)}
                    />

                    <InputError message={errors.password} className="mt-2" />
                </div>

                <div className="mt-4">
                    <InputLabel htmlFor="password_confirmation" value={t("gg.confirm-password")} />

                    <TextInput
                        type="password"
                        name="password_confirmation"
                        value={data.password_confirmation}
                        className="block w-full mt-1"
                        autoComplete="new-password"
                        onChange={(e) => setData('password_confirmation', e.target.value)}
                    />

                    <InputError message={errors.password_confirmation} className="mt-2" />
                </div>

                <div className="flex items-center justify-end mt-4">
                    <PrimaryButton className="ml-4" disabled={processing}>
                        {t("gg.set-password.button")}
                    </PrimaryButton>
                </div>
            </form>}

        </GuestLayout>
    );
}
