// import { Link, useRouteError } from "react-router-dom";
import { Head } from "@inertiajs/react";
import { PageProps } from "@/types";
import { Link } from "@inertiajs/react";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import GuestLayout from "@/Layouts/GuestLayout";

export default function ErrorPage({
    auth,
    status,
    message,
    statusText,
}: {
    auth: PageProps;
    status: number;
    message: string;
    statusText: string;
}) {
    // const error = useRouteError();
    // console.error(error);

    return (
        <GuestLayout
        // user={auth.user}
        // header={
        //     <h2 className="text-xl font-semibold leading-tight text-gray-800 dark:text-gray-200">
        //         Error Page
        //     </h2>
        // }
        >
            <Head title="Error" />
            <div className="relative pb-32 mt-8 isolate">
                <div className="container grid px-6 mx-auto sm:gap-4 lg:px-8 basis-9/12">
                    <div className="flex flex-col items-center">
                        <h1 className="text-3xl font-bold text-primary lg:text-6xl">
                            {status}
                        </h1>
                        <h6 className="mb-2 text-2xl font-bold text-center text-gray-800 md:text-3xl">
                            <span className="text-red-500">Oops!</span> Page
                            {statusText}
                        </h6>

                        <p className="mb-4 text-center text-gray-500 md:text-lg">
                            {message}
                        </p>
                    </div>
                </div>
            </div>
        </GuestLayout>
    );
}

