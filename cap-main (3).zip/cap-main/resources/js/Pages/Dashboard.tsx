import Authenticated from "@/Layouts/AuthenticatedLayout";

function classNames(...classes: any) {
    return classes.filter(Boolean).join(" ");
}

export default function Dashboard({ auth, users }: any) {
    const user = auth.user;
    const bRoutes = [
        {
            name: "Dashboard",
            hasArrow: true,
            link: route("dashboard"),
        },
    ];
    return (
        <Authenticated bRoutes={bRoutes}>
            <Statistics user={user} usersData={users} />
        </Authenticated>
    );
}

function Statistics({ user, usersData }: any) {
    const stats = [
        { name: "Total Users", stat: usersData?.totalUsers ?? "0" },
        { name: "Pending For Approval", stat: usersData?.pending ?? "0" },
        { name: "Declined", stat: usersData?.declined ?? "0" },
    ];
    return (
        <div>
            <h3 className="text-base font-semibold leading-6 text-gray-900">
                Hello <strong>{user.name}</strong>
            </h3>
            <p>Here are your current statistics.</p>
            <dl className="grid grid-cols-1 gap-5 mt-5 sm:grid-cols-3">
                {stats.map((item) => (
                    <div
                        key={item.name}
                        className="px-4 py-5 overflow-hidden bg-white rounded-lg shadow sm:p-6"
                    >
                        <dt className="text-sm font-medium text-gray-500 truncate">
                            {item.name}
                        </dt>
                        <dd className="mt-1 text-3xl font-semibold tracking-tight text-gray-900">
                            {item.stat}
                        </dd>
                    </div>
                ))}
            </dl>
        </div>
    );
}
