import ConfirmButton from "@/Components/elements/buttons/ConfirmButton";
import { PrimaryButton, PrimaryLink } from "@/Components/elements/buttons/PrimaryButton";
import { SecondaryLink } from "@/Components/elements/buttons/SecondaryButton";
import MasterTable, { TableBody, TableTd } from "@/Components/elements/tables/masterTable";
import AuthenticatedLayout from "@/Layouts/AuthenticatedLayout";
import { ClipboardDocumentCheckIcon, ClipboardDocumentIcon, EyeIcon, XCircleIcon } from "@heroicons/react/24/outline";
import { PencilIcon } from "@heroicons/react/24/solid";
import { Head, Link, router } from "@inertiajs/react";
import CopyToClipboard from "react-copy-to-clipboard";
import { useLaravelReactI18n } from "laravel-react-i18n";
import useStateRef from "react-usestateref";
import { useState } from "react";
import Modal from "@/Components/Modal";
import TextInput from "@/Components/elements/inputs/TextInput";
import InputError from "@/Components/elements/inputs/InputError";
import TextArea from "@/Components/elements/inputs/TextArea";
import InputLabel from "@/Components/elements/inputs/InputLabel";
import SelectInput from "@/Components/elements/inputs/SelectInput";

export default function QuestionnaireAllIndex({
    questionary,
    filters,
}: {
    questionary: any;
    filters: any;
}) {

    const { t } = useLaravelReactI18n();
    const bRoutes = [
        {
            name: "breadcrumbs.dashboard",
            hasArrow: true,
            link: route("dashboard"),
        },
        {
            name: "breadcrumbs.questionary",
            hasArrow: true,
            link: route("questionnaire.index"),
        },
    ];

    const tableColumns = [
        {
            label: "",
            sortField: "",
            sortable: false,
        },
        {
            label: t("questionary.all.table.id"),
            sortField: "id",
            sortable: true,
        },
        {
            label: t("questionary.all.table.question.or.answer"),
            sortField: "name",
            sortable: true,
        },
        {
            label: t("questionary.all.table.tag.id"),
            sortField: "tag",
            sortable: true,
        },
        // {
        //     label: t("questionary.all.table.type"),
        //     sortField: "type",
        //     sortable: false,
        // },
        {
            label: t("questionary.all.table.created_at_human"),
            sortField: "created_at",
            sortable: true,
        },
    ];

    // const createLink = {
    //     url: route("questionnaire.create"),
    //     label: t("questionary.all.buttons.create"),
    // };
    const search = {
        placeholder: 'search',
    };

    const [buttonName, setButtonName, buttonNameRef] = useStateRef("Create");
    const showModal = () => {
        setButtonName("Create");
        setIsModalOpen(true);
    };

    const [isModalOpen, setIsModalOpen] = useState(false);
    const [key, setKey, KeyRef] = useStateRef("");
    const [tag, setTag, TagRef] = useStateRef("");
    // const [question, setQuestion, QuestionRef] = useStateRef("");
    const [id, setId, IdRef] = useStateRef("");

    function openSelectionModal(questionary: any) {
        setKey(questionary?.key);
        setTag(questionary?.tag);
        setIsModalOpen(true);
    }
    function closeModal() {
        setKey("");
        setTag("");
        setIsModalOpen(false);
    }
    const submit = () => {
        if (KeyRef.current && TagRef.current) {
            if (buttonNameRef.current == "Create") {
                router.post(route("questionnaire.store"), {
                    tag: TagRef.current,
                    key: KeyRef.current,
                });
            } else {
                if (IdRef.current) {
                    router.patch(
                        route("questionnaire.update", {
                            id: IdRef.current,
                        }),
                        {
                            tag: TagRef.current,
                            key: KeyRef.current,
                        }
                    );
                }
            }

            closeModal();
        } else {
        }
        setKey("");
        setTag("");
    };

    const [openImportModal, setOpenImportModal] = useState(false);
    const showImportModal = () => {
        setOpenImportModal(true);
    };
    const closeImportModal = () => {
        setOpenImportModal(false);
    };
    const [questionArray, setQuestionArray] = useState('');
    const submitImport = () => {
        if (questionArray) {
            router.post(route("questionnaire.import"), {
                array: questionArray
            });
            setOpenImportModal(false);
        };
    }

    return (
        <AuthenticatedLayout bRoutes={bRoutes}>
            <Head title={t("questionary.all.title")} />
            <div className="md:flex md:items-center md:justify-between">
                <div className="flex-1 min-w-0">
                    <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:truncate sm:text-3xl sm:tracking-tight">
                        {t("questionary.all.title")}
                    </h2>
                </div>
            </div>

            <div>
                {/* Table */}
                <MasterTable
                    tableColumns={tableColumns}
                    filters={filters}
                    url={route("questionnaire.index")}
                    modalOpen={showModal}
                    importModal={showImportModal}
                    search={search}
                    links={questionary?.meta?.links}
                >
                    {questionary?.data?.map((item: any, index: number) => (
                        <TableBody
                            buttons={
                                <>
                                    <PrimaryButton
                                        className="!py-2 "
                                        onClick={() => {
                                            openSelectionModal(item);
                                            setButtonName("Edit");
                                            setId(item.id);
                                        }}
                                    >
                                        <PencilIcon className="w-3 h-3 mr-2" />{" "}
                                        {t("users.all.table.edit")}
                                    </PrimaryButton>

                                    <ConfirmButton
                                        className="!py-2"
                                        url={route("questionnaire.destroy", {
                                            id: item.id,
                                        })}
                                        label={t(
                                            "table.all.delete"
                                        )}
                                    />
                                </>
                            }
                            key={item.id}
                        >
                            <TableTd>{item.id}</TableTd>
                            <TableTd>
                                <div className="text-sm">
                                    {item?.key?.substring(0, 25)}
                                </div>
                            </TableTd>
                            <TableTd>
                                <div>
                                    {item.tag}
                                    {item.options != null && item.options.length > 0 && (
                                        <ul className="ml-1">
                                            {Object.keys(item.options).map((key) => (
                                                <li className="ml-5 text-slate-600" key={key}>
                                                    {key} - {item.options[key]}
                                                </li>
                                            ))}
                                        </ul>
                                    )}

                                </div>
                            </TableTd>
                            {/* <TableTd>
                                <span className="uppercase">
                                    {item.type}
                                </span>
                            </TableTd> */}
                            <TableTd>{item.created_at_human}</TableTd>
                        </TableBody>
                    ))}
                </MasterTable>
            </div>
            {/* ---- */}
            <Modal
                show={isModalOpen}
                onClose={() => console.log("g")}
            // className=""
            >
                <div className="absolute top-0 right-0">
                    <XCircleIcon
                        onClick={() => {
                            closeModal();
                            // reset()
                        }}
                        className="w-10 h-10 hover:cursor-pointer"
                    />
                </div>
                <div className=" h-[98%] mt-8bg-white">
                    <div className="grid grid-cols-1 p-4 bg-white rounded-lg shadow-md w-96 ">
                        {/* <div className="grid grid-cols-2 gap-2"> */}
                        <div>
                            <span className="pb-4 font-semibold capitalize">
                                {buttonNameRef.current} Questionary.
                            </span>
                            <div className="relative border-[1px] rounded-xl border-slate-400  flex p-1 mt-2">
                                {/* <form onSubmit={submit}> */}
                                <div className="bg-[#FFFFFF] p-8">
                                    <div className="grid grid-flow-col gap-4">
                                        <div className="row-span-3">
                                            {/*  */}
                                            {/* description */}
                                            <div className="mt-1">
                                                <label
                                                    htmlFor="key"
                                                    className="block text-sm font-medium text-gray-700"
                                                >
                                                    Key (Question){" "}
                                                    <span className="text-red-600">
                                                        *
                                                    </span>
                                                </label>

                                                <TextArea
                                                    id="key"
                                                    className="block w-full mt-1 h-28"
                                                    value={
                                                        KeyRef.current
                                                    }
                                                    onChange={(e) => {
                                                        setKey(
                                                            e.target.value
                                                        );
                                                    }}
                                                    // rows={5}
                                                    placeholder="key"
                                                    autoComplete="key"
                                                />

                                                <InputError
                                                    className="mt-2"
                                                // message={errors.reason}
                                                />
                                            </div>
                                            <div>
                                                <label
                                                    htmlFor="tag"
                                                    className="block text-sm font-medium text-gray-700"
                                                >
                                                    Tag{" "}
                                                    <span className="text-red-600">
                                                        *
                                                    </span>
                                                </label>

                                                <TextInput
                                                    id="name"
                                                    className="block w-full mt-1"
                                                    value={TagRef.current}
                                                    onChange={(e) => {
                                                        // setData(
                                                        //     "name",
                                                        //     e.target.value
                                                        // );
                                                        setTag(e.target.value);
                                                    }}
                                                    isFocused
                                                    placeholder="tag"
                                                    autoComplete="tag"
                                                />

                                                <InputError
                                                    className="mt-2"
                                                // message={errors.name}
                                                />
                                            </div>
                                            {/* ///// */}
                                            {/* <div className="mt-1">
                                                <label
                                                    htmlFor="options"
                                                    className="block text-sm font-medium text-gray-700"
                                                >
                                                    Options {" "}
                                                    <span className="text-red-600">
                                                        *
                                                    </span>
                                                </label>

                                                <TextArea
                                                    id="options"
                                                    className="block w-full h-24 mt-1"
                                                    value={
                                                        KeyRef.current
                                                    }
                                                    onChange={(e) => {
                                                        setKey(
                                                            e.target.value
                                                        );
                                                    }}
                                                    // rows={5}
                                                    placeholder="ex: value|key,"
                                                    autoComplete="options"
                                                />

                                                <InputError
                                                    className="mt-2"
                                                // message={errors.reason}
                                                />
                                            </div> */}
                                            {/* /////////// */}


                                        </div>
                                    </div>
                                    <div className="px-4 py-4 sm:px-8">
                                        <div className="flex items-center justify-center">
                                            <PrimaryButton
                                                //  disabled={processing}
                                                onClick={submit}
                                            >
                                                {buttonNameRef.current}
                                            </PrimaryButton>

                                            {/* <Transition
                                                    show={recentlySuccessful}
                                                    enterFrom="opacity-0"
                                                    leaveTo="opacity-0"
                                                    className="transition ease-in-out"
                                                >
                                                    <p className="text-sm text-gray-600">
                                                        Account {buttonNameRef.current} successfully.
                                                    </p>
                                                </Transition> */}
                                        </div>
                                    </div>
                                </div>

                                {/* </form> */}
                            </div>
                        </div>
                        <div></div>
                        {/* </div> */}
                    </div>
                </div>
            </Modal>
            {/* ----- */}
            <Modal
                show={openImportModal}
                onClose={() => console.log("g")}
            // className=""
            >
                <div className="absolute top-0 right-0">
                    <XCircleIcon
                        onClick={() => {
                            closeImportModal();
                            // reset()
                        }}
                        className="w-10 h-10 hover:cursor-pointer"
                    />
                </div>
                <div className=" h-[98%] mt-8bg-white">
                    <div className="grid w-full grid-cols-1 p-4 bg-white rounded-lg shadow-md ">
                        {/* <div className="grid grid-cols-2 gap-2"> */}
                        <div>
                            <span className="pb-4 font-semibold capitalize">
                                Add Questionary.
                            </span>
                            {/* <div className="relative border-[1px] rounded-xl border-slate-400  flex p-1 mt-2"> */}
                            {/* <form onSubmit={submit}> */}
                            <div className="bg-[#FFFFFF]">
                                <div className="grid grid-flow-col gap-4">
                                    <div className="row-span-3">
                                        {/*  */}
                                        {/* description */}
                                        <div className="mx-5 w-96 h-80 ">
                                            <label
                                                htmlFor="key"
                                                className="block text-sm font-medium text-gray-700"
                                            >
                                                Sumsub Questions {" "}
                                                <span className="text-red-600">
                                                    *
                                                </span>
                                            </label>

                                            <TextArea
                                                id="question"
                                                className="block w-full h-full mt-1"
                                                value={
                                                    questionArray
                                                }
                                                onChange={(e) => {
                                                    setQuestionArray(
                                                        e.target.value
                                                    );
                                                }}
                                                // rows={5}
                                                placeholder="question array"
                                                autoComplete="key"
                                            />

                                            <InputError
                                                className="mt-2"
                                            // message={errors.reason}
                                            />
                                        </div>



                                    </div>
                                </div>
                                <div className="px-6 py-4 sm:px-8">
                                    <div className="flex items-center justify-center">
                                        <PrimaryButton
                                            className="mt-4"
                                            onClick={submitImport}
                                        >
                                            Add
                                        </PrimaryButton>

                                        {/* <Transition
                                                    show={recentlySuccessful}
                                                    enterFrom="opacity-0"
                                                    leaveTo="opacity-0"
                                                    className="transition ease-in-out"
                                                >
                                                    <p className="text-sm text-gray-600">
                                                        Account {buttonNameRef.current} successfully.
                                                    </p>
                                                </Transition> */}
                                    </div>
                                </div>
                            </div>

                            {/* </form> */}
                            {/* </div> */}
                        </div>
                        <div></div>
                        {/* </div> */}
                    </div>
                </div>
            </Modal>
        </AuthenticatedLayout>
    );
};
