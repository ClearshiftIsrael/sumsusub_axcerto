export const PublicNavigationLinks = [
    {
        name: "sidebar.link.dashboard",
        link: true,
        border: false,
        startWith: "/",
        route: "dashboard",
        icon: "ChartPieIcon",
    },
    {
        name: "Verify",
        link: true,
        border: false,
        startWith: "/verify",
        route: "verify.index",
        icon: "UsersIcon",
    },
    {
        name: "Profile",
        link: true,
        border: false,
        startWith: "/profile",
        route: "profile.index",
        icon: "UsersIcon",
    },
];
