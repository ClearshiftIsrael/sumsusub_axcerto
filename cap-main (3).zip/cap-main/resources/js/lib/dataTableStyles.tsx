export const primaryTable: any = {
    rows: {
        style: {
            // minHeight: '72px', // override the row height
            padding: "10px",
            backgroundColor: "#ffffff",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            //   zIndex: "1",
            //   potision: "absolute",
        },
    },
    headCells: {
        style: {
            borderTopLeftRadius: "8px",
            borderTopRightRadius: "8px",
            fontWeight: "bold",
            fontSize: "14px",
            paddingTop: "0px",
            whiteSpace: "nowrap",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            paddingLeft: "8px",
            paddingRight: "8px",
        },
    },
    headRow: {
        style: {
            padding: "8px",
            borderTopLeftRadius: "10px",
            borderTopRightRadius: "10px",
            backgroundColor: "#e2e8f0",
            borderBottom: "0 solid #e2e8f0",
            whiteSpace: "nowrap",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
        },
    },
    pagination: {
        style: {
            borderBottomLeftRadius: "10px",
            borderBottomRightRadius: "10px",
            zIndex: "0",
        },
    },
    cells: {
        style: {
            paddingLeft: "8px",
            paddingRight: "8px",
            whiteSpace: "nowrap",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            width: "fit-content",
            potision: "absolute",
        },
    },
    table: {
        style: {
            borderRadius: "10px",
            boxShadow: "0 0 10px 0 rgba(0, 0, 0, 0.1)",
        },
    },
    column: {
        style: {
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            textAlign: "center",
            whiteSpace: "nowrap",
            width: "fit-content",
        },
    },
};
