import { Config } from "ziggy-js";
export interface User {
    provider: string;
    username: any;
    password: string | number | readonly string[] | undefined;
    cover: string | undefined;
    role: any;
    status: any;
    meta_data: any;
    avatar: string | undefined;
    id: number;
    name: string;
    email: string;
    email_verified_at: string;
    twofa_enabled_at: string;
}

export type PageProps<T extends Record<string, unknown> = Record<string, unknown>> =
    T & {
        auth: {
            user: User;
        };
        flash: {
            error: any;
            success: any;
            message: string;
            type: string;
        };
        ziggy: Config & { location: string };
    };
