import { LabelHTMLAttributes } from 'react';

export default function InputLabel({
    value,
    className = "",
    required = false,
    children,
    ...props
}: LabelHTMLAttributes<HTMLLabelElement> & { value?: string; required?:boolean }) {
    return (
        <label
            {...props}
            className={`block font-medium text-sm text-gray-700 ` + className}
        >
            {value ? value : children}
            {required&&<span className='text-red-600'>*</span>}
        </label>
    );
}
