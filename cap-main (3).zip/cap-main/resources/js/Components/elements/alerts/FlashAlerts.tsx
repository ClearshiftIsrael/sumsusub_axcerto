import SuccessAlert from "./SuccessAlert";
import { PageProps } from "@/types";
import { useLaravelReactI18n } from "laravel-react-i18n";
import DangerAlert from "./DangerAlert";

export default function FlashAlerts({ flash }: { flash: PageProps["flash"] }) {
    const { t } = useLaravelReactI18n();
    return (
        <>
            {flash?.success && (
                <SuccessAlert
                    title={t(flash.message)}
                    message={flash?.success}
                />
            )}

            {flash?.error && (
                <DangerAlert
                    title={t(flash.message)}
                    message={flash?.error}
                />
            )}
        </>
    );
}
