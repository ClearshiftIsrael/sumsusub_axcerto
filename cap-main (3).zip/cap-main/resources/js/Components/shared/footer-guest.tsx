import { useLaravelReactI18n } from "laravel-react-i18n";

function getYear() {
    return new Date().getFullYear();
}
export default function FooterGuest() {
    const { t } = useLaravelReactI18n();
    return (
        <footer className=" w-full ">
            <div className="px-4 py-4 sm:px-6 md:flex md:items-center md:justify-between lg:px-8">
                <div className="mx-auto mt-8 md:order-1 md:mt-0">
                    <div className="mt-2 text-gray-800">
                        <p className="flex justify-center sm-auto font-[400] text-gray-600 text-sm">
                            @{getYear()} Clearshift All Rights Reserved.
                        </p>
                        <p className="flex justify-center sm-auto font-[400] text-gray-600 text-xs mt-2">
                            Development and Maintenance by
                            <a
                                target="_blank"
                                className="mx-1 font-[500] cursor-pointer"
                                href="https://axcertro.com/?a=clearshift"
                            >
                                Acertro Ltd
                            </a>{" "}
                        </p>
                    </div>
                </div>
            </div>
        </footer>
    );
}
