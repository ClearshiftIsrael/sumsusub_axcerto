import * as translationConfigs from "@/lib/translations";
import { Menu, Transition } from "@headlessui/react";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
import { router } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { Fragment } from "react";

function classNames(...classes: any) {
    return classes.filter(Boolean).join(" ");
}

function getLocaleName(locale: string, long = true) {
    switch (locale) {
        case "he":
            return long ? "Hebrew" : "HE";
        default:
            return long ? "English" : "EN";
    }
}
export default function internationalization({ guest = false }) {
    const { currentLocale, setLocale, getLocales } = useLaravelReactI18n();

    function changeLanguage(language: string) {
        router.visit(route("language", { language: language }));
        setLocale(language);
    }
    return (
        <Menu as="div" className="relative self-center inline-block text-left">
            <div>
                <Menu.Button className="flex items-center bg-gray-200 px-4 py-1 rounded-xl space-x-2 justify-center w-full text-sm font-medium rounded-lg  focus:outline-none focus:ring-2 focus:ring-transparent">
                    <span>
                        <span className="hidden lg:inline">Language:</span>
                        <span className="font-[800] hidden lg:inline">
                            {getLocaleName(currentLocale(), true)}
                        </span>
                        <span className="font-[800] lg:hidden">
                            {getLocaleName(currentLocale(), false)}
                        </span>
                    </span>
                    <ChevronDownIcon className="self-center w-5 h-5" />
                </Menu.Button>
            </div>

            <Transition
                as={Fragment}
                enter="transition ease-out duration-100"
                enterFrom="transform opacity-0 scale-95"
                enterTo="transform opacity-100 scale-100"
                leave="transition ease-in duration-75"
                leaveFrom="transform opacity-100 scale-100"
                leaveTo="transform opacity-0 scale-95"
            >
                <Menu.Items className="absolute z-50 w-48 py-1 mt-2 origin-top-right bg-white rounded-md shadow-lg -right-6 dropdown-menu ring-1 ring-black ring-opacity-5 focus:outline-none">
                    <div className="py-1">
                        {translationConfigs.LANGUAGES.map((language, index) => (
                            <Menu.Item key={index}>
                                {({ active }) => (
                                    <button
                                        onClick={() => changeLanguage(language)}
                                        className={classNames(
                                            language == currentLocale()
                                                ? " bg-gray-100 text-gray-900"
                                                : "text-gray-700",
                                            "block w-full px-4 py-2 text-left text-sm "
                                        )}
                                    >
                                        {getLocaleName(language)}
                                    </button>
                                )}
                            </Menu.Item>
                        ))}
                    </div>
                </Menu.Items>
            </Transition>
        </Menu>
    );
}
