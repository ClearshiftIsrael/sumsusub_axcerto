import Internationalization from "@/Components/shared/internationalization";
import { Disclosure, Menu, Transition } from "@headlessui/react";
import {
    ChevronDownIcon
} from "@heroicons/react/20/solid";
import { Bars3Icon, XMarkIcon } from "@heroicons/react/24/outline";
import { Link, usePage } from "@inertiajs/react";
import { useLaravelReactI18n } from "laravel-react-i18n";
import { Fragment } from "react";


const userNavigation = [{ name: "My Profile", href: route("profile.index") }];

function classNames(...classes: any) {
    return classes.filter(Boolean).join(" ");
}

export default function MemberNav() {
    const { url, props } = usePage();
        const { t } = useLaravelReactI18n();

    const navigation = [
        {
            name: t("pp.header.links.dashboard"),
            href: route("dashboard"),
            current: "/dashboard",
        },
        {
            name: t("pp.header.links.accounts"),
            href: route("accounts.index"),
            current: "/accounts",
        },
        // { name: "My Profile", href: route("profile.index"), current: "/profile" },
    ];

    const { user }: any = props.auth;
    return (
        <Disclosure as="header" className="z-20 bg-white shadow">
            {({ open }) => (
                <>
                    <div className="w-full">
                        <div className="container relative flex justify-between h-16 px-2 mx-auto sm:px-4 lg:px-8">
                            <div className="relative z-10 flex px-2 lg:px-0">
                                <div className="flex items-center flex-shrink-0">
                                    <img
                                        className="w-auto h-8"
                                        src={"/assets/image/logo.png?a=10"}
                                        alt="Clearshift"
                                    />
                                </div>
                            </div>
                            <div className="relative z-0 flex items-center justify-center flex-1 px-2 sm:absolute sm:inset-0"></div>
                            <div className="relative z-10 flex items-center lg:hidden">
                                <Internationalization guest={false} />
                                {/* Mobile menu button */}
                                <Disclosure.Button className="relative inline-flex items-center justify-center p-2 text-gray-400 rounded-md hover:bg-gray-100 hover:text-gray-500 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-indigo-500">
                                    <span className="absolute -inset-0.5" />
                                    <span className="sr-only">Open menu</span>
                                    {open ? (
                                        <XMarkIcon
                                            className="block w-6 h-6"
                                            aria-hidden="true"
                                        />
                                    ) : (
                                        <Bars3Icon
                                            className="block w-6 h-6"
                                            aria-hidden="true"
                                        />
                                    )}
                                </Disclosure.Button>
                            </div>
                            <div className="hidden lg:relative lg:z-10 lg:ml-4 lg:flex lg:items-center">
                                <div className=" text-slate-900 p-4 rounded-full flex justify-center ml-6">
                                    <Internationalization guest={false} />
                                </div>
                                {/* Profile dropdown */}
                                <div>
                                    <Menu as="div" className="relative ml-4">
                                        <div>
                                            <Menu.Button className="relative flex bg-white rounded-full focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                                                <span className="self-center font-[700] text-gray-600">
                                                    {user.name}
                                                </span>
                                                <ChevronDownIcon className="self-center w-8 h-8" />
                                            </Menu.Button>
                                        </div>
                                        <Transition
                                            as={Fragment}
                                            enter="transition ease-out duration-100"
                                            enterFrom="transform opacity-0 scale-95"
                                            enterTo="transform opacity-100 scale-100"
                                            leave="transition ease-in duration-75"
                                            leaveFrom="transform opacity-100 scale-100"
                                            leaveTo="transform opacity-0 scale-95"
                                        >
                                            <Menu.Items className="absolute right-0 z-10 w-48 py-1 mt-2 origin-top-right bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5 focus:outline-none">
                                                {userNavigation.map((item) => (
                                                    <Menu.Item key={item.name}>
                                                        {({ active }) => (
                                                            <Link
                                                                href={item.href}
                                                                className={classNames(
                                                                    active
                                                                        ? "bg-gray-100"
                                                                        : "",
                                                                    "block px-4 py-2 text-sm text-gray-700"
                                                                )}
                                                            >
                                                                {item.name}
                                                            </Link>
                                                        )}
                                                    </Menu.Item>
                                                ))}
                                                <Menu.Item>
                                                    {({ active }) => (
                                                        <Link
                                                            href={route(
                                                                "logout"
                                                            )}
                                                            method={"post"}
                                                            as="button"
                                                            type="button"
                                                            className={classNames(
                                                                active
                                                                    ? "bg-gray-100"
                                                                    : "",
                                                                "block px-4 py-2 text-sm text-gray-700 w-full text-left"
                                                            )}
                                                        >
                                                            Logout
                                                        </Link>
                                                    )}
                                                </Menu.Item>
                                            </Menu.Items>
                                        </Transition>
                                    </Menu>
                                </div>
                            </div>
                        </div>
                        <div className="bg-gray-100 ">
                            <nav
                                className="container hidden px-2 mx-auto lg:flex lg:space-x-8 lg:py-2 sm:px-4 lg:px-8"
                                aria-label="Global"
                            >
                                {navigation.map((item) => (
                                    <a
                                        key={item.name}
                                        href={item.href}
                                        className={classNames(
                                            url.startsWith(item.current)
                                                ? "bg-primary text-white"
                                                : "text-gray-900 hover:bg-gray-50 hover:text-gray-900",
                                            "inline-flex items-center rounded-md py-2 px-3 text-sm font-medium"
                                        )}
                                        aria-current={
                                            url.startsWith(item.current)
                                                ? "page"
                                                : undefined
                                        }
                                    >
                                        {item.name}
                                    </a>
                                ))}
                            </nav>
                        </div>
                    </div>

                    <Disclosure.Panel
                        as="nav"
                        className="lg:hidden"
                        aria-label="Global"
                    >
                        <div className="px-2 pt-2 pb-3 space-y-1">
                            {navigation.map((item) => (
                                <Disclosure.Button
                                    key={item.name}
                                    as="a"
                                    href={item.href}
                                    className={classNames(
                                        url.startsWith(item.current)
                                            ? "bg-primary text-white"
                                            : "text-gray-900 hover:bg-gray-50 hover:text-gray-900",
                                        "block rounded-md py-2 px-3 text-base font-medium"
                                    )}
                                    aria-current={
                                        url.startsWith(item.current)
                                            ? "page"
                                            : undefined
                                    }
                                >
                                    {item.name}
                                </Disclosure.Button>
                            ))}
                        </div>
                        <div className="pt-4 pb-3 border-t border-gray-200">
                            <div className="flex items-center px-4">
                                <div className="flex-shrink-0">
                                    <img
                                        className="w-10 h-10 rounded-full"
                                        src={user.imageUrl}
                                        alt="User Avatar"
                                    />
                                </div>
                                <div className="ml-3">
                                    <div className="text-base font-medium text-gray-800">
                                        {user.name}
                                    </div>
                                    <div className="text-sm font-medium text-gray-500">
                                        {user.email}
                                    </div>
                                </div>
                            </div>
                            <div className="px-2 mt-3">
                                {userNavigation.map((item) => (
                                    <Disclosure.Button
                                        key={item.name}
                                        as="a"
                                        href={item.href}
                                        className="block px-3 py-2 text-base font-medium text-gray-500 rounded-md hover:bg-gray-50 hover:text-gray-900"
                                    >
                                        {item.name}
                                    </Disclosure.Button>
                                ))}
                                <Disclosure.Button>
                                    <Link
                                        href={route("logout")}
                                        method={"post"}
                                        as="button"
                                        type="button"
                                        className="block px-3 py-2 text-base font-medium text-gray-500 rounded-md hover:bg-gray-50 hover:text-gray-900"
                                    >
                                        Logout
                                    </Link>
                                </Disclosure.Button>
                            </div>
                        </div>
                    </Disclosure.Panel>
                </>
            )}
        </Disclosure>
    );
}
