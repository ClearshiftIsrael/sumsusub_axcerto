
import { Popover } from '@headlessui/react';
import { Link } from '@inertiajs/react';
import { useEffect, useState } from 'react';
import Internationalization from './internationalization';
function classNames(...classes: string[]) {
  return classes.filter(Boolean).join(' ');
}

interface Props {
  locale?: string;
}

export default function PublicHeader({ locale }: Props) {
  const [sticky, setSticky] = useState(false);

  useEffect(() => {
    window.addEventListener('scroll', isSticky);
    return () => {
      window.removeEventListener('scroll', isSticky);
    };
  }, []);

  const isSticky = () => {
    /* Method that will fix header after a specific scrollable */
    const scrollTop = window.scrollY;
    const stickyClass = scrollTop >= 170 ? true : false;
    setSticky(stickyClass);
  };

  return (
      <header
          className={`${
              sticky
                  ? "bg-[#F5F7FA] backdrop-blur-[30px]"
                  : "border-transparent bg-transparent shadow-none"
          } sticky top-0  z-50 block `}
      >
          <Popover className="relative">
              <div className="container mx-auto flex items-center justify-between px-2 py-2 md:justify-start md:space-x-10 lg:px-0  xl:py-4 2xl:py-4">
                  <div className="flex justify-start lg:w-0 lg:flex-1">
                      <Link href={route('home')}>
                          <span className="sr-only">GP Advisory</span>
                          {sticky ? (
                              <>
                                  <img
                                      src="/assets/images/logos/logo.png?a=1"
                                      width={120}
                                      height={100}
                                      alt="Ibiza Logo"
                                      className="width-[auto] hidden lg:block"
                                  />
                                  <img
                                      src="/assets/images/logos/logo-short.png?a=1"
                                      width={60}
                                      height={40}
                                      alt="Ibiza Logo"
                                      className="width-[auto] lg:hidden"
                                  />
                              </>
                          ) : (
                              <>
                                  <img
                                      src="/assets/images/logos/logo-white.png?a=1"
                                      width={120}
                                      height={100}
                                      alt="Ibiza Logo"
                                      className="width-[auto] hidden lg:block"
                                  />
                                  <img
                                      src="/assets/images/logos/logo-short-white.png?a=1"
                                      width={60}
                                      height={40}
                                      alt="Ibiza Logo"
                                      className="width-[auto] lg:hidden"
                                  />
                              </>
                          )}
                      </Link>
                  </div>
                  <div className="flex items-center justify-end space-x-2 lg:w-0">
                      <Internationalization />
                      {/* {user ? (
              <Link
                href={'/dashboard'}
                className="inline-flex h-[55px] w-[55px] justify-center self-center rounded-full bg-white p-3 text-sm font-medium text-gray-700 focus:outline-none  focus:ring-2 focus:ring-transparent hover:bg-gray-50 lg:h-[auto] lg:w-[200px] lg:rounded-3xl xl:px-[28px] xl:py-[14px]"
              >
                <LeftCir className="h-6 w-6 self-center text-primary" />{' '}
                <span className="ml-2 hidden self-center lg:block">
                  Dashboard
                </span>
              </Link>
            ) : (
              <Link
                href={'/login'}
                className="flex h-[55px] w-[55px] justify-center rounded-full bg-white p-4 text-sm font-medium text-gray-700 focus:outline-none focus:ring-2  focus:ring-transparent hover:bg-gray-50 lg:h-[auto] lg:w-[120px] lg:rounded-3xl xl:px-[28px] xl:py-[14px]"
              >
                <MdLogin className="h-6 w-6 self-center text-primary" />{' '}
                <span className="ml-2 hidden self-center lg:block">Login</span>
              </Link>
            )} */}
                  </div>
              </div>
          </Popover>
      </header>
  );
}
