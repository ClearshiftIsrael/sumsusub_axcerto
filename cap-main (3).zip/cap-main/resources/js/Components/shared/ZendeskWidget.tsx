import Zendesk from "react-zendesk";
const ZENDESK_KEY = import.meta.env.VITE_ZENDESK_KEY;
// "98fd15c6-9361-43ea-b0e6-32b345a925e6";

const setting = {
    // color: {
    //     theme: "#000"
    // },
    // launcher: {
    //     chatLabel: {
    //         "en-US": "Need Help"
    //     }
    // },
    // contactForm: {
    //     fields: [
    //         { id: "description", prefill: { "*": "My pre-filled description" } }
    //     ]
    // }
    locale: "en-US",
};
export default function ZendeskWidget({}) {
    return <Zendesk defer zendeskKey={ZENDESK_KEY} {...setting} onLoaded={() => console.log('zendesk loaded')} />;
};
