import { useLaravelReactI18n } from "laravel-react-i18n";
import { FC} from "react";
import NavItem from "./partials/NavItem";
import { User } from "@/types";
import { navigationLinks } from "@/lib/SideNavLinks";

interface ISidebar {
    user: User;
}

const Sidebar: FC<ISidebar> = () => {
    const { t } = useLaravelReactI18n();
    return (
        <>
            {/* Static sidebar for desktop */}
            <div className="hidden lg:fixed lg:inset-y-0 lg:flex lg:w-[260px] lg:flex-col pt-20">
                {/* Sidebar component, swap this element with another sidebar if you like */}
                <div className="flex flex-grow flex-col overflow-y-auto bg-slate-200 pb-4 pl-4 pr-3 pt-0">
                    <nav
                        className="overflow-revert scrollbar-track-rounded-full scrollbar-thumb-rounded-full flex flex-1 flex-col  overscroll-auto scroll-smooth scrollbar-thin "
                        aria-label="Sidebar"
                    >
                        <div className="pt-8">
                            {navigationLinks.map((item: any) => (
                                <NavItem
                                    key={item.name}
                                    name={t(item.name)}
                                    routeName={route(item.route)}
                                    startWith={item.startWith}
                                    icon={item.icon}
                                    link={item.link}
                                    border={item.border}
                                    children={item.children}
                                />
                            ))}
                        </div>
                    </nav>
                </div>
            </div>
        </>
    );
};
export default Sidebar;
