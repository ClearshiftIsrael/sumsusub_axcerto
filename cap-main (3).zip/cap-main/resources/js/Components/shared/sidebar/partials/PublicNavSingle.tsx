import DynamicHeroIcon from "@/Components/DynamicHeroIcon";
import { Link, usePage } from "@inertiajs/react";
import NavSeparator from "./NavSeparator";
import NavTitle from "./NavTitle";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
function classNames(...classes: string[]) {
    return classes.filter(Boolean).join(" ");
}

export default function PublicNavSingle({
    startWith,
    routeName,
    name,
    icon,
}: {
    startWith?: string;
    routeName?: any;
    name: any;
    icon: any;
}) {
    const { url } = usePage();

    function isActive(startWith?: string) {
        if (startWith == "/") {
            return url == startWith;
        } else {
            return url.startsWith(startWith ?? "");
        }
    }

    return (
        <div className="flex items-center py-2">
            <Link
                href={routeName}
                className={classNames(
                    isActive(startWith)
                        ? " text-primary border-b-2 border-b-primary "
                        : "text-gray-600 cursor-pointer hover:text-primary hover:shadow  ",
                    " group mt-0 flex   items-center text-sm font-medium  duration-300 ease-in-out transition-all w-full "
                )}
                aria-current={isActive(startWith) ? "page" : undefined}
            >
                <span className="text"> {name}</span>
            </Link>
        </div>
    );
}
