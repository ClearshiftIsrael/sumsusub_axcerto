import { usePage } from "@inertiajs/react";
import NavSeparator from "./NavSeparator";
import NavTitle from "./NavTitle";
import NavMulti from "./NavMulti";
import NavSingle from "./NavSingle";
import PublicNavSingle from "./PublicNavSingle";

const PublicNavItem = ({
    startWith,
    routeName,
    name,
    link,
    border,
    icon,
    children,
}: {
    startWith?: string;
    routeName?: any;
    name: any;
    link: boolean;
    border: boolean;
    icon: any;
    children: any;
}) => {
    const { url, component } = usePage();

    function isActive(startWith?: string) {
        if (startWith == "/") {
            return url == startWith;
        } else {
            return url.startsWith(startWith ?? "");
        }
    }

    return (
        <>
            {link ? (
                    <PublicNavSingle
                        name={name}
                        startWith={startWith}
                        routeName={routeName}
                        icon={icon}
                    />

            ) : border ? (
                <NavSeparator name={name} />
            ) : (
                <NavTitle name={name} />
            )}
        </>
    );
};
export default PublicNavItem;
