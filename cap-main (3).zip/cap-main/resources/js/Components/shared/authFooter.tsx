import { useLaravelReactI18n } from "laravel-react-i18n";

function getYear() {
  return new Date().getFullYear();
}
export default function AuthFooter() {
     const { t } = useLaravelReactI18n();
  return (
      <div>
          <p className="text-center text-base font-[300] text-gray-200">
              <span className="block">
                  @{getYear()} Clearshift All Rights Reserved.
              </span>
          </p>
          <span className="sr-only">
              Development and Maintenance by
              <a
                  target="_blank"
                  className="mx-1 font-[500] cursor-pointer"
                  href="https://axcertro.com/?a=clearshift"
              >
                  Acertro Ltd
              </a>{" "}
          </span>
      </div>
  );
}
