import { useLaravelReactI18n } from "laravel-react-i18n";

function getYear() {
    return new Date().getFullYear();
}
export default function Footer() {
    const { t } = useLaravelReactI18n();
    return (
        <footer className="py-6">
            <div className="container mx-auto">
                <p className="flex justify-center sm-auto font-[400] text-gray-600 text-sm">
                    @{getYear()} Clearshift All Rights Reserved.
                </p>
                <p className="flex justify-center sm-auto font-[400] text-gray-600 text-xs mt-2">
                    Development and Maintenance by
                    <a
                        target="_blank"
                        className="mx-1 font-[500] cursor-pointer"
                        href="https://axcertro.com/?a=clearshift"
                    >
                        Acertro Ltd
                    </a>{" "}
                </p>
            </div>
        </footer>
    );
}
