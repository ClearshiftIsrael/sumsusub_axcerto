import { SVGAttributes } from "react";

export default function ApplicationLogo(props: SVGAttributes<SVGElement>) {
    return (
        <img
            className="self-center object-contain lg:h-full lg:w-auto"
            src={"/assets/image/logo.png?a=10"}
            width="120"
            height="100"
        />
    );
}
